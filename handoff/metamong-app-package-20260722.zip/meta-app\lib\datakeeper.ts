// SERVER-ONLY. Data Keeper read client (orbitools PG API).
// Mirrors tools/data_keeper_client.py:42-62 pattern. No fallback chain — direct PG only.

import "server-only";

const BASE = "https://orbitools.orbiters.co.kr/api/datakeeper";

// DK read 토큰. Vercel env 가 비어도 동작하도록 fallback 내장(meta-app 은 gitignore·server-only).
// 로테이션 시 이 값 교체 + SE/.env·.env.local 갱신. [[reference_dk_token_rotation_3places]]
const DK_TOKEN_FALLBACK = "dk_SE_7de6ec154f3d7b7bd0cc571a9e5b7220e125af197cf9dc1d40b893b086e13023";

function authHeaders(): HeadersInit {
  const token = process.env.DK_SE_READ_TOKEN || DK_TOKEN_FALLBACK;
  if (token) return { Authorization: `Bearer ${token}` };
  const u = process.env.ORBITOOLS_USER;
  const p = process.env.ORBITOOLS_PASS;
  if (u && p) {
    return { Authorization: `Basic ${Buffer.from(`${u}:${p}`).toString("base64")}` };
  }
  throw new Error("DK_SE_READ_TOKEN or ORBITOOLS_USER/PASS missing");
}

export interface DkQueryOptions {
  days?: number;
  dateFrom?: string;
  dateTo?: string;
  limit?: number;
  brand?: string;
  postId?: string;
  username?: string;
  adId?: string;
  // 필요 컬럼만 선택 — content_posts 는 caption/transcript 등 대형 텍스트 포함이라
  // 미지정 시 3~6MB (Next data cache 2MB 한도 초과 → 매 렌더 재fetch + DK 부하 → 503)
  fields?: string[];
}

// ── 동시요청 상한 + 재시도 ──────────────────────────────────────────────
// orbitools nginx/gunicorn 이 버스트(동시 다발 요청)에서 즉시 503 을 뱉는다(≈4ms).
// 상세/풀 페이지가 광고·콜라보 수만큼 DK 를 동시에 쏘면 한계에 걸려 페이지 전체가 실패.
// → 클라이언트에서 동시요청을 제한하고, 일시적 5xx/429 는 백오프 재시도한다.
const MAX_CONCURRENT = 4;
let active = 0;
const waiters: (() => void)[] = [];

function acquire(): Promise<void> {
  if (active < MAX_CONCURRENT) { active++; return Promise.resolve(); }
  return new Promise<void>((resolve) => waiters.push(resolve));
}
function release(): void {
  const next = waiters.shift();
  if (next) next();   // 슬롯을 다음 대기자에게 넘김 (active 유지)
  else active--;      // 대기자 없으면 슬롯 반납
}

const RETRY_STATUS = new Set([429, 500, 502, 503, 504]);
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
// 150 · 400 · 900ms + 지터 (동시요청이 몰릴 때 재시도 타이밍 분산)
function backoff(attempt: number): number {
  const base = [150, 400, 900][attempt] ?? 900;
  return base + Math.floor(Math.random() * 200);
}

async function fetchWithRetry(url: string, init: RequestInit, tries = 4): Promise<Response> {
  let lastRes: Response | null = null;
  for (let i = 0; i < tries; i++) {
    await acquire();
    try {
      const res = await fetch(url, init);
      if (!RETRY_STATUS.has(res.status)) return res;   // 성공/영구오류 → 그대로 반환
      lastRes = res;
    } catch (e) {
      if (i === tries - 1) throw e;                     // 네트워크 오류 → 마지막이면 throw
    } finally {
      release();
    }
    if (i < tries - 1) await sleep(backoff(i));         // 슬롯 놓고 대기 후 재시도
  }
  return lastRes as Response;                            // 소진 → 마지막 5xx 반환 (상위에서 throw)
}

export async function dkQuery<T = Record<string, unknown>>(
  table: string,
  opts: DkQueryOptions = {},
  revalidate = 300,
): Promise<T[]> {
  const params = new URLSearchParams({ table });
  if (opts.days !== undefined) params.set("days", String(opts.days));
  if (opts.dateFrom) params.set("date_from", opts.dateFrom);
  if (opts.dateTo) params.set("date_to", opts.dateTo);
  if (opts.limit !== undefined) params.set("limit", String(opts.limit));
  if (opts.brand) params.set("brand", opts.brand);
  if (opts.postId) params.set("post_id", opts.postId);
  if (opts.username) params.set("username", opts.username);
  if (opts.adId) params.set("ad_id", opts.adId);
  if (opts.fields?.length) params.set("fields", opts.fields.join(","));

  const url = `${BASE}/query/?${params.toString()}`;
  const res = await fetchWithRetry(url, { headers: authHeaders(), next: { revalidate } });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`DK ${table} ${res.status}: ${body.slice(0, 200)}`);
  }
  const data = await res.json();
  if (Array.isArray(data)) return data as T[];
  if (Array.isArray((data as { rows?: unknown[] }).rows)) return (data as { rows: T[] }).rows;
  return [];
}

// ── content_metrics_daily ──
export interface ContentMetric {
  post_id: string;
  date: string;
  views: number;
  likes: number;
  comments: number;
}

export async function fetchContentMetrics(days = 90): Promise<ContentMetric[]> {
  return dkQuery<ContentMetric>("content_metrics_daily", {
    days, limit: 50000,
    fields: ["post_id", "date", "views", "likes", "comments"],   // 1.8MB → 0.95MB
  });
}

// ── content_posts (post_date 등 메타데이터) ──
export interface ContentPost {
  post_id: string;
  post_date: string | null;
  username: string;
  brand: string;
  platform: string;
  region: string | null;
  followers: number | null;
  views_30d: number | null;      // 조회수 (= 3초 이상 시청)
  plays_30d: number | null;      // 재생수 (= 전체 접촉/노출)
  likes_30d: number | null;
  comments_30d: number | null;
  engagement_rate: number | null;
  url: string | null;
}

export async function fetchContentPosts(days = 365, brand?: string): Promise<ContentPost[]> {
  // brand 필터 시 결과 ~1000건 → limit 3000 충분. (50000 은 서버 부하로 503 유발)
  // fields 필수: 전체 컬럼은 caption/transcript/ci_analysis 포함 3.3MB (2MB 캐시 한도 초과)
  return dkQuery<ContentPost>("content_posts", {
    days, limit: brand ? 3000 : 20000, brand,
    fields: [
      "post_id", "post_date", "username", "brand", "platform", "region", "followers",
      "views_30d", "plays_30d", "likes_30d", "comments_30d", "engagement_rate", "url",
    ],   // 3.3MB → 0.22MB
  });
}

// ── 3초 이상 시청 비율 (views/plays). post_id 키 (IG=shortcode). ──
// measured=false = plays==views (구분 미수집) → 100% 로 뜨지만 실측 아님.
export interface Watch3s { views: number; plays: number; rate: number | null; measured: boolean; }

export async function fetchWatch3sMap(brand = "grosmimi"): Promise<Map<string, Watch3s>> {
  const posts = await fetchContentPosts(365, brand);
  const m = new Map<string, Watch3s>();
  for (const p of posts) {
    const views = p.views_30d ?? 0;
    const plays = p.plays_30d ?? 0;
    // 조회==재생(구분 미포착)은 3s율 무의미 → 조회<재생(진짜 측정)만 채택
    if (!p.post_id || plays <= views) continue;
    m.set(p.post_id, { views, plays, rate: views / plays, measured: true });
  }
  return m;
}
