import { NextResponse } from "next/server";
import { fetchDailyIssues } from "@/lib/daily-issues";

export async function GET() {
  try {
    const data = await fetchDailyIssues();
    return NextResponse.json(data);
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : String(e) },
      { status: 500 },
    );
  }
}
