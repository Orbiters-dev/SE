"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, BarChart3, Wallet, Bell, Users, KeyRound, Repeat } from "lucide-react";
import { cn } from "@/lib/utils";
import { Monkey } from "@/components/meta/Monkey";

const NAV = [
  { href: "/", label: "홈", icon: Home },
  { href: "/products", label: "전환", icon: Repeat },
  { href: "/ads", label: "광고", icon: BarChart3 },
  { href: "/budget", label: "예산", icon: Wallet },
  { href: "/alerts", label: "알림", icon: Bell },
  { href: "/influencers", label: "콘텐츠", icon: Users },
  { href: "/codes", label: "코드", icon: KeyRound },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  if (pathname.startsWith("/login")) {
    return <>{children}</>;
  }
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 border-b border-border/60 bg-background/70 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <Link href="/" className="flex items-center gap-2.5">
            <Monkey mood="happy" size={36} />
            <div className="leading-tight">
              <div className="text-base font-bold tracking-tight">메타몽</div>
              <div className="text-[10px] font-medium text-muted-foreground">Grosmimi JP</div>
            </div>
          </Link>
          <nav className="hidden gap-1 md:flex">
            {NAV.map(({ href, label, icon: Icon }) => {
              const active = href === "/" ? pathname === "/" : pathname.startsWith(href);
              return (
                <Link
                  key={href}
                  href={href}
                  className={cn(
                    "flex items-center gap-1.5 rounded-full px-3.5 py-1.5 text-sm font-semibold transition-colors",
                    active
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground",
                  )}
                >
                  <Icon className="h-4 w-4" />
                  {label}
                </Link>
              );
            })}
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-6xl flex-1 px-4 pb-24 pt-5 sm:px-6 md:pb-10">
        {children}
      </main>
      <nav className="fixed inset-x-0 bottom-0 z-30 border-t border-border/60 bg-background/90 backdrop-blur-md md:hidden">
        <div className="mx-auto flex max-w-6xl items-stretch">
          {NAV.map(({ href, label, icon: Icon }) => {
            const active = href === "/" ? pathname === "/" : pathname.startsWith(href);
            return (
              <Link
                key={href}
                href={href}
                className={cn(
                  "relative flex flex-1 flex-col items-center gap-0.5 py-2.5 text-[11px] font-semibold transition-colors",
                  active ? "text-primary" : "text-muted-foreground",
                )}
              >
                {active && <span className="absolute inset-x-6 top-0 h-0.5 rounded-full bg-primary" />}
                <Icon className="h-5 w-5" />
                {label}
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
