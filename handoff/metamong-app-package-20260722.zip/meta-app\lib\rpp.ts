// SERVER-ONLY. Rakuten RPP 일별 광고비 (SE tools/collect_rpp_daily.py 가 매일 09:20 수집).
// 소스: 라쿠텐 RPP 콘솔 내부 API downloadPerfFile periodType=2 (일별 집계) — RMS 공식 API 미노출.
// 시드: lib/rpp-daily-seed.json (수집기가 갱신 후 재배포). 검증: 2026-06 합계 ¥106,902 = 세은 제공값 일치.

import "server-only";
import seed from "./rpp-daily-seed.json";

interface RppDay {
  clicks: number;
  spend_jpy: number;
  cpc_jpy: number;
  ctr_pct: number;
  sales_12h_jpy: number;
  orders_12h: number;
  roas_12h_pct: number;
  sales_720h_jpy: number;
  orders_720h: number;
  roas_720h_pct: number;
}

interface RppSeed {
  updated_at: string | null;
  days: Record<string, RppDay>;
}

const store = seed as unknown as RppSeed;

export interface RppMonthlyRow {
  month: string; // "2026-06"
  spendJpy: number;
  clicks: number;
  sales720hJpy: number;
}

export function rppUpdatedAt(): string | null {
  return store.updated_at;
}

// 월별 RPP 광고비 (최신 월 위로 — 예산 탭 월별 뷰와 동일 정렬)
export function rppMonthly(): RppMonthlyRow[] {
  const byMonth = new Map<string, RppMonthlyRow>();
  for (const [day, rec] of Object.entries(store.days)) {
    const month = day.slice(0, 7);
    const cur = byMonth.get(month) ?? { month, spendJpy: 0, clicks: 0, sales720hJpy: 0 };
    cur.spendJpy += rec.spend_jpy;
    cur.clicks += rec.clicks;
    cur.sales720hJpy += rec.sales_720h_jpy;
    byMonth.set(month, cur);
  }
  return [...byMonth.values()].sort((a, b) => b.month.localeCompare(a.month));
}

export interface RppRangeSummary {
  spendJpy: number;
  clicks: number;
  sales720hJpy: number;
  days: number; // 범위 내 데이터 보유 일수 (store 는 어제까지)
}

// 기간 합산 (since/until ISO date, inclusive) — 예산 탭 어제/7일/30일/MTD/Lifetime 뷰용
export function rppRange(since: string, until: string): RppRangeSummary {
  const out: RppRangeSummary = { spendJpy: 0, clicks: 0, sales720hJpy: 0, days: 0 };
  for (const [day, rec] of Object.entries(store.days)) {
    if (day < since || day > until) continue;
    out.spendJpy += rec.spend_jpy;
    out.clicks += rec.clicks;
    out.sales720hJpy += rec.sales_720h_jpy;
    out.days += 1;
  }
  return out;
}

// JPY→KRW 환율 (12h 캐시). 실패 시 fallback 9.11 (2026-07-21 실측).
const FALLBACK_RATE = 9.11;

export async function fetchJpyKrw(): Promise<{ rate: number; live: boolean }> {
  try {
    const res = await fetch("https://open.er-api.com/v6/latest/JPY", {
      next: { revalidate: 43200 },
    });
    if (res.ok) {
      const d = (await res.json()) as { rates?: { KRW?: number } };
      const r = d.rates?.KRW;
      if (typeof r === "number" && r > 0) return { rate: r, live: true };
    }
  } catch {
    // fall through
  }
  return { rate: FALLBACK_RATE, live: false };
}
