// SERVER-ONLY. 1:1 port of aggregation functions from tools/meta_jp_daily.py.
// Sync rule: when meta_jp_daily.py changes, update here the same turn.

import "server-only";
import { fetchInsights, fetchAdStatuses } from "./dk-meta";   // DK 단일소스 (Graph 대체)
import { extractLpv, extractPurchases, type InsightRow } from "./meta-api";  // 순수 헬퍼
import { toFloat, isoDate, daysAgo } from "./format";
import {
  SUPERSALE_START,
  SUPERSALE_END,
  BUDGET_RAISE_START,
  FREQ_HIGH,
  OFF_D3_CPC_MAX,
  OFF_D3_CTR_MIN,
  OFF_D3_CPLPV_OFF,
  OFF_MIN_DAYS,
  OFF_DELIVERY_DAYS,
  OFF_DELIVERY_FLOOR,
  GRAD_CPC_MAX,
  GRAD_CTR_MIN,
  GRAD_CPLPV_MAX,
  GRAD_MIN_DAYS,
} from "./meta-constants";

export interface AdRow {
  ad_id: string;
  ad_name: string;
  adset_name: string;
  campaign_name: string;
  spend: number;
  impressions: number;
  clicks: number;
  reach: number;
  frequency: number;
  lpv: number;
  purchases: number;
  purchase_value: number;
  ctr: number;        // %
  cpc: number;        // KRW
  cpm: number;        // KRW
  cplpv: number;      // KRW
  roas: number;
  cvr: number;        // %
}

function deriveMetrics(r: InsightRow): AdRow {
  const spend = toFloat(r.spend);
  const impr = toFloat(r.impressions);
  const clicks = toFloat(r.clicks);
  const reach = toFloat(r.reach);
  const freq = toFloat(r.frequency);
  const lpv = extractLpv(r.actions);
  const purchases = extractPurchases(r.actions);
  const ctr = impr > 0 ? (clicks / impr) * 100 : 0;
  const cpc = clicks > 0 ? spend / clicks : 0;
  const cpm = impr > 0 ? (spend / impr) * 1000 : 0;
  const cplpv = lpv > 0 ? spend / lpv : 0;
  const cvr = clicks > 0 ? (purchases / clicks) * 100 : 0;
  return {
    ad_id: r.ad_id ?? "",
    ad_name: r.ad_name ?? "",
    adset_name: r.adset_name ?? "",
    campaign_name: r.campaign_name ?? "",
    spend, impressions: impr, clicks, reach, frequency: freq,
    lpv, purchases, purchase_value: 0,  // purchase_value extracted separately if needed
    ctr, cpc, cpm, cplpv,
    roas: 0,  // requires purchase_value action
    cvr,
  };
}

// ── Account-level summary ──
export interface AccountSummary {
  spend: number;
  impressions: number;
  clicks: number;
  reach: number;
  lpv: number;
  purchases: number;
  ctr: number;
  cpc: number;
  cplpv: number;
  frequency: number;
}

function summarizeAccount(rows: InsightRow[]): AccountSummary {
  const spend = rows.reduce((s, r) => s + toFloat(r.spend), 0);
  const impr = rows.reduce((s, r) => s + toFloat(r.impressions), 0);
  const clicks = rows.reduce((s, r) => s + toFloat(r.clicks), 0);
  const reach = rows.reduce((s, r) => s + toFloat(r.reach), 0);
  const lpv = rows.reduce((s, r) => s + extractLpv(r.actions), 0);
  const purchases = rows.reduce((s, r) => s + extractPurchases(r.actions), 0);
  return {
    spend, impressions: impr, clicks, reach, lpv, purchases,
    ctr: impr > 0 ? (clicks / impr) * 100 : 0,
    cpc: clicks > 0 ? spend / clicks : 0,
    cplpv: lpv > 0 ? spend / lpv : 0,
    frequency: reach > 0 ? impr / reach : 0,
  };
}

// ── Public: fetch + summarize period (days back from ref) ──
export async function fetchAccountSummary(
  since: string,
  until: string,
): Promise<AccountSummary> {
  const rows = await fetchInsights({
    level: "account",
    timeRange: { since, until },
  });
  return summarizeAccount(rows);
}

// ── Public: fetch ads + normalize ──
export async function fetchAds(
  since: string,
  until: string,
): Promise<AdRow[]> {
  const rows = await fetchInsights({
    level: "ad",
    timeRange: { since, until },
  });
  const mapped = rows.map(deriveMetrics);
  // on/off 필터 — 꺼진 광고(ADSET_PAUSED·PAUSED·ARCHIVED 등) 제외, ACTIVE 만.
  // 6/19 제품분리로 같은 ad_name 이 옛 ad_id(paused)+새 ad_id(active) 중복되는 것 방지.
  // status 조회 전체 실패 시엔 전체 유지(안전 — 빈 표 방지).
  const statuses = await fetchAdStatuses(mapped.map((a) => a.ad_id).filter(Boolean));
  return statuses.size > 0
    ? mapped.filter((a) => statuses.get(a.ad_id) === "ACTIVE")
    : mapped;
}

// ── BEST / WORST (port of meta_jp_daily.py L295-349 simplified) ──
export type SortKey = "ctr" | "cpc" | "cplpv" | "spend";

export function bestWorst(
  ads: AdRow[],
  key: SortKey,
  n = 5,
  minSpend = 1000,
): { best: AdRow[]; worst: AdRow[] } {
  const qualified = ads.filter((a) => a.spend >= minSpend);
  const asc = key === "cpc" || key === "cplpv";
  const sorted = [...qualified].sort((a, b) => {
    const diff = (a[key] ?? 0) - (b[key] ?? 0);
    return asc ? diff : -diff;
  });
  return {
    best: sorted.slice(0, n),
    worst: sorted.slice(-n).reverse(),
  };
}

// ── 종합 BEST/WORST (2026-06-10 광고 탭용) ──
// 자격: 7일 노출 ≥ 200 (meta_jp_daily.py best_worst_from_rows 와 동일 게이트)
// 종합점수 = 풀 내 percentile 가중합 — CPLPV 50% (LPV 효율 = 운영 1차 축) + CTR 30% + CPC 20%
// BEST 먼저 뽑고 WORST 는 BEST 제외 후 선정 (겹침 방지 — 메일과 동일)
export interface CompositeAd extends AdRow {
  score: number;
}

export function compositeBestWorst(
  ads: AdRow[],
  n = 3,
  minImpr = 200,
): { best: CompositeAd[]; worst: CompositeAd[]; poolSize: number } {
  const pool = ads.filter((a) => a.impressions >= minImpr);
  if (pool.length < 2) return { best: [], worst: [], poolSize: pool.length };

  const pct = (sorted: number[], v: number): number => {
    if (sorted.length === 0) return 50;
    let lt = 0, eq = 0;
    for (const x of sorted) {
      if (x < v) lt++;
      else if (x === v) eq++;
    }
    return ((lt + eq / 2) / sorted.length) * 100;
  };
  const ctrs = pool.map((a) => a.ctr).sort((a, b) => a - b);
  const cpcs = pool.filter((a) => a.cpc > 0).map((a) => a.cpc).sort((a, b) => a - b);
  const cplpvs = pool.filter((a) => a.cplpv > 0).map((a) => a.cplpv).sort((a, b) => a - b);

  const scored: CompositeAd[] = pool.map((a) => {
    const sCtr = pct(ctrs, a.ctr);
    const sCpc = a.cpc > 0 ? 100 - pct(cpcs, a.cpc) : 0;        // LPV/클릭 0 = 최하점
    const sCplpv = a.cplpv > 0 ? 100 - pct(cplpvs, a.cplpv) : 0;
    return { ...a, score: 0.5 * sCplpv + 0.3 * sCtr + 0.2 * sCpc };
  });

  const k = Math.min(n, Math.floor(scored.length / 2));
  const best = [...scored].sort((x, y) => y.score - x.score).slice(0, k);
  const bestIds = new Set(best.map((a) => a.ad_id));
  const worst = [...scored]
    .sort((x, y) => x.score - y.score)
    .filter((a) => !bestIds.has(a.ad_id))
    .slice(0, k);
  return { best, worst, poolSize: pool.length };
}

// ── Supersale period compare (port of L1259-1299) ──
export interface SupersaleCompare {
  after_window: string;
  before_window: string;
  after: AccountSummary;
  before: AccountSummary;
  delta: Record<"spend" | "lpv" | "cplpv" | "ctr" | "frequency" | "reach", number>;
  active: boolean;  // false if past SUPERSALE_END
}

export async function fetchSupersaleCompare(
  refDate: Date,
): Promise<SupersaleCompare | null> {
  if (refDate < SUPERSALE_START) return null;
  const afterStart = SUPERSALE_START;
  const afterEnd = refDate < SUPERSALE_END ? refDate : SUPERSALE_END;
  const nDays =
    Math.floor((afterEnd.getTime() - afterStart.getTime()) / 86_400_000) + 1;
  const beforeEnd = new Date(BUDGET_RAISE_START);
  beforeEnd.setUTCDate(beforeEnd.getUTCDate() - 1);
  const beforeStart = new Date(beforeEnd);
  beforeStart.setUTCDate(beforeStart.getUTCDate() - (nDays - 1));

  const [after, before] = await Promise.all([
    fetchAccountSummary(isoDate(afterStart), isoDate(afterEnd)),
    fetchAccountSummary(isoDate(beforeStart), isoDate(beforeEnd)),
  ]);

  const pct = (a: number, b: number) => (b === 0 ? 0 : (a / b - 1) * 100);
  return {
    after_window: `${isoDate(afterStart)} ~ ${isoDate(afterEnd)} (${nDays}일)`,
    before_window: `${isoDate(beforeStart)} ~ ${isoDate(beforeEnd)} (${nDays}일, 증액 전)`,
    after,
    before,
    delta: {
      spend: pct(after.spend, before.spend),
      lpv: pct(after.lpv, before.lpv),
      cplpv: pct(after.cplpv, before.cplpv),
      ctr: pct(after.ctr, before.ctr),
      frequency: pct(after.frequency, before.frequency),
      reach: pct(after.reach, before.reach),
    },
    active: refDate <= SUPERSALE_END,
  };
}

// ── Budget increase candidates (port of L552-580) ──
export interface BudgetCandidate extends AdRow {
  cplpv_ratio: number;
  ctr_ratio: number;
  bump_pct: number;
  avg_cplpv: number;
  avg_ctr: number;
}

export function budgetIncreaseCandidates(
  ads: AdRow[],
  minSpend = 30000,
): BudgetCandidate[] {
  // Testing 은 증액 제도 없음 (졸업뿐, 세은 2026-07-07: 증액 안 함) → Proven 만.
  // 졸업 후보(graduationCandidates)와 동일하게 adset OR campaign 명으로 Testing 판정 →
  // 같은 영상이 증액·졸업 양쪽에 뜨는 것 방지 (증액은 campaign, 졸업은 adset 만 보던 불일치 제거).
  const isTesting = (a: AdRow) => /test/i.test(a.campaign_name) || /test/i.test(a.adset_name);
  const qualified = ads.filter(
    (a) => a.spend >= minSpend && a.lpv > 0 && a.ctr > 0 && a.frequency <= FREQ_HIGH
      && !isTesting(a),
  );
  if (qualified.length === 0) return [];
  const avgCplpv = qualified.reduce((s, a) => s + a.cplpv, 0) / qualified.length;
  const avgCtr = qualified.reduce((s, a) => s + a.ctr, 0) / qualified.length;
  const candidates: BudgetCandidate[] = [];
  for (const a of qualified) {
    const cplpvRatio = avgCplpv > 0 ? a.cplpv / avgCplpv : 1;
    const ctrRatio = avgCtr > 0 ? a.ctr / avgCtr : 1;
    if (cplpvRatio <= 0.85 && ctrRatio >= 1.1) {
      const improvement = (1 - cplpvRatio) * 100;
      const bump = improvement >= 50 ? 30 : improvement >= 20 ? 20 : 10;
      candidates.push({
        ...a, cplpv_ratio: cplpvRatio, ctr_ratio: ctrRatio,
        bump_pct: bump, avg_cplpv: avgCplpv, avg_ctr: avgCtr,
      });
    }
  }
  return candidates.sort((a, b) => a.cplpv_ratio - b.cplpv_ratio).slice(0, 5);
}

// ── Off 권장 (2026-06-16 확정 D+3 게이트 — port of meta_jp_daily.py off_rule_check + render_off_recommend_box) ──
// memory/reference_meta_wl_testing_gate_criteria.md 게이트 1.
// Testing(1:1 분리, D+3+ 판정): CPC≤₩150 AND CTR≥5% → 생존.
//   ② CPC·CTR 중 하나라도 나쁨 → CPLPV≥₩190 시 OFF / 정상이면 D+5 유예(monitoring).
//   ③ CPC·CTR 양호한데 CPLPV≥₩190 → 이탈형 OFF.
// Proven: D+90+ AND spend<₩5K (delivery 실패)만. WL 은 3~6개월 운용 — 시간 단독 트리거 X.
// 풀 = PAID/GIFT × Testing/Proven (newborn D+7 미만 / UNKNOWN 이미지 광고 제외). Freq 피로도는 별도 알림.

export type PaidFlag = "PAID" | "GIFT" | "UNKNOWN";
export type Lifecycle = "newborn" | "testing" | "proven" | "unknown";

export function parsePaidFlag(adName: string): PaidFlag {
  const n = adName ?? "";
  if (n.includes("| PAID |")) return "PAID";
  if (n.includes("| GIFT |")) return "GIFT";
  // 신 명명 (2026-06~): RKT_WL-P_ (Paid) / RKT_WL-G_ (Gift).
  if (n.includes("WL-P")) return "PAID";
  if (n.includes("WL-G")) return "GIFT";
  return "UNKNOWN";
}

// ad_name 끝 8자리 (yyyymmdd) → D+N. 파싱 실패 시 null.
export function calcDaysLive(adName: string, refDate: Date): number | null {
  if (!adName) return null;
  const ref = Date.UTC(refDate.getUTCFullYear(), refDate.getUTCMonth(), refDate.getUTCDate());
  // 신 명명 (2026-06~): 앞쪽 Y26M06D19 (= 2026-06-19)
  const mNew = adName.match(/Y(\d{2})M(\d{2})D(\d{2})/);
  if (mNew) {
    const [, yy, mo, dd] = mNew;
    const mn = Number(mo), dn = Number(dd);
    if (mn < 1 || mn > 12 || dn < 1 || dn > 31) return null;
    const launch = Date.UTC(2000 + Number(yy), mn - 1, dn);
    return Math.floor((ref - launch) / 86_400_000);
  }
  // 구 명명: 끝 8자리 yyyymmdd
  const tail = adName.includes("|")
    ? (adName.trim().split("|").pop() ?? "").trim()
    : adName.trim().slice(-8);
  const digits = (tail.match(/\d/g) ?? []).join("").slice(-8);
  if (digits.length !== 8) return null;
  const y = Number(digits.slice(0, 4));
  const m = Number(digits.slice(4, 6));
  const d = Number(digits.slice(6, 8));
  if (m < 1 || m > 12 || d < 1 || d > 31) return null;
  const launch = Date.UTC(y, m - 1, d);
  return Math.floor((ref - launch) / 86_400_000);
}

export function lifecycleStage(daysLive: number | null): Lifecycle {
  if (daysLive === null) return "unknown";
  if (daysLive < 7) return "newborn";
  if (daysLive < 15) return "testing";
  return "proven";
}

export interface OffRuleAd extends AdRow {
  pool: string;            // "PAID×Testing"
  paid_flag: PaidFlag;
  days_live: number | null;
  reason: string;
}

const won = (v: number) => `₩${Math.round(v).toLocaleString("en-US")}`;

export function offRecommendations(
  ads: AdRow[],
  refDate: Date,
  minImpr = 200,
): { candidates: OffRuleAd[]; monitoring: OffRuleAd[] } {
  // 풀 자격: 노출 ≥ 200. 단 delivery 실패 평가 대상(D+90+ & spend<₩5K)은 노출 미달이어도 포함
  const enriched = ads
    .map((a) => {
      const daysLive = calcDaysLive(a.ad_name, refDate);
      return {
        ...a,
        paid_flag: parsePaidFlag(a.ad_name),
        days_live: daysLive,
        // Testing/Proven 은 campaign 기준 (졸업 로직과 통일). 나이 기반 X — D+15+ Testing 이 Proven 으로 새는 것 방지.
        lifecycle: (/test/i.test(a.campaign_name) ? "testing" : "proven") as Lifecycle,
      };
    })
    .filter(
      (a) =>
        a.impressions >= minImpr ||
        (a.days_live !== null && a.days_live >= OFF_DELIVERY_DAYS && a.spend < OFF_DELIVERY_FLOOR),
    );

  const candidates: OffRuleAd[] = [];
  const monitoring: OffRuleAd[] = [];

  for (const paid of ["PAID", "GIFT"] as const) {
    for (const lc of ["testing", "proven"] as const) {
      const members = enriched.filter((a) => a.paid_flag === paid && a.lifecycle === lc);
      if (members.length === 0) continue;
      const poolLabel = `${paid}×${lc === "testing" ? "Testing" : "Proven"}`;

      for (const a of members) {
        if (lc === "testing") {
          // 게이트 1 — D+3 OFF (off_rule_check). D+3+ 만 판정.
          if (a.days_live === null || a.days_live < OFF_MIN_DAYS) continue;
          const cpcBad = a.cpc > OFF_D3_CPC_MAX;
          const ctrBad = a.ctr < OFF_D3_CTR_MIN;
          const cplpvBad = a.cplpv >= OFF_D3_CPLPV_OFF && a.cplpv > 0;

          if (!cpcBad && !ctrBad) {
            // ③ CPC/CTR 양호 — CPLPV 이탈형만 OFF
            if (cplpvBad) {
              candidates.push({
                ...a, pool: poolLabel,
                reason: `CPC ${won(a.cpc)}·CTR ${a.ctr.toFixed(1)}% 양호하나 CPLPV ${won(a.cplpv)} ≥ ₩${OFF_D3_CPLPV_OFF} (이탈형)`,
              });
            }
          } else {
            // ② CPC/CTR 중 하나 나쁨 → CPLPV 로 OFF/유예 판정
            const bad: string[] = [];
            if (cpcBad) bad.push(`CPC ${won(a.cpc)} > ₩${OFF_D3_CPC_MAX}`);
            if (ctrBad) bad.push(`CTR ${a.ctr.toFixed(1)}% < ${OFF_D3_CTR_MIN}%`);
            if (cplpvBad) {
              candidates.push({
                ...a, pool: poolLabel,
                reason: `${bad.join(" · ")} + CPLPV ${won(a.cplpv)} ≥ ₩${OFF_D3_CPLPV_OFF}`,
              });
            } else {
              monitoring.push({
                ...a, pool: poolLabel,
                reason: `${bad.join(" · ")} but CPLPV ${won(a.cplpv)} 정상 — D+5 유예`,
              });
            }
          }
        } else {
          // Proven: delivery 실패만 (시간 단독 트리거 X — WL 은 3~6개월 운용)
          if (a.days_live !== null && a.days_live >= OFF_DELIVERY_DAYS && a.spend < OFF_DELIVERY_FLOOR) {
            candidates.push({
              ...a, pool: poolLabel,
              reason: `D+${a.days_live} + spend ${won(a.spend)} < ${won(OFF_DELIVERY_FLOOR)} (delivery 실패)`,
            });
          }
        }
      }
    }
  }

  candidates.sort((x, y) => y.spend - x.spend);
  monitoring.sort((x, y) => y.spend - x.spend);
  return { candidates, monitoring };
}

// ── 졸업 후보 (2026-06-16 확정 — WL Testing 1:1 분리 운영 절대 지표) ──
// memory/reference_meta_wl_testing_gate_criteria.md 게이트 2.
// Testing adset 소속 + D+3+ + CPC≤₩95 AND CTR≥8% AND CPLPV≤₩130 모두 통과.
// 1:1 분리 운영(소재1=adset1)이라 풀 share 무의미 → 개별 절대 지표로 졸업 판정.
// 메일(meta_jp_daily.py graduation_candidates)은 5/21 share 2-window 기준 유지 — app은 최신 기준 별개 구현.
// clicks 0 → cpc 0, lpv 0 → cplpv 0 이 게이트를 거짓 통과하므로 양수 가드 필수.
export interface GradCandidate extends AdRow {
  days_live: number | null;
  paid_flag: PaidFlag;
}

export function graduationCandidates(
  ads: AdRow[],
  refDate: Date,
  minImpr = 200,
): GradCandidate[] {
  const out: GradCandidate[] = [];
  for (const a of ads) {
    if (!/test/i.test(a.adset_name) && !/test/i.test(a.campaign_name)) continue;  // Testing 소속 (신 구조: campaign 명에 Testing)
    if (a.impressions < minImpr) continue;           // 표본 충분
    const daysLive = calcDaysLive(a.ad_name, refDate);
    if (daysLive === null || daysLive < GRAD_MIN_DAYS) continue;  // D+7+
    if (a.cpc <= 0 || a.cplpv <= 0) continue;        // 데이터 부족(클릭/LPV 0) 거짓통과 차단
    if (a.cpc > GRAD_CPC_MAX) continue;
    if (a.ctr < GRAD_CTR_MIN) continue;
    if (a.cplpv > GRAD_CPLPV_MAX) continue;
    out.push({ ...a, days_live: daysLive, paid_flag: parsePaidFlag(a.ad_name) });
  }
  return out.sort((x, y) => x.cplpv - y.cplpv);      // CPLPV 좋은 순
}

// ── 월별 사용액 (예산 탭 — 2026-06-10 세은 지시: 비교 X, 사용액 정리만) ──
export interface MonthlySpendRow {
  month: string;        // "2026-06"
  spend: number;
  inProgress: boolean;  // 이번 달 진행 중
}

const ACCOUNT_START = "2025-12-01";  // act_4117678028561958 첫 spend 월 (2025-12 실측)

export interface MonthlyAdRow {
  ad_name: string;
  campaign_name: string;
  spend: number;
}

// 월 → 광고별 spend 내역 (토글 상세용)
export async function fetchMonthlyAdSpend(): Promise<Map<string, MonthlyAdRow[]>> {
  const today = new Date();
  const raw = await fetchInsights({
    level: "ad",
    timeRange: { since: ACCOUNT_START, until: isoDate(today) },
    timeIncrement: "monthly",
  });
  const byMonth = new Map<string, MonthlyAdRow[]>();
  for (const r of raw) {
    const month = (r.date_start ?? "").slice(0, 7);
    const spend = toFloat(r.spend);
    if (!month || spend <= 0) continue;
    const arr = byMonth.get(month) ?? [];
    arr.push({
      ad_name: r.ad_name ?? "(unnamed)",
      campaign_name: r.campaign_name ?? "",
      spend,
    });
    byMonth.set(month, arr);
  }
  for (const arr of byMonth.values()) arr.sort((a, b) => b.spend - a.spend);
  return byMonth;
}

export async function fetchMonthlySpend(): Promise<{ rows: MonthlySpendRow[]; total: number }> {
  const today = new Date();
  const thisMonth = isoDate(today).slice(0, 7);
  const raw = await fetchInsights({
    level: "account",
    timeRange: { since: ACCOUNT_START, until: isoDate(today) },
    timeIncrement: "monthly",
  });
  const rows: MonthlySpendRow[] = raw
    .map((r) => ({
      month: (r.date_start ?? "").slice(0, 7),
      spend: toFloat(r.spend),
      inProgress: (r.date_start ?? "").slice(0, 7) === thisMonth,
    }))
    .filter((r) => r.month)
    .sort((a, b) => b.month.localeCompare(a.month));  // 최신 월 위로
  const total = rows.reduce((s, r) => s + r.spend, 0);
  return { rows, total };
}

// ── Period helpers ──
export function periodRange(period: "1d" | "7d" | "30d" | "mtd" | "lifetime"): {
  since: string;
  until: string;
} {
  const today = new Date();
  const yesterday = daysAgo(1, today);
  const until = isoDate(yesterday);
  let sinceDate: Date;
  switch (period) {
    case "1d":
      sinceDate = yesterday;
      break;
    case "7d":
      sinceDate = daysAgo(7, today);
      break;
    case "30d":
      sinceDate = daysAgo(30, today);
      break;
    case "mtd":
      sinceDate = new Date(Date.UTC(yesterday.getUTCFullYear(), yesterday.getUTCMonth(), 1));
      break;
    case "lifetime":
      sinceDate = new Date("2024-01-01");
      break;
  }
  return { since: isoDate(sinceDate), until };
}
