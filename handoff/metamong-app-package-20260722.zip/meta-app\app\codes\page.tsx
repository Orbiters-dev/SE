import Link from "next/link";
import { ExternalLink } from "lucide-react";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { EnvWarning } from "@/components/meta/EnvWarning";
import { Monkey } from "@/components/meta/Monkey";
import { GradeBadge } from "@/components/meta/GradeChip";
import { CopyButton } from "@/components/meta/CopyButton";
import { buildContentPool, type ContentSummary } from "@/lib/influencer-aggregation";
import { fmtWon } from "@/lib/format";

export const revalidate = 60;

type CodeStatus = "issued" | "declined" | "missing";

function codeStatus(c: ContentSummary): CodeStatus {
  const code = (c.wlCode ?? "").trim();
  if (!code) return "missing";
  if (code === "×" || code === "X" || code === "x") return "declined";
  return "issued";
}

export default async function CodesPage() {
  let body: React.ReactNode;
  try {
    const pool = await buildContentPool();
    const issued = pool.filter((c) => codeStatus(c) === "issued");
    const declined = pool.filter((c) => codeStatus(c) === "declined");
    const missing = pool.filter((c) => codeStatus(c) === "missing");
    const running = issued.filter((c) => c.wlAdIds.length > 0);

    const sorted = [...issued].sort((a, b) => {
      const r = (b.wlAdIds.length > 0 ? 1 : 0) - (a.wlAdIds.length > 0 ? 1 : 0);
      if (r !== 0) return r;
      return b.wlSpendKrw - a.wlSpendKrw;
    });

    body = (
      <>
        <section>
          <div className="mb-3 flex items-baseline justify-between">
            <h1 className="text-lg font-bold tracking-tight">WL 코드 관리</h1>
            <span className="text-xs text-muted-foreground">시트 WL code 칼럼 연동 · 변경 후 최대 5분 내 반영</span>
          </div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 sm:gap-3">
            <Stat label="코드 발급" value={issued.length} />
            <Stat label="광고 집행 중" value={running.length} />
            <Stat label="미발급 (×)" value={declined.length} />
            <Stat label="공란" value={missing.length} />
          </div>
        </section>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">발급 코드 ({issued.length})</CardTitle>
            <p className="text-xs text-muted-foreground">
              광고 집행 중 → spend 순 정렬 · 코드는 복사 버튼으로
            </p>
          </CardHeader>
          <CardContent className="overflow-x-auto p-0">
            <Table className="md:min-w-[860px]">
              <TableHeader>
                <TableRow>
                  <TableHead>크리에이터</TableHead>
                  <TableHead className="hidden md:table-cell">제품</TableHead>
                  <TableHead>WL code</TableHead>
                  <TableHead className="text-right">광고</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sorted.map((c, i) => (
                  <TableRow key={`${c.postShortcode ?? c.creatorId}-${i}`}>
                    <TableCell className="max-w-[115px] md:max-w-[220px]">
                      <div className="flex items-center gap-1">
                        <Link
                          href={`/influencers/${encodeURIComponent(c.igHandle)}`}
                          className="truncate text-sm font-semibold hover:opacity-80"
                        >
                          @{c.igHandle}
                        </Link>
                        <GradeBadge grade={c.wlGrade} />
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="truncate text-[11px] text-muted-foreground md:hidden">
                          {c.product || "—"}
                        </span>
                        {c.url && (
                          <a
                            href={c.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex shrink-0 items-center gap-0.5 text-[10px] font-semibold text-primary hover:opacity-80"
                          >
                            게시물 <ExternalLink className="h-2.5 w-2.5" />
                          </a>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="hidden max-w-[200px] md:table-cell">
                      <div className="truncate text-sm">{c.product || "—"}</div>
                      <div className="text-[11px] text-muted-foreground">{c.dealType || "—"}</div>
                    </TableCell>
                    <TableCell className="max-w-[140px] md:max-w-[320px]">
                      <div className="flex min-w-0 items-center gap-1.5">
                        <code className="min-w-0 truncate rounded bg-muted px-1.5 py-0.5 text-[11px]">
                          {c.wlCode.replace(/\s+/g, " ")}
                        </code>
                        <CopyButton text={c.wlCode} />
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      {c.wlAdIds.length > 0 ? (
                        <>
                          <Badge className="text-[10px]">집행 중 {c.wlAdIds.length}개</Badge>
                          <div className="mt-0.5 text-[11px] tabular-nums text-muted-foreground">
                            {fmtWon(c.wlSpendKrw)}
                          </div>
                        </>
                      ) : (
                        <Badge variant="secondary" className="text-[10px]">미집행</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">코드 없는 콜라보 ({declined.length + missing.length})</CardTitle>
            <p className="text-xs text-muted-foreground">× = 미발급/거절 표기 · 공란 = 아직 미입력</p>
          </CardHeader>
          <CardContent>
            {declined.length + missing.length === 0 ? (
              <div className="flex flex-col items-center gap-2 py-4 text-muted-foreground">
                <Monkey mood="tongue" size={56} />
                <span className="text-xs">전부 발급 완료</span>
              </div>
            ) : (
              <ul className="grid grid-cols-1 gap-x-6 gap-y-1.5 sm:grid-cols-2 md:grid-cols-3">
                {[...declined, ...missing].map((c, i) => (
                  <li key={`${c.creatorId}-${i}`} className="flex min-w-0 items-center justify-between gap-2 text-sm">
                    <Link
                      href={`/influencers/${encodeURIComponent(c.igHandle)}`}
                      className="min-w-0 truncate hover:opacity-80"
                    >
                      @{c.igHandle}
                    </Link>
                    <Badge variant={codeStatus(c) === "declined" ? "secondary" : "outline"} className="shrink-0 text-[10px]">
                      {codeStatus(c) === "declined" ? "×" : "공란"}
                    </Badge>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </>
    );
  } catch (e) {
    body = <EnvWarning error={e instanceof Error ? e.message : String(e)} />;
  }
  return <div className="space-y-6">{body}</div>;
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <Card className="border-border/60 bg-card/80">
      <CardContent className="p-3">
        <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className="mt-1 text-base font-bold tabular-nums sm:text-lg">{value}</div>
      </CardContent>
    </Card>
  );
}
