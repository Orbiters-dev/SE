// Simple cookie-based password gate. Single user only.
// HMAC signed cookie to prevent tampering — no DB / no session store.

import "server-only";
import { createHmac, timingSafeEqual } from "node:crypto";

const SESSION_COOKIE = "meta_app_session";
const SESSION_TTL_DAYS = 30;

function getSecret(): string {
  const s = process.env.APP_SESSION_SECRET;
  if (!s || s.length < 16) {
    throw new Error("APP_SESSION_SECRET missing or too short (min 16 chars)");
  }
  return s;
}

function getPassword(): string {
  const p = process.env.APP_PASSWORD;
  if (!p) throw new Error("APP_PASSWORD missing");
  return p;
}

function sign(payload: string): string {
  return createHmac("sha256", getSecret()).update(payload).digest("hex");
}

export function makeSessionCookie(): { value: string; maxAge: number } {
  const exp = Date.now() + SESSION_TTL_DAYS * 86_400_000;
  const payload = `v1.${exp}`;
  const sig = sign(payload);
  return {
    value: `${payload}.${sig}`,
    maxAge: SESSION_TTL_DAYS * 86_400,
  };
}

export function verifySessionCookie(raw: string | undefined): boolean {
  if (!raw) return false;
  const parts = raw.split(".");
  if (parts.length !== 3) return false;
  const [v, expStr, sig] = parts;
  if (v !== "v1") return false;
  const exp = Number(expStr);
  if (!Number.isFinite(exp) || exp < Date.now()) return false;
  const expectedSig = sign(`${v}.${expStr}`);
  const a = Buffer.from(sig, "hex");
  const b = Buffer.from(expectedSig, "hex");
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

export function checkPassword(input: string): boolean {
  const expected = getPassword();
  const a = Buffer.from(input);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

export const SESSION_COOKIE_NAME = SESSION_COOKIE;
