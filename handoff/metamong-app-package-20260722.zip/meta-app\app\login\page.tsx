"use client";

import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Monkey } from "@/components/meta/Monkey";

export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}

function LoginForm() {
  const router = useRouter();
  const search = useSearchParams();
  const next = search.get("next") || "/";
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password, next }),
      });
      if (!res.ok) {
        setError("비밀번호가 틀려요");
        setLoading(false);
        return;
      }
      router.replace(next);
      router.refresh();
    } catch {
      setError("로그인 실패");
      setLoading(false);
    }
  }

  const mood = error ? "angry" : password ? "shy" : "happy";

  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <form
        onSubmit={onSubmit}
        className="w-full max-w-sm space-y-6 rounded-3xl border border-border/60 bg-card/90 p-8 shadow-xl backdrop-blur-md"
      >
        <div className="flex flex-col items-center gap-2 text-center">
          <Monkey mood={mood} size={88} />
          <div>
            <h1 className="text-lg font-bold tracking-tight">메타몽</h1>
            <p className="mt-0.5 text-xs text-muted-foreground">Grosmimi JP 광고 대시보드</p>
          </div>
        </div>
        <div className="space-y-2">
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoFocus
            autoComplete="current-password"
            placeholder="비밀번호"
            className="w-full rounded-full border border-input bg-background px-4 py-2.5 text-center text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/30"
          />
          {error && <p className="text-center text-xs font-semibold text-[var(--bad-fg)]">{error}</p>}
        </div>
        <button
          type="submit"
          disabled={loading || !password}
          className="w-full rounded-full bg-primary py-2.5 text-sm font-bold text-primary-foreground shadow-sm transition hover:opacity-90 disabled:opacity-40"
        >
          {loading ? "확인 중..." : "들어가기"}
        </button>
      </form>
    </div>
  );
}
