"use client";

// 오늘의 운영 변경 공지 (2026-06-30, 24h 한정) — 세은 운영 반영.
// 표시 게이트(시간·dismiss)는 AnnouncementStack이 관리. 여기는 표시 전용.
// ~2026-07-02 00:00 KST 자동 미표시. X 닫기 = 같은 탭 세션 동안 다시 안 뜸.

import type { ReactNode } from "react";
import { X } from "lucide-react";
import { Monkey } from "@/components/meta/Monkey";
import { cn } from "@/lib/utils";

export const TODAY_OPS_SHOW_UNTIL_UTC = Date.UTC(2026, 5, 29, 15, 0, 0); // 만료 처리 (2026-07-01 세은 지시로 팝업 제거)
export const TODAY_OPS_DISMISS_KEY = "today_ops_20260630_dismissed";

interface OpsCard {
  tag: string;
  tone: "decision" | "info";
  title: string;
  bullets: ReactNode[];
}

const CARDS: OpsCard[] = [
  {
    tag: "완료",
    tone: "decision",
    title: "Stainless Proven Ad Set 예산 세팅",
    bullets: [
      <>
        Ad Set 일예산 <b>₩160,000</b> 세팅 완료
      </>,
      <>
        PPSU : Stainless Proven 예산 비율 <b>1 : 4</b>
      </>,
    ],
  },
  {
    tag: "확인",
    tone: "info",
    title: "Off 후보 대상 없음",
    bullets: [
      <>
        D+3 게이트 기준 OFF 대상 <b>0건</b>
      </>,
    ],
  },
  {
    tag: "완료",
    tone: "decision",
    title: "PPSU Proven 졸업 이동",
    bullets: [
      <>
        <b>NEE_AND_TWINS</b> 졸업 → PPSU Proven 이동
      </>,
      <>
        Testing 성과 — CTR <b>11.1%</b> · CPC <b>₩74</b> · CPLPV <b>₩89</b> (게이트 3축 통과)
      </>,
      <>
        <a
          href="https://meta-app-one.vercel.app/ads/120249165031260223"
          target="_blank"
          rel="noreferrer"
          className="font-semibold text-primary underline underline-offset-2"
        >
          광고 상세 바로가기
        </a>
        {" · "}
        <a
          href="https://www.instagram.com/p/DZwq7J_jJOv/"
          target="_blank"
          rel="noreferrer"
          className="font-semibold text-primary underline underline-offset-2"
        >
          게시물
        </a>
      </>,
    ],
  },
];

export function TodayOpsAnnouncement({ onClose }: { onClose: () => void }) {
  const dismiss = () => {
    sessionStorage.setItem(TODAY_OPS_DISMISS_KEY, "1");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={dismiss} />
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-border bg-background shadow-2xl">
        <button
          onClick={dismiss}
          aria-label="닫기"
          className="absolute right-3 top-3 rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <X className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-3 border-b border-border/60 bg-secondary/40 px-5 py-4">
          <Monkey mood="rich" size={48} />
          <div>
            <div className="text-base font-bold tracking-tight">오늘의 운영 변경</div>
            <div className="text-xs text-muted-foreground">2026-06-30 · 메타몽</div>
          </div>
        </div>
        <div className="max-h-[60vh] space-y-3 overflow-y-auto px-5 py-4">
          {CARDS.map((c, ci) => (
            <div key={ci} className="rounded-xl border border-border/60 bg-secondary/30 px-4 py-3">
              <span
                className={cn(
                  "mb-2 inline-block rounded-md px-2 py-0.5 text-[11px] font-bold",
                  c.tone === "decision" && "bg-emerald-100 text-emerald-700",
                  c.tone === "info" && "bg-secondary text-muted-foreground",
                )}
              >
                {c.tag}
              </span>
              <div className="mb-1.5 text-sm font-bold">{c.title}</div>
              <ul className="list-disc space-y-1 pl-4">
                {c.bullets.map((b, i) => (
                  <li key={i} className="text-[13px] leading-relaxed text-foreground/80">
                    {b}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
