import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface Props {
  label: string;
  value: string;
  deltaPct?: number | null;
  hint?: string;
  invertColor?: boolean;  // true = lower is better
}

export function KpiCard({ label, value, deltaPct, hint, invertColor }: Props) {
  const showDelta = typeof deltaPct === "number" && Number.isFinite(deltaPct);
  let tone: "neutral" | "good" | "bad" = "neutral";
  if (showDelta && Math.abs(deltaPct!) >= 0.1) {
    const isPositive = deltaPct! > 0;
    const isGood = invertColor ? !isPositive : isPositive;
    tone = isGood ? "good" : "bad";
  }
  return (
    <Card className="border-border/60 bg-card/80 backdrop-blur-sm">
      <CardContent className="p-4">
        <div className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
          {label}
        </div>
        <div className="mt-1.5 text-2xl font-bold tabular-nums text-foreground">
          {value}
        </div>
        <div className="mt-1.5 flex items-center gap-2 text-xs">
          {showDelta && (
            <span
              className={cn(
                "rounded-full px-2 py-0.5 text-[11px] font-semibold tabular-nums",
                tone === "good" && "bg-[var(--good-bg)] text-[var(--good-fg)]",
                tone === "bad" && "bg-[var(--bad-bg)] text-[var(--bad-fg)]",
                tone === "neutral" && "bg-muted text-muted-foreground",
              )}
            >
              {deltaPct! > 0 ? "▲" : deltaPct! < 0 ? "▼" : "▬"} {Math.abs(deltaPct!).toFixed(1)}%
            </span>
          )}
          {hint && <span className="text-muted-foreground">{hint}</span>}
        </div>
      </CardContent>
    </Card>
  );
}
