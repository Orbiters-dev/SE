import { cn } from "@/lib/utils";

export type Tone = "good" | "warn" | "bad" | "neutral";

export function StatusPill({
  children, tone = "neutral", className,
}: {
  children: React.ReactNode;
  tone?: Tone;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-semibold tabular-nums",
        tone === "good" && "bg-[var(--good-bg)] text-[var(--good-fg)]",
        tone === "bad" && "bg-[var(--bad-bg)] text-[var(--bad-fg)]",
        tone === "warn" && "bg-accent text-accent-foreground",
        tone === "neutral" && "bg-muted text-muted-foreground",
        className,
      )}
    >
      {children}
    </span>
  );
}

export function SpendBar({ value, max }: { value: number; max: number }) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  return (
    <div className="relative h-1.5 w-full overflow-hidden rounded-full bg-muted">
      <div
        className="absolute inset-y-0 left-0 rounded-full bg-primary/80"
        style={{ width: `${pct}%` }}
      />
    </div>
  );
}

export function RankBadge({ rank, tone = "neutral" }: { rank: number; tone?: Tone }) {
  const isMedal = rank <= 3;
  const symbol = rank === 1 ? "1" : rank === 2 ? "2" : rank === 3 ? "3" : String(rank);
  return (
    <span
      className={cn(
        "inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold",
        isMedal && tone === "good" && "bg-primary text-primary-foreground shadow-sm",
        isMedal && tone === "bad" && "bg-[var(--bad)] text-white shadow-sm",
        !isMedal && "bg-muted text-muted-foreground",
      )}
    >
      {symbol}
    </span>
  );
}
