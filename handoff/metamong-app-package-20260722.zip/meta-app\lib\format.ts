// Port of fmt_won / fmt_pct / fmt_num / to_float from tools/meta_jp_daily.py L135-154.

export function toFloat(v: unknown, fallback = 0): number {
  if (v === null || v === undefined || v === "") return fallback;
  const n = typeof v === "number" ? v : Number(v);
  return Number.isFinite(n) ? n : fallback;
}

// 단위 룰 (2026-06-10 세은 지시 v2): view·노출 등 "개수"만 ≥1M → M / ≥1K → K. 금액(₩)은 풀 자릿수.
function trimZeros(s: string): string {
  return s.includes(".") ? s.replace(/\.?0+$/, "") : s;
}

export function fmtCompact(v: unknown): string {
  const n = toFloat(v);
  const abs = Math.abs(n);
  if (abs >= 1_000_000) return `${trimZeros((n / 1_000_000).toFixed(2))}M`;
  if (abs >= 100_000) return `${Math.round(n / 1_000)}K`;
  if (abs >= 1_000) return `${trimZeros((n / 1_000).toFixed(1))}K`;
  return String(Math.round(n));
}

export function fmtWon(v: unknown): string {
  return `₩${Math.round(toFloat(v)).toLocaleString("en-US")}`;
}

export function fmtPct(v: unknown, decimals = 2): string {
  return `${toFloat(v).toFixed(decimals)}%`;
}

export function fmtNum(v: unknown, decimals = 0): string {
  const n = toFloat(v);
  return decimals === 0
    ? fmtCompact(n)
    : n.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

export function fmtDelta(curr: number, prev: number, decimals = 1): string {
  if (prev === 0) return curr === 0 ? "0%" : "+∞";
  const d = ((curr - prev) / prev) * 100;
  const sign = d > 0 ? "+" : "";
  return `${sign}${d.toFixed(decimals)}%`;
}

export function deltaPct(curr: number, prev: number): number {
  if (prev === 0) return 0;
  return ((curr - prev) / prev) * 100;
}

export function isoDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

export function daysAgo(n: number, base = new Date()): Date {
  const d = new Date(base);
  d.setUTCDate(d.getUTCDate() - n);
  return d;
}
