// SERVER-ONLY. "오늘의 이슈" 감지 — 당일(KST) 신규 등록 광고 + Testing→Proven 졸업 광고.
//
// 감지 룰:
//   졸업 = 오늘 created + Proven adset 소속 + 동일 ad_name이 Testing adset에 기존 존재
//          (졸업 메커니즘 (b) "Testing pause + Proven 새 ad_id" 기준.
//           rename 방식 (a)는 created_time이 안 바뀌어 감지 불가 — 한계)
//   신규 = 오늘 created 중 졸업으로 분류 안 된 것 → 영상 permalink 첨부 (바로가기 버튼용)
// 졸업 항목엔 졸업 근거 데이터 동봉: 직전 7d Testing adset 내 triple share + CTR + 누적 spend.
// (2026-06-11 세은 지시: issues_info 경고는 표시하지 않는다 — 데이터에서도 제외)

import "server-only";
// 광고 성과·permalink 는 DK. 단 "오늘 등록" 감지는 created_time(DK 미보관)이 필요해 apiGet(Graph) 유지.
import { fetchAdCreatives } from "./dk-meta";
import { apiGet, extractLpv } from "./meta-api";
import { toFloat } from "./format";
import { KPI_WL_CTR } from "./meta-constants";

const ACCT = process.env.META_JP_AD_ACCOUNT_ID;

export interface NewAd {
  ad_id: string;
  name: string;
  adset_name: string;
  status: string;
  permalink: string | null; // IG 영상 바로가기
}

export interface GraduatedAd {
  ad_id: string;
  name: string;
  adset_name: string;       // 새 Proven adset
  from_adset: string;       // 기존 Testing adset
  spend_lifetime: number;   // 졸업 전 누적 (₩)
  spend_7d: number;         // 직전 7d (₩)
  ctr_7d: number;           // %
  kpi_ctr: number;          // 성과 게이트 기준 (%)
  share_spend: number;      // 직전 7d Testing adset 내 점유율 (%)
  share_clicks: number;
  share_lpv: number;
}

export interface DailyIssues {
  date: string; // KST YYYY-MM-DD
  newAds: NewAd[];
  graduated: GraduatedAd[];
}

interface RawAd {
  id?: string;
  name?: string;
  status?: string;
  effective_status?: string;
  created_time?: string; // "+0900" 오프셋 (계정 tz Asia/Tokyo)
  adset?: { id?: string; name?: string };
}

function kstDate(offsetDays = 0): string {
  return new Date(Date.now() + 9 * 3600_000 - offsetDays * 86_400_000)
    .toISOString().slice(0, 10);
}

async function graduationStats(twin: RawAd, provenAdsetName: string): Promise<GraduatedAd> {
  const twinId = twin.id ?? "";
  const adsetId = twin.adset?.id ?? "";
  const since = kstDate(7);
  const until = kstDate(1);

  const [lifeRows, poolRows] = await Promise.all([
    apiGet(`${twinId}/insights`, { fields: "spend", date_preset: "maximum", limit: 10 }),
    apiGet(`${adsetId}/insights`, {
      fields: "ad_id,spend,impressions,clicks,actions",
      level: "ad",
      time_range: JSON.stringify({ since, until }),
      limit: 500,
    }),
  ]);

  const spendLifetime = lifeRows.reduce((s, r) => s + toFloat(r.spend), 0);
  let totSpend = 0, totClicks = 0, totLpv = 0;
  let mySpend = 0, myClicks = 0, myLpv = 0, myImpr = 0;
  for (const r of poolRows) {
    const sp = toFloat(r.spend), ck = toFloat(r.clicks);
    const lv = extractLpv(r.actions as { action_type: string; value: string }[] | undefined);
    totSpend += sp; totClicks += ck; totLpv += lv;
    if (r.ad_id === twinId) {
      mySpend = sp; myClicks = ck; myLpv = lv; myImpr = toFloat(r.impressions);
    }
  }
  return {
    ad_id: twinId,
    name: twin.name ?? "",
    adset_name: provenAdsetName,
    from_adset: twin.adset?.name ?? "",
    spend_lifetime: spendLifetime,
    spend_7d: mySpend,
    ctr_7d: myImpr > 0 ? (myClicks / myImpr) * 100 : 0,
    kpi_ctr: KPI_WL_CTR,
    share_spend: totSpend > 0 ? (mySpend / totSpend) * 100 : 0,
    share_clicks: totClicks > 0 ? (myClicks / totClicks) * 100 : 0,
    share_lpv: totLpv > 0 ? (myLpv / totLpv) * 100 : 0,
  };
}

export async function fetchDailyIssues(): Promise<DailyIssues> {
  if (!ACCT) throw new Error("META_JP_AD_ACCOUNT_ID missing in env");
  const ads = (await apiGet(`${ACCT}/ads`, {
    fields: "id,name,status,effective_status,created_time,adset{id,name}",
    limit: 500,
  })) as RawAd[];

  const date = kstDate();
  // created_time 문자열은 계정 tz(+0900) 오프셋 포함 → 앞 10자가 곧 KST 날짜
  const createdToday = ads.filter((a) => (a.created_time ?? "").slice(0, 10) === date);

  const graduated: GraduatedAd[] = [];
  const rawNew: RawAd[] = [];
  for (const a of createdToday) {
    const inProven = /proven/i.test(a.adset?.name ?? "");
    const twin = inProven
      ? ads.find((b) => b.id !== a.id && b.name === a.name && /test/i.test(b.adset?.name ?? ""))
      : undefined;
    if (twin) {
      graduated.push(await graduationStats(twin, a.adset?.name ?? ""));
    } else {
      rawNew.push(a);
    }
  }

  const permalinks = await fetchAdCreatives(rawNew.map((a) => a.id ?? "").filter(Boolean));
  const newAds: NewAd[] = rawNew.map((a) => ({
    ad_id: a.id ?? "",
    name: a.name ?? "",
    adset_name: a.adset?.name ?? "",
    status: a.effective_status ?? a.status ?? "",
    permalink: permalinks.get(a.id ?? "") ?? null,
  }));

  return { date, newAds, graduated };
}
