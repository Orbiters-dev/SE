// SERVER-ONLY. Google Sheets CSV export (public sheet, no auth).
// SSOT for influencer roster + collab terms + qualitative scores.

import "server-only";
import { parse } from "csv-parse/sync";

const SHEET_ID = process.env.SHEET_ID || "1wkue4G7FP_fiVeqSmMp7Z6IsIMmvOIc93TBb0NwcAmU";

const GID_MASTER = 0;
const GID_GROSMIMI = 386147805;

// 콘텐츠 자동 태그 (별도 시트: JP Influencer Tracker → Content Tags (JP) 탭)
const TAG_SHEET_ID = process.env.TAG_SHEET_ID || "13S1cST2ukuNNHNUmyXAr1HuaYPsuuK_EfUQ10IWIQsE";
const TAG_GID = Number(process.env.TAG_GID ?? 699625745);

function csvUrl(gid: number): string {
  return `https://docs.google.com/spreadsheets/d/${SHEET_ID}/export?format=csv&gid=${gid}`;
}

async function fetchCsv(gid: number, revalidate = 60): Promise<string[][]> {
  const res = await fetch(csvUrl(gid), { next: { revalidate } });
  if (!res.ok) throw new Error(`Sheet ${gid} fetch ${res.status}`);
  const text = await res.text();
  return parse(text, {
    relax_column_count: true,
    skip_empty_lines: false,
  }) as string[][];
}

// ── Master DB tab ──
export interface MasterRow {
  creatorId: string;       // C-N
  fullName: string;
  babyInfo: string;
  igHandle: string;        // col 16
  igFollowers: string;
  igAvgViews: string;
  creatorType: string;
  complianceRating: string;
  overallRating: string;   // col 32
  pic: string;
  status: string;
  recentContact: string;
  recentRate: string;
}

export async function fetchMaster(): Promise<MasterRow[]> {
  const rows = await fetchCsv(GID_MASTER);
  const data = rows.slice(2).filter((r) => (r[0] ?? "").trim());
  return data.map((r) => ({
    creatorId: (r[0] ?? "").trim(),
    fullName: (r[2] ?? "").trim(),
    babyInfo: (r[7] ?? "").trim(),
    igHandle: (r[16] ?? "").trim().replace(/^@/, ""),
    igFollowers: (r[18] ?? "").trim(),
    igAvgViews: (r[20] ?? "").trim(),
    creatorType: (r[29] ?? "").trim(),
    complianceRating: (r[31] ?? "").trim(),
    overallRating: (r[32] ?? "").trim(),
    pic: (r[33] ?? "").trim(),
    status: (r[35] ?? "").trim(),
    recentContact: (r[36] ?? "").trim(),
    recentRate: (r[37] ?? "").trim(),
  }));
}

// ── Grosmimi collab tab ──
export interface CollabRow {
  period: string;         // 운영기간
  internalId: string;
  creatorName: string;
  creatorId: string;      // IG @ID — join key with Master.igHandle
  platform: string;
  deliverableType: string;
  product: string;
  pic: string;
  status: string;
  expectedUpload: string;
  wlCode: string;
  url: string;
  postShortcode: string | null;  // derived from url
  conceptType: string;
  dealType: string;       // Paid / Unpaid
  feeJpy: number;         // numeric
  feeRaw: string;
  commissionRate: string;
  adCode: string;
  whitelistingDuration: string;
  paymentStatus: string;
  paymentDate: string;
  // Performance Evaluation (qualitative, 6 axes)
  scriptFollow: string;
  compliance: string;
  easeOfWork: string;
  hook: string;
  wowScene: string;
  overall: string;        // col 42 — primary Tier-2 signal
  hookType: string;       // col 43 (44번째 열) — 수동 태깅: 훅 유형 (신규)
}

const SHORTCODE_RE = /\/(reel|p|tv)\/([A-Za-z0-9_-]+)/;
function extractShortcode(url: string): string | null {
  const m = url.match(SHORTCODE_RE);
  return m ? m[2] : null;
}

function parseFee(s: string): number {
  if (!s) return 0;
  const cleaned = s.replace(/[^0-9.-]/g, "");
  const n = parseFloat(cleaned);
  return Number.isFinite(n) ? n : 0;
}

// ── Content Tags (auto-tagged, tools/tag_jp_content.py 산출 + 앱 수동 override) ──
export interface ContentTag {
  postId: string;
  shortcode: string;
  kmPrimary: string;       // S##_F## (자동)
  kmPrimaryDesc: string;
  kmSub: string;
  hookPrimary: string;     // 자동 태그 코드 — 구 H## (자동 태거 v2 미전환)
  hookPrimaryName: string;
  confidence: string;      // 高 / 中 / 低
  evidence: string;
  kmManual: string[];      // S##_F## 목록 — 앱 드롭다운 수동 선택, comma 저장 (자동보다 우선)
  hookManual: string[];    // HV-##/HC-## 목록 (구 H## 혼재 허용) — 〃
  kmAutoRejected: boolean; // km_manual = "-" 센티널: 자동 KM 오분류 기각 (미분류 취급, 집계 제외)
}

// shortcode → tag. 헤더명 기준(컬럼 이동 안전) + 라벨("S06_F06 설명")에서 코드 추출.
// 시트 비공개/미배포 시 호출부에서 catch (페이지는 떠야 함).
export async function fetchContentTags(): Promise<Map<string, ContentTag>> {
  const url = `https://docs.google.com/spreadsheets/d/${TAG_SHEET_ID}/export?format=csv&gid=${TAG_GID}`;
  const res = await fetch(url, { next: { revalidate: 60 } });
  if (!res.ok) throw new Error(`Tag sheet fetch ${res.status}`);
  const rows = parse(await res.text(), {
    relax_column_count: true, skip_empty_lines: false,
  }) as string[][];
  const map = new Map<string, ContentTag>();
  if (rows.length < 2) return map;

  const hdr = rows[0].map((h) => h.trim());
  const ix = (name: string) => hdr.indexOf(name);
  const c = {
    shortcode: ix("shortcode"), postId: ix("post_id"),
    km: ix("km_primary"), kmSub: ix("km_sub"), hook: ix("hook_primary"),
    conf: ix("confidence"), ev: ix("evidence"),
    kmManual: ix("km_manual"), hookManual: ix("hook_manual"),
  };
  if (c.shortcode < 0) return map;
  const at = (r: string[], i: number) => (i >= 0 ? (r[i] ?? "").trim() : "");
  const codeOf = (v: string, re: RegExp) => v.match(re)?.[0] ?? "";
  const codesOf = (v: string, re: RegExp) =>
    v.split(",").map((s) => codeOf(s.trim(), re)).filter(Boolean);

  for (const r of rows.slice(1)) {
    const shortcode = at(r, c.shortcode);
    if (!shortcode) continue;
    const kmLabel = at(r, c.km);
    const hookLabel = at(r, c.hook);
    const kmManualRaw = at(r, c.kmManual);
    map.set(shortcode, {
      postId: at(r, c.postId),
      shortcode,
      kmPrimary: codeOf(kmLabel, /S\d{2}_F\d{2}/),
      kmPrimaryDesc: kmLabel,             // 라벨 = 코드 + 설명 (그대로 표시)
      kmSub: codeOf(at(r, c.kmSub), /S\d{2}_F\d{2}/),
      hookPrimary: codeOf(hookLabel, /H(?:[VC]-)?\d{2}/),
      hookPrimaryName: hookLabel,
      confidence: at(r, c.conf),
      evidence: at(r, c.ev),
      kmManual: codesOf(kmManualRaw, /S\d{2}_F\d{2}/),
      hookManual: codesOf(at(r, c.hookManual), /H(?:[VC]-)?\d{2}/),
      kmAutoRejected: kmManualRaw === "-",
    });
  }
  return map;
}

// ── 태그 택소노미 (드롭다운 옵션) — Inhouse Content Tracker ──
// KM SSOT (JIAH)_v2: S##(Subject) → S##_F##(Focus) 종속
// 훅 = WL 훅 taxonomy v2 (2026-07-09): 비주얼훅 HV-## / 캡션훅 HC-## 2축.
// (구 Hook Type 탭 H##는 폐기 — 기존 저장값 H##는 읽기 호환만 유지.)
const TAXONOMY_SHEET_ID = "1HnouC4gMRVTcGwGeInJlGJl_W7eNgI_4m63ZDSxzfZY";
const TAXONOMY_KM_GID = 44578416;       // KM SSOT (JIAH)_v2
const TAXONOMY_HOOK_GID = 1298743912;   // WL 훅 taxonomy v2 (HV/HC)

import type { Taxonomy, KmGroup, TaxonomyOption } from "./sheets-types";
export type { Taxonomy, KmGroup, TaxonomyOption } from "./sheets-types";

async function fetchTaxonomyCsv(gid: number): Promise<string[][]> {
  const url = `https://docs.google.com/spreadsheets/d/${TAXONOMY_SHEET_ID}/export?format=csv&gid=${gid}`;
  const res = await fetch(url, { next: { revalidate: 3600 } });
  if (!res.ok) throw new Error(`Taxonomy sheet ${gid} fetch ${res.status}`);
  return parse(await res.text(), { relax_column_count: true, skip_empty_lines: true }) as string[][];
}

// 행을 regex 스캔(컬럼 이동에 견고): 코드 셀 오른쪽 첫 비어있지 않은 셀 = 설명
export async function fetchTaxonomy(): Promise<Taxonomy> {
  const [kmRows, hookRows] = await Promise.all([
    fetchTaxonomyCsv(TAXONOMY_KM_GID),
    fetchTaxonomyCsv(TAXONOMY_HOOK_GID),
  ]);

  const groups = new Map<string, KmGroup>();
  for (const row of kmRows) {
    const cells = row.map((v) => (v ?? "").trim());
    const fi = cells.findIndex((v) => /^S\d{2}_F\d{2}$/.test(v));
    if (fi < 0) continue;
    const focusCode = cells[fi];
    const focusDesc = cells.slice(fi + 1).find(Boolean) ?? "";
    const si = cells.findIndex((v) => /^S\d{2}$/.test(v));
    const subject = si >= 0 ? cells[si] : focusCode.slice(0, 3);
    const subjectName = si >= 0 ? (cells.slice(si + 1, fi).find(Boolean) ?? "") : "";
    let g = groups.get(subject);
    if (!g) { g = { subject, subjectName, options: [] }; groups.set(subject, g); }
    if (!g.options.some((o) => o.code === focusCode)) {
      g.options.push({ code: focusCode, label: focusDesc });
    }
  }

  // 훅 v2 행: Code(HV-##/HC-##) | 그룹 | 훅 이름(KO) | Name(EN) | 설명…
  // 컨셉 섹션(코드 없음)·헤더는 regex 미스매치로 자동 제외.
  const hooks: TaxonomyOption[] = [];
  for (const row of hookRows) {
    const cells = row.map((v) => (v ?? "").trim());
    const hi = cells.findIndex((v) => /^H[VC]-\d{2}$/.test(v));
    if (hi < 0) continue;
    const code = cells[hi];
    if (hooks.some((o) => o.code === code)) continue;
    const axis = code.startsWith("HV") ? "🎬 비주얼훅" : "💬 캡션훅";
    const grp = cells[hi + 1] ?? "";
    const label = cells[hi + 2] || (cells.slice(hi + 1).find(Boolean) ?? "");
    hooks.push({ code, label, group: grp ? `${axis} · ${grp}` : axis });
  }

  if (!groups.size || !hooks.length) {
    throw new Error(`택소노미 로드 실패: KM ${groups.size}그룹 / Hook ${hooks.length}개`);
  }
  return { kmGroups: [...groups.values()], hooks };
}

export async function fetchCollabs(): Promise<CollabRow[]> {
  const rows = await fetchCsv(GID_GROSMIMI);
  // Row 0-2 are headers; data starts at row 3
  const data = rows.slice(3).filter((r) => (r[3] ?? "").trim());
  return data.map((r) => {
    const url = (r[16] ?? "").trim();
    return {
      period: (r[0] ?? "").trim(),
      internalId: (r[1] ?? "").trim(),
      creatorName: (r[2] ?? "").trim(),
      creatorId: (r[3] ?? "").trim().replace(/^@/, ""),
      platform: (r[4] ?? "").trim(),
      deliverableType: (r[5] ?? "").trim(),
      product: (r[6] ?? "").trim(),
      pic: (r[7] ?? "").trim(),
      status: (r[8] ?? "").trim(),
      expectedUpload: (r[13] ?? "").trim(),
      wlCode: (r[15] ?? "").trim(),
      url,
      postShortcode: extractShortcode(url),
      conceptType: (r[17] ?? "").trim(),
      dealType: (r[23] ?? "").trim(),
      feeJpy: parseFee(r[24] ?? ""),
      feeRaw: (r[24] ?? "").trim(),
      commissionRate: (r[25] ?? "").trim(),
      adCode: (r[27] ?? "").trim(),
      whitelistingDuration: (r[29] ?? "").trim(),
      paymentStatus: (r[31] ?? "").trim(),
      paymentDate: (r[32] ?? "").trim(),
      scriptFollow: (r[37] ?? "").trim(),
      compliance: (r[38] ?? "").trim(),
      easeOfWork: (r[39] ?? "").trim(),
      hook: (r[40] ?? "").trim(),
      wowScene: (r[41] ?? "").trim(),
      overall: (r[42] ?? "").trim(),
      hookType: (r[43] ?? "").trim(),
    };
  });
}
