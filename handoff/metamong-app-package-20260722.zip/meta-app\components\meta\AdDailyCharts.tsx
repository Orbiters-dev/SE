"use client";

import {
  Area, AreaChart, Line, LineChart, ResponsiveContainer,
  Tooltip, XAxis, YAxis, CartesianGrid,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { fmtWon, fmtPct, fmtNum, fmtCompact } from "@/lib/format";

export interface DailyPoint {
  date: string;       // yyyy-mm-dd
  spend: number;
  lpv: number;
  clicks: number;
  ctr: number;        // %
  cplpv: number;      // KRW
  frequency: number;
  impressions: number;
  // 누적(적분) — 등록일부터 그날까지 running total 기준
  cumLpv: number;     // 누적 LPV 합
  cumCtr: number;     // 누적 clicks / 누적 impressions × 100
  cumCplpv: number;   // 누적 spend / 누적 LPV
}

const AXIS_STYLE = { fontSize: 10, fill: "var(--muted-foreground)" };

function shortDate(d: string): string {
  return d.slice(5).replace("-", "/");
}

function ChartCard({ title, hint, children }: {
  title: string;
  hint?: string;
  children: React.ReactNode;
}) {
  return (
    <Card>
      <CardHeader className="pb-1">
        <div className="flex items-baseline justify-between">
          <CardTitle className="text-sm">{title}</CardTitle>
          {hint && <span className="text-[10px] text-muted-foreground">{hint}</span>}
        </div>
      </CardHeader>
      <CardContent className="pl-0 pr-3">
        <div className="h-[170px] w-full">{children}</div>
      </CardContent>
    </Card>
  );
}

function tooltipStyle() {
  return {
    contentStyle: {
      background: "var(--card)",
      border: "1px solid var(--border)",
      borderRadius: 12,
      fontSize: 12,
    },
    labelStyle: { color: "var(--muted-foreground)", fontSize: 11 },
  };
}

export function AdDailyCharts({ data }: { data: DailyPoint[] }) {
  const common = {
    data,
    margin: { top: 4, right: 4, bottom: 0, left: 0 },
  };
  const xAxis = (
    <XAxis
      dataKey="date"
      tickFormatter={shortDate}
      tick={AXIS_STYLE}
      tickLine={false}
      axisLine={false}
      minTickGap={28}
    />
  );
  const grid = <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />;

  return (
    <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
      <ChartCard title="Spend (일별)" hint="₩">
        <ResponsiveContainer>
          <AreaChart {...common}>
            {grid}
            {xAxis}
            <YAxis tick={AXIS_STYLE} tickLine={false} axisLine={false} width={52} tickFormatter={(v: number) => fmtCompact(v)} />
            <Tooltip {...tooltipStyle()} formatter={(v) => [fmtWon(v as number), "Spend"]} labelFormatter={(l) => shortDate(String(l))} />
            <Area type="monotone" dataKey="spend" stroke="var(--primary)" fill="var(--primary)" fillOpacity={0.18} strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="LPV (일별)" hint="랜딩페이지 뷰">
        <ResponsiveContainer>
          <AreaChart {...common}>
            {grid}
            {xAxis}
            <YAxis tick={AXIS_STYLE} tickLine={false} axisLine={false} width={44} tickFormatter={(v: number) => fmtNum(v)} />
            <Tooltip {...tooltipStyle()} formatter={(v) => [fmtNum(v as number), "LPV"]} labelFormatter={(l) => shortDate(String(l))} />
            <Area type="monotone" dataKey="lpv" stroke="var(--chart-2, #8a6f4d)" fill="var(--chart-2, #8a6f4d)" fillOpacity={0.18} strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="CTR (일별)" hint="%">
        <ResponsiveContainer>
          <LineChart {...common}>
            {grid}
            {xAxis}
            <YAxis tick={AXIS_STYLE} tickLine={false} axisLine={false} width={40} tickFormatter={(v: number) => `${v}%`} />
            <Tooltip {...tooltipStyle()} formatter={(v) => [fmtPct(v as number), "CTR"]} labelFormatter={(l) => shortDate(String(l))} />
            <Line type="monotone" dataKey="ctr" stroke="var(--primary)" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="CPLPV (일별)" hint="낮을수록 좋음">
        <ResponsiveContainer>
          <LineChart {...common}>
            {grid}
            {xAxis}
            <YAxis tick={AXIS_STYLE} tickLine={false} axisLine={false} width={48} tickFormatter={(v: number) => `₩${fmtNum(v)}`} />
            <Tooltip {...tooltipStyle()} formatter={(v) => [fmtWon(v as number), "CPLPV"]} labelFormatter={(l) => shortDate(String(l))} />
            <Line type="monotone" dataKey="cplpv" stroke="var(--chart-2, #8a6f4d)" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Frequency (일별)" hint="피로도 임계 2.5">
        <ResponsiveContainer>
          <LineChart {...common}>
            {grid}
            {xAxis}
            <YAxis tick={AXIS_STYLE} tickLine={false} axisLine={false} width={36} domain={[0, "auto"]} />
            <Tooltip {...tooltipStyle()} formatter={(v) => [(v as number).toFixed(2), "Freq"]} labelFormatter={(l) => shortDate(String(l))} />
            <Line type="monotone" dataKey="frequency" stroke="var(--primary)" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="노출 (일별)" hint="Impressions">
        <ResponsiveContainer>
          <AreaChart {...common}>
            {grid}
            {xAxis}
            <YAxis tick={AXIS_STYLE} tickLine={false} axisLine={false} width={48} tickFormatter={(v: number) => fmtCompact(v)} />
            <Tooltip {...tooltipStyle()} formatter={(v) => [fmtNum(v as number), "노출"]} labelFormatter={(l) => shortDate(String(l))} />
            <Area type="monotone" dataKey="impressions" stroke="var(--chart-2, #8a6f4d)" fill="var(--chart-2, #8a6f4d)" fillOpacity={0.18} strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      <div className="md:col-span-2 pt-2 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
        누적 (적분) — 등록일부터 그날까지 합산 기준
      </div>

      <ChartCard title="LPV (누적)" hint="등록일부터 합산">
        <ResponsiveContainer>
          <AreaChart {...common}>
            {grid}
            {xAxis}
            <YAxis tick={AXIS_STYLE} tickLine={false} axisLine={false} width={52} tickFormatter={(v: number) => fmtCompact(v)} />
            <Tooltip {...tooltipStyle()} formatter={(v) => [fmtNum(v as number), "누적 LPV"]} labelFormatter={(l) => shortDate(String(l))} />
            <Area type="monotone" dataKey="cumLpv" stroke="var(--chart-2, #8a6f4d)" fill="var(--chart-2, #8a6f4d)" fillOpacity={0.18} strokeWidth={2} />
          </AreaChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="CTR (누적)" hint="누적 clicks / 누적 노출">
        <ResponsiveContainer>
          <LineChart {...common}>
            {grid}
            {xAxis}
            <YAxis tick={AXIS_STYLE} tickLine={false} axisLine={false} width={40} tickFormatter={(v: number) => `${v}%`} />
            <Tooltip {...tooltipStyle()} formatter={(v) => [fmtPct(v as number), "누적 CTR"]} labelFormatter={(l) => shortDate(String(l))} />
            <Line type="monotone" dataKey="cumCtr" stroke="var(--primary)" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="CPLPV (누적)" hint="누적 spend / 누적 LPV · 낮을수록 좋음">
        <ResponsiveContainer>
          <LineChart {...common}>
            {grid}
            {xAxis}
            <YAxis tick={AXIS_STYLE} tickLine={false} axisLine={false} width={48} tickFormatter={(v: number) => `₩${fmtNum(v)}`} />
            <Tooltip {...tooltipStyle()} formatter={(v) => [fmtWon(v as number), "누적 CPLPV"]} labelFormatter={(l) => shortDate(String(l))} />
            <Line type="monotone" dataKey="cumCplpv" stroke="var(--chart-2, #8a6f4d)" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  );
}
