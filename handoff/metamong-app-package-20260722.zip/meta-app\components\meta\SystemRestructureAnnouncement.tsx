"use client";

// WL 광고 시스템 개편 공지 (2026-06-18 · 메타몽).
// 6/19 실행 예정: OFF 정리 → Proven 승급 → Testing 1:1 재세팅. 총 일예산 ₩300,000.
// 노출 ~6/20 00:00 KST → 이후 자동 미표시. X 닫기 = 같은 탭 세션 동안 미표시 (sessionStorage).
// 표시 게이트(시간·dismiss)는 AnnouncementStack이 관리 — 여기는 표시 전용.
// 금액 KRW 통일 · 줄글 X 카드/칩 (메타몽 팝업 룰).

import type { ReactNode } from "react";
import { X } from "lucide-react";
import { Monkey } from "@/components/meta/Monkey";
import { cn } from "@/lib/utils";

export const SYSTEM_RESTRUCTURE_SHOW_UNTIL_UTC = Date.UTC(2026, 5, 19, 15, 0, 0); // 2026-06-20 00:00 KST
export const SYSTEM_RESTRUCTURE_DISMISS_KEY = "system_restructure_20260618_dismissed";

interface Chip {
  label: string;
  value: string;
  tone: "bad" | "good" | "flat";
}

interface Card {
  tag: string;
  tone: "result" | "decision" | "info";
  title: string;
  chips?: Chip[];
  bullets?: ReactNode[];
}

const CARDS: Card[] = [
  {
    tag: "결정",
    tone: "decision",
    title: "🔄 6/19 WL 광고 3단계 재편",
    bullets: [
      <>
        ① 게이트 미달 광고 <b>OFF 정리</b>
      </>,
      <>
        ② 졸업 기준 통과 → <b>Proven 승급</b> (Testing PAUSE → 새 ad_id)
      </>,
      <>
        ③ Testing을 <b>소재 1개 = ad set 1개</b> (1:1 분리)로 재세팅
      </>,
    ],
  },
  {
    tag: "결정",
    tone: "decision",
    title: "📦 Proven — SKU별 1 ad set 통합",
    chips: [
      { label: "Stainless", value: "₩103,000 유지", tone: "flat" },
      { label: "PPSU", value: "₩55K → ₩93K", tone: "good" },
    ],
    bullets: [
      <>
        Stainless는 현행 유지 (CPLPV ₩119 · 졸업선 안쪽)
      </>,
      <>
        PPSU는 <b>19%씩 2~3일 간격</b> 점진 증액 (learning reset 회피)
      </>,
      <>
        각 스텝 <b>CPLPV ₩135 넘으면 정지</b> = 스케일 한계
      </>,
    ],
  },
  {
    tag: "근거",
    tone: "result",
    title: "📊 PPSU 증액 근거 — 효율 우위인데 과소투자",
    chips: [
      { label: "CPLPV", value: "₩109 < ₩119", tone: "good" },
      { label: "CTR", value: "10.4% > 7.7%", tone: "good" },
      { label: "CPC", value: "₩71 < ₩95", tone: "good" },
    ],
    bullets: [
      <>
        PPSU가 <b>전 지표에서 Stainless보다 우위</b>인데 예산은 절반(55K vs 103K)
      </>,
      <>
        → 대칭 맞추기가 아니라 <b>과소투자 해소</b>가 증액 근거 (7d 실측)
      </>,
    ],
  },
  {
    tag: "결정",
    tone: "decision",
    title: "🧪 Testing 1:1 분리 — ad set당 ₩8,000",
    chips: [
      { label: "Budget", value: "₩8,000 / ad set", tone: "good" },
      { label: "방식", value: "개수 우선", tone: "flat" },
    ],
    bullets: [
      <>
        ₩8,000 × 3일 = D+3 LPV <b>189</b> (학습 임계 50의 3.8배) → 표본 충분
      </>,
      <>
        초과 예산은 효과 체감 → 같은 돈이면 <b>소재 개수↑</b>가 발굴에 이득
      </>,
      <>
        가용 소재 13개 미만이면 차액은 Proven으로 (억지 증액 X)
      </>,
    ],
  },
];

// 히어로: 일예산 ₩300,000 구조
const HERO = {
  total: "₩300,000",
  sub: "일예산 · 6/19 재편 후",
  lanes: [
    { label: "Proven Stainless", value: "₩103K" },
    { label: "Proven PPSU", value: "→ ₩93K" },
    { label: "Testing ×N", value: "₩8K씩" },
  ],
};

export function SystemRestructureAnnouncement({ onClose }: { onClose: () => void }) {
  const dismiss = () => {
    sessionStorage.setItem(SYSTEM_RESTRUCTURE_DISMISS_KEY, "1");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={dismiss} />
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-border bg-background shadow-2xl">
        <button
          onClick={dismiss}
          aria-label="닫기"
          className="absolute right-3 top-3 rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <X className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-3 border-b border-border/60 bg-secondary/40 px-5 py-4">
          <Monkey mood="teacher" size={48} />
          <div>
            <div className="text-base font-bold tracking-tight">WL 광고 시스템 개편</div>
            <div className="text-xs text-muted-foreground">2026-06-18 · 메타몽 · 6/19 실행 예정</div>
          </div>
        </div>

        <div className="max-h-[64vh] space-y-3 overflow-y-auto px-5 py-4">
          {/* 히어로: 일예산 구조 */}
          <div className="rounded-xl border border-border/60 bg-secondary/30 px-4 py-3">
            <div className="mb-2 text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
              일예산 구조
            </div>
            <div className="mb-2 text-center text-3xl font-extrabold tracking-tight text-foreground">
              {HERO.total}
            </div>
            <div className="flex items-stretch gap-2">
              {HERO.lanes.map((lane, i) => (
                <div key={i} className="flex-1 rounded-lg bg-secondary/60 px-2 py-2 text-center">
                  <div className="text-sm font-bold text-foreground">{lane.value}</div>
                  <div className="mt-0.5 text-[10px] leading-tight text-muted-foreground">
                    {lane.label}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-2 text-center text-[12px] text-foreground/70">{HERO.sub}</div>
          </div>

          {CARDS.map((c, ci) => (
            <div key={ci} className="rounded-xl border border-border/60 bg-secondary/30 px-4 py-3">
              <span
                className={cn(
                  "mb-2 inline-block rounded-md px-2 py-0.5 text-[11px] font-bold",
                  c.tone === "decision" && "bg-emerald-100 text-emerald-700",
                  c.tone === "result" && "bg-primary/15 text-primary",
                  c.tone === "info" && "bg-secondary text-muted-foreground",
                )}
              >
                {c.tag}
              </span>
              <div className="mb-1.5 text-sm font-bold">{c.title}</div>
              {c.chips && (
                <div className="mb-2 flex flex-wrap gap-1.5">
                  {c.chips.map((chip, i) => (
                    <span
                      key={i}
                      className={cn(
                        "inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[12px] font-semibold",
                        chip.tone === "bad" && "bg-rose-100 text-rose-700",
                        chip.tone === "good" && "bg-emerald-100 text-emerald-700",
                        chip.tone === "flat" && "bg-secondary text-foreground/70",
                      )}
                    >
                      <span className="text-[10px] font-medium opacity-70">{chip.label}</span>
                      {chip.value}
                    </span>
                  ))}
                </div>
              )}
              {c.bullets && (
                <ul className="list-disc space-y-1 pl-4">
                  {c.bullets.map((b, i) => (
                    <li key={i} className="text-[13px] leading-relaxed text-foreground/80">
                      {b}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
