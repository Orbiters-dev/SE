// 1:1 port from tools/meta_jp_daily.py (lines 45-56).
// Sync rule: SE/memory/feedback_sync_code_when_memory_rule_changes.md
// — when constants change here, update meta_jp_daily.py the same turn.

export const CTR_BENCH = 1.71;      // JP 6-24m mom benchmark (%)
export const CTR_LOW = 1.0;         // Below = candidate for review (%)
export const FREQ_HIGH = 2.5;       // Fatigue threshold (2026-05-22 memory rule)
export const CPC_SPIKE_PCT = 30.0;  // CPC WoW spike alert (%)

// KPI = North Star. Separate from Off Rule (2026-05-15 memory rule).
export const KPI_WL_CTR = 8.0;   // Whitelisting (PAID/GIFT) CTR goal (%)
export const KPI_IMG_CTR = 4.0;  // Image ad (UNKNOWN) CTR goal (%)
export const KPI_CPC = 100;      // CPC goal (KRW)

// WL Testing → Proven 졸업 게이트 (2026-06-16 확정 — 1:1 분리 운영 절대 지표).
// memory/reference_meta_wl_testing_gate_criteria.md. 1:1 분리라 share 무의미 → 개별 절대 지표.
// 졸업 = CPC≤₩95 AND CTR≥8% AND CPLPV≤₩130 (D+3 판정). 실제 졸업생 5개 Testing 시절 중앙값 경계.
// CPLPV 135→130 (2026-07-09 세은 확정, PPSU/Stainless 공통).
export const GRAD_CPC_MAX = 95;      // CPC ≤ ₩95
export const GRAD_CTR_MIN = 8.0;     // CTR ≥ 8%
export const GRAD_CPLPV_MAX = 130;   // CPLPV ≤ ₩130 (2026-07-09 세은: 135→130)
export const GRAD_MIN_DAYS = 3;      // D+3 졸업 판정 시점 (2026-07-06 세은: OFF·졸업 모두 D+3)

// Supersale 2026-06-04 → 06-11. Section auto-hides after this date.
export const SUPERSALE_START = new Date("2026-06-04");
export const SUPERSALE_END = new Date("2026-06-11");
export const BUDGET_RAISE_START = new Date("2026-06-02");

export const META_ACCOUNT_CURRENCY = "KRW" as const;

// Graph API
export const META_GRAPH_BASE = "https://graph.facebook.com/v18.0";

// WL Testing OFF 게이트 (2026-06-16 확정 — D+3 판정). meta_jp_daily.py off_rule_check 와 동기화.
// memory/reference_meta_wl_testing_gate_criteria.md 게이트 1.
// Testing 1:1 분리: CPC≤₩150 AND CTR≥5% → 생존. 나쁘면 CPLPV≥₩190 시 OFF (정상이면 D+5 유예).
export const OFF_D3_CPC_MAX = 150;     // D+3 CPC 나쁨선 (KRW)
export const OFF_D3_CTR_MIN = 5.0;     // D+3 CTR 나쁨선 (%)
export const OFF_D3_CPLPV_OFF = 190;   // D+3 CPLPV OFF 트리거 (이탈형 돈샘, KRW)
export const OFF_MIN_DAYS = 3;         // OFF 판정 시점 D+3

// Proven delivery 실패 게이트 (시간 단독 트리거 X — WL 은 3~6개월 운용).
export const OFF_DELIVERY_DAYS = 90;
export const OFF_DELIVERY_FLOOR = 5_000;  // KRW
