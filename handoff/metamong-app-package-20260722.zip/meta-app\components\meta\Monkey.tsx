import Image from "next/image";
import { cn } from "@/lib/utils";

export type MonkeyMood = "happy" | "dizzy" | "angry" | "shy" | "tongue" | "cry" | "ecstatic" | "joyful" | "rich" | "teacher";

export function Monkey({
  mood = "happy", size = 32, className,
}: {
  mood?: MonkeyMood;
  size?: number;
  className?: string;
}) {
  return (
    <Image
      src={`/monkeys/${mood}.svg`}
      alt={mood}
      width={size}
      height={size}
      className={cn("select-none", className)}
      priority={size >= 60}
    />
  );
}
