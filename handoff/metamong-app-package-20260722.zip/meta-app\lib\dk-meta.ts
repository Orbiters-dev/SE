// SERVER-ONLY. Meta 광고 데이터를 DataKeeper(gk_meta_ads_daily)에서 읽는다.
// meta-api.ts (Graph 직접호출) 를 대체 — 앱은 DK 단일소스에서 읽는다 (2026-07-02 세은 지시).
// tools/meta_jp_daily.py 의 _dk_norm / _dk_aggregate 와 동일 로직.
//
// DK 스키마(gk_meta_ads_daily): campaign/adset/ad id·name, spend, impressions, clicks,
//   reach, frequency, purchases, purchase_value, objective, campaign_type, date,
//   landing_page_view, effective_status, creative_permalink, creative_media_id (후자 4개는 EC2 배포 후 채워짐).

import "server-only";
import { dkQuery } from "./datakeeper";
import { fetchInsights as graphInsights, fetchAdDaily as graphAdDaily, fetchAdStatuses as graphAdStatuses, extractLpv } from "./meta-api";  // 임시 전체이력 보완 + 실시간 status
import type { InsightRow, FetchInsightsOptions, AdInfo } from "./meta-api";

const DK_BRAND = "Grosmimi JP";

const PRESET_DAYS: Record<string, number> = {
  yesterday: 1, last_7d: 7, last_14d: 14, last_30d: 30, last_90d: 90,
};

interface DkMetaRow {
  date: string;
  ad_id: string;
  ad_name: string;
  campaign_id: string;
  campaign_name: string;
  adset_id: string;
  adset_name: string;
  spend: number | string | null;
  impressions: number | string | null;
  clicks: number | string | null;
  reach: number | string | null;
  frequency: number | string | null;
  purchases: number | string | null;
  purchase_value: number | string | null;
  landing_page_view: number | string | null;
  effective_status: string | null;
  creative_permalink: string | null;
  creative_media_id: string | null;
}

function num(v: unknown): number {
  const n = typeof v === "number" ? v : parseFloat(String(v ?? ""));
  return Number.isFinite(n) ? n : 0;
}

// DK row → Graph InsightRow 형식 정규화 (actions 에 LPV/purchase 재구성)
function toInsightRow(r: DkMetaRow): InsightRow {
  const lpv = num(r.landing_page_view);
  const purchases = num(r.purchases);
  const actions: { action_type: string; value: string }[] = [];
  if (lpv) actions.push({ action_type: "landing_page_view", value: String(lpv) });
  if (purchases) actions.push({ action_type: "purchase", value: String(purchases) });
  const spend = num(r.spend), impr = num(r.impressions), clicks = num(r.clicks);
  return {
    campaign_id: r.campaign_id ?? "", campaign_name: r.campaign_name ?? "",
    adset_id: r.adset_id ?? "", adset_name: r.adset_name ?? "",
    ad_id: r.ad_id ?? "", ad_name: r.ad_name ?? "",
    spend: String(spend), impressions: String(impr), clicks: String(clicks),
    ctr: impr > 0 ? String((clicks / impr) * 100) : "0",
    cpc: clicks > 0 ? String(spend / clicks) : "0",
    cpm: impr > 0 ? String((spend / impr) * 1000) : "0",
    frequency: String(num(r.frequency)),
    reach: String(num(r.reach)),
    actions,
    date_start: r.date ?? "", date_stop: r.date ?? "",
  };
}

function resolveRange(opts: FetchInsightsOptions): { since: string; until: string } {
  if (opts.timeRange) return opts.timeRange;
  const n = opts.datePreset ? (PRESET_DAYS[opts.datePreset] ?? 7) : 7;
  // 어제 기준 n일 (Graph date_preset 과 동일)
  const until = new Date();
  until.setUTCDate(until.getUTCDate() - 1);
  const since = new Date(until);
  since.setUTCDate(since.getUTCDate() - (n - 1));
  const iso = (d: Date) => d.toISOString().slice(0, 10);
  return { since: iso(since), until: iso(until) };
}

// 기간 합산 (key 단위) — spend/impr/clicks/reach/lpv/purchase 합산 후 비율 재계산
function aggregate(rows: InsightRow[], keyOf: (r: InsightRow) => string, blankIds: "campaign" | "ad" | "none"): InsightRow[] {
  const groups = new Map<string, InsightRow[]>();
  for (const r of rows) {
    const k = keyOf(r);
    const arr = groups.get(k) ?? [];
    arr.push(r);
    groups.set(k, arr);
  }
  const out: InsightRow[] = [];
  for (const rs of groups.values()) {
    const spend = rs.reduce((s, r) => s + num(r.spend), 0);
    const impr = rs.reduce((s, r) => s + num(r.impressions), 0);
    const clicks = rs.reduce((s, r) => s + num(r.clicks), 0);
    const reach = rs.reduce((s, r) => s + num(r.reach), 0);
    const lpv = rs.reduce((s, r) => s + num(r.actions?.find((a) => a.action_type === "landing_page_view")?.value ?? 0), 0);
    const purch = rs.reduce((s, r) => s + num(r.actions?.find((a) => a.action_type === "purchase")?.value ?? 0), 0);
    const actions: { action_type: string; value: string }[] = [];
    if (lpv) actions.push({ action_type: "landing_page_view", value: String(lpv) });
    if (purch) actions.push({ action_type: "purchase", value: String(purch) });
    const base = { ...rs[rs.length - 1] };
    base.spend = String(spend); base.impressions = String(impr); base.clicks = String(clicks);
    base.reach = String(reach);
    base.ctr = impr > 0 ? String((clicks / impr) * 100) : "0";
    base.cpc = clicks > 0 ? String(spend / clicks) : "0";
    base.cpm = impr > 0 ? String((spend / impr) * 1000) : "0";
    base.frequency = reach > 0 ? String(impr / reach) : "0";
    base.actions = actions;
    if (blankIds === "campaign") { base.ad_id = ""; base.adset_id = ""; base.ad_name = ""; base.adset_name = ""; }
    out.push(base);
  }
  return out;
}

async function loadRows(since: string, until: string): Promise<DkMetaRow[]> {
  return dkQuery<DkMetaRow>("meta_ads_daily", { brand: DK_BRAND, dateFrom: since, dateTo: until, limit: 50000 });
}

// ── 임시 전체이력 보완 (2026-07-02) ──
// DK gk_meta_ads_daily 가 계정 전체 이력(2025-12~)을 다 담지 못함(3/1부터 + 누락) + LPV 컬럼도 없음.
// 그래서 DK 를 base 로 두고 Graph(전 기간 완전) 로 union: DK 에 없는 (ad,date) 행은 Graph 로 채우고,
// DK 에 있는데 LPV 0 이면 Graph LPV 주입. DK 백필+컬럼 완료되면 Graph 는 중복이라 무해 → 나중에 제거.
function injectLpv(r: InsightRow, lpv: number | undefined): InsightRow {
  if (!lpv || lpv <= 0) return r;
  const actions = (r.actions ?? []).filter((a) => a.action_type !== "landing_page_view");
  actions.push({ action_type: "landing_page_view", value: String(lpv) });
  return { ...r, actions };
}

function mergeWithGraph(dkRows: InsightRow[], graphRows: InsightRow[]): InsightRow[] {
  const m = new Map<string, InsightRow>();
  for (const r of dkRows) m.set(`${r.ad_id}|${r.date_start}`, r);
  for (const g of graphRows) {
    const key = `${g.ad_id}|${g.date_start}`;
    const ex = m.get(key);
    if (!ex) m.set(key, g);                                        // DK 에 없는 이력 → Graph 로 채움
    else if (extractLpv(ex.actions) <= 0) m.set(key, injectLpv(ex, extractLpv(g.actions)));  // LPV 보강
  }
  return [...m.values()];
}

// ── meta-api.fetchInsights 대체 ──
export async function fetchInsights(opts: FetchInsightsOptions): Promise<InsightRow[]> {
  const { since, until } = resolveRange(opts);
  const raw = await loadRows(since, until);
  const daily = opts.timeIncrement === 1 || opts.withDaily;
  let norm = raw.map(toInsightRow);
  // 임시: DK 가 전체 이력을 다 안 담아 Graph 로 union (전 기간 완전 반영). 백필 완료되면 제거.
  try {
    const g = await graphInsights({ level: "ad", timeRange: { since, until }, withDaily: true });
    norm = mergeWithGraph(norm, g);
  } catch {
    // Graph 실패 시 DK 만으로 진행
  }

  // 월별 분해 (예산 탭 "월별") — Graph time_increment=monthly 대응. 누락 시 전 기간이
  // 한 덩어리로 합산돼 이번 달로 표기되는 사고 (2026-07-08 세은 발견: 7월 TOTAL 에 전 월 합산).
  if (opts.timeIncrement === "monthly") {
    const monthOf = (r: InsightRow) => (r.date_start ?? "").slice(0, 7);
    if (opts.level === "account") return aggregate(norm, monthOf, "campaign");
    if (opts.level === "campaign") return aggregate(norm, (r) => `${r.campaign_id}|${monthOf(r)}`, "campaign");
    return aggregate(norm, (r) => `${r.ad_id}|${monthOf(r)}`, "none");
  }

  if (opts.level === "account") {
    if (daily) return aggregate(norm, (r) => r.date_start ?? "", "campaign");
    return aggregate(norm, () => "all", "campaign");
  }
  if (opts.level === "campaign") {
    return aggregate(norm, (r) => daily ? `${r.campaign_id}|${r.date_start}` : (r.campaign_id ?? ""), "campaign");
  }
  // ad level
  if (daily) return norm;                                  // 일별 그대로
  return aggregate(norm, (r) => r.ad_id ?? "", "none");    // 기간 합산
}

// ── 광고별 현재상태 raw 테이블 (gk_raw_meta_ad_creative) ──
// effective_status / media_id / permalink 는 일별(meta_ads_daily)이 아니라 이 광고별 테이블에 있다.
// (JP 는 tools/collect_meta_jp_creative.py 적재, US 는 WONGI 크론. 2026-07-06)
interface DkRawCreativeRow {
  ad_id: string;
  effective_status: string | null;
  effective_instagram_media_id: string | null;
  instagram_permalink_url: string | null;
}

async function loadRawCreatives(): Promise<Map<string, DkRawCreativeRow>> {
  const rows = await dkQuery<DkRawCreativeRow>("raw_meta_ad_creative", {
    limit: 50000,
    // 전체 컬럼은 creative 원문 포함 5.6MB (Next data cache 2MB 한도 초과 → 매 렌더 재fetch) → 필요 4개만 0.2MB
    fields: ["ad_id", "effective_status", "effective_instagram_media_id", "instagram_permalink_url"],
  });
  const m = new Map<string, DkRawCreativeRow>();
  for (const r of rows) if (r.ad_id) m.set(r.ad_id, r);
  return m;
}

// ── on/off 상태: Graph 실시간 우선, DK(raw_meta_ad_creative) 는 fallback ──
// DK raw 는 로컬 09:10 push 가 죽으면(2026-07-08~ write 토큰 read 강등 403) stale ACTIVE 로 남아
// 이미 졸업/OFF 한 광고가 후보에 재등장한다 (RHYTHMICAL_MAMA 사고). status 만은 live 가 진실.
export async function fetchAdStatuses(adIds: string[]): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  if (adIds.length === 0) return map;
  try {
    const g = await graphAdStatuses(adIds);
    for (const [id, st] of g) map.set(id, st);
  } catch {
    // Graph 전체 실패 → DK 로 진행 (아래 fallback)
  }
  const missing = adIds.filter((id) => !map.has(id));
  if (missing.length > 0) {
    const raw = await loadRawCreatives();
    for (const id of missing) {
      const st = raw.get(id)?.effective_status ?? "";
      if (st) map.set(id, st);
    }
  }
  return map;
}

// ── creative permalink (DK raw_meta_ad_creative.instagram_permalink_url) ──
export async function fetchAdCreatives(adIds: string[]): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  if (adIds.length === 0) return map;
  const raw = await loadRawCreatives();
  for (const id of adIds) {
    const url = raw.get(id)?.instagram_permalink_url;
    if (url) map.set(id, url);
  }
  return map;
}

// ── ad → 게시자 username: DK 는 media_id 만 보관(username 미보관) → 빈 맵.
//    wl-attribution 은 permalink shortcode / ad_code / handle fallback 으로 매칭 가능.
export async function fetchAdPosterUsernames(_adIds: string[]): Promise<Map<string, string>> {
  return new Map<string, string>();
}

// ── 단일 광고 노드 info (DK 최신행에서 구성, status 는 Graph live) ──
export async function fetchAdInfo(adId: string): Promise<AdInfo | null> {
  const rows = await dkQuery<DkMetaRow>("meta_ads_daily", { brand: DK_BRAND, days: 400, adId, limit: 5000 });
  if (rows.length === 0) return null;
  const sorted = [...rows].sort((a, b) => (a.date ?? "").localeCompare(b.date ?? ""));
  const last = sorted[sorted.length - 1];
  const first = sorted[0];
  // status 는 stale 금지 → live 우선, 실패 시에만 DK raw
  const status = await fetchAdStatuses([adId]);
  let effectiveStatus = status.get(adId) ?? "";
  if (!effectiveStatus) {
    const raw = await dkQuery<DkRawCreativeRow>("raw_meta_ad_creative", { adId, limit: 5 });
    effectiveStatus = raw[0]?.effective_status ?? "";
  }
  return {
    id: adId,
    name: last.ad_name ?? "",
    created_time: first.date ?? "",
    effective_status: effectiveStatus,
    adset: { name: last.adset_name ?? "" },
    campaign: { name: last.campaign_name ?? "" },
  };
}

// ── 단일 광고 일별 시계열 ──
export async function fetchAdDaily(adId: string, since: string, until: string): Promise<InsightRow[]> {
  const raw = await loadRows(since, until);
  const mine = raw.filter((r) => r.ad_id === adId);
  let rows = mine.map(toInsightRow);
  // 임시: DK 누락분 + LPV 를 Graph(해당 광고 전 기간)로 union
  try {
    const g = await graphAdDaily(adId, since, until);
    rows = mergeWithGraph(rows, g);
  } catch {
    // Graph 실패 시 DK 만으로
  }
  return rows.sort((a, b) => (a.date_start ?? "").localeCompare(b.date_start ?? ""));
}
