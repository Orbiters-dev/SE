"use client";

// 오늘의 이슈 — 메타몽 세션 결정 공지 (2026-06-16): WL Testing 3게이트 운영 기준 확정.
// 실행기간 노출 (~6/20 00:00 KST) — 이후 자동 미표시 (코드 제거 불필요).
// X 닫기 = 같은 탭 세션 동안 다시 안 뜸 (sessionStorage).
// 표시 게이트(시간·dismiss)는 AnnouncementStack이 관리 — 여기는 표시 전용.

import type { ReactNode } from "react";
import { X } from "lucide-react";
import { Monkey } from "@/components/meta/Monkey";
import { cn } from "@/lib/utils";

export const TODAY_BRIEF_SHOW_UNTIL_UTC = Date.UTC(2026, 5, 19, 15, 0, 0); // 2026-06-20 00:00 KST
export const TODAY_BRIEF_DISMISS_KEY = "today_brief_20260616_dismissed";

interface BriefChip {
  label: string;
  value: string;
  tone: "bad" | "good";
}

interface BriefQA {
  q: string;
  a: ReactNode;
}

interface BriefCard {
  tag: string;
  tone: "decision" | "progress" | "info";
  title: string;
  chips?: BriefChip[];
  bullets?: ReactNode[];
  qa?: BriefQA[];
}

const CARDS: BriefCard[] = [
  {
    tag: "결정",
    tone: "decision",
    title: "🔴 OFF 게이트 — 효율 미달 끄기 (D+3)",
    chips: [
      { label: "CPC", value: ">₩150", tone: "bad" },
      { label: "CTR", value: "<5%", tone: "bad" },
      { label: "CPLPV", value: ">₩190", tone: "bad" },
    ],
    bullets: [
      <>
        메인 판단 = <b>CPC · CTR</b> / CPLPV는 보조 확인
      </>,
      <>
        CPC · CTR 멀쩡한데 <b>CPLPV만 초과</b> → OFF (클릭 후 이탈형)
      </>,
      <>
        애매한 경계는 <b>D+5까지 한 번 더</b> 보고 판정
      </>,
    ],
  },
  {
    tag: "결정",
    tone: "decision",
    title: "🎓 졸업 게이트 — Proven 승급 (D+7)",
    chips: [
      { label: "CPC", value: "≤₩95", tone: "good" },
      { label: "CTR", value: "≥8%", tone: "good" },
      { label: "CPLPV", value: "≤₩135", tone: "good" },
    ],
    bullets: [
      <>
        <b>세 개 모두 충족</b> 시 Proven 승급
      </>,
      <>
        승급하면 Testing에서 빼고 <b>Proven에 새로 등록</b>
      </>,
    ],
  },
  {
    tag: "결정",
    tone: "decision",
    title: "💰 Budget",
    bullets: [
      <>
        Testing 각 광고 <b>₩8,000/day</b> · 개수 제한 없음
      </>,
      <>Proven 현행 유지</>,
      <>
        분리 시 Testing 예산 ₩131K→₩56K (<b>−₩75K/day · 월 ≈−₩2.25M</b>)
      </>,
    ],
  },
  {
    tag: "참고",
    tone: "info",
    title: "✅ 안전성 검증",
    qa: [
      {
        q: "3일 만에 끄면 너무 이른 판단 아닐까?",
        a: (
          <>
            과거 광고로 확인해보니 <b>3일 성적이 7일 결과를 96% 그대로 예측</b>했어요. 좋은 광고를
            일찍 끊은 사례는 <b>0건</b>.
          </>
        ),
      },
      {
        q: "광고를 끄면 머신러닝(학습)이 망가지지 않을까?",
        a: (
          <>
            우리 캠페인은 <b>트래픽(방문) 최적화</b>라 학습 데이터가 빨리 쌓여요. 3일이면 필요량의{" "}
            <b>6배</b> 확보 → 학습 이미 완료. 게다가 광고마다 <b>따로 운영(1:1)</b>이라, 하나를 꺼도
            다른 광고 학습엔 영향이 없습니다.
          </>
        ),
      },
    ],
  },
  {
    tag: "참고",
    tone: "info",
    title: "⏳ 잠정 — 추후 갱신 예정",
    bullets: [
      <>
        지금 기준은 <b>적은 표본</b>으로 잡은 1차 값이에요
      </>,
      <>
        <b>6/17 정상 트래픽</b> 쌓이면 임계값 재확인
      </>,
      <>실행: 6/17 오전 이후</>,
    ],
  },
];

export function TodayBriefAnnouncement({ onClose }: { onClose: () => void }) {
  const dismiss = () => {
    sessionStorage.setItem(TODAY_BRIEF_DISMISS_KEY, "1");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={dismiss} />
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-border bg-background shadow-2xl">
        <button
          onClick={dismiss}
          aria-label="닫기"
          className="absolute right-3 top-3 rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <X className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-3 border-b border-border/60 bg-secondary/40 px-5 py-4">
          <Monkey mood="teacher" size={48} />
          <div>
            <div className="text-base font-bold tracking-tight">오늘의 이슈</div>
            <div className="text-xs text-muted-foreground">2026-06-16 · 메타몽</div>
          </div>
        </div>
        <div className="max-h-[60vh] space-y-3 overflow-y-auto px-5 py-4">
          {CARDS.map((c, ci) => (
            <div
              key={ci}
              className="rounded-xl border border-border/60 bg-secondary/30 px-4 py-3"
            >
              <span
                className={cn(
                  "mb-2 inline-block rounded-md px-2 py-0.5 text-[11px] font-bold",
                  c.tone === "decision" && "bg-emerald-100 text-emerald-700",
                  c.tone === "progress" && "bg-primary/15 text-primary",
                  c.tone === "info" && "bg-secondary text-muted-foreground",
                )}
              >
                {c.tag}
              </span>
              <div className="mb-1.5 text-sm font-bold">{c.title}</div>
              {c.chips && (
                <div className="mb-2 flex flex-wrap gap-1.5">
                  {c.chips.map((chip, i) => (
                    <span
                      key={i}
                      className={cn(
                        "inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[12px] font-semibold",
                        chip.tone === "bad" && "bg-rose-100 text-rose-700",
                        chip.tone === "good" && "bg-emerald-100 text-emerald-700",
                      )}
                    >
                      <span className="text-[10px] font-medium opacity-70">{chip.label}</span>
                      {chip.value}
                    </span>
                  ))}
                </div>
              )}
              {c.qa && (
                <div className="space-y-2">
                  {c.qa.map((item, i) => (
                    <div key={i} className="rounded-lg bg-background/70 px-3 py-2">
                      <div className="text-[12.5px] font-semibold text-muted-foreground">
                        ❓ {item.q}
                      </div>
                      <div className="mt-1 flex gap-1.5 text-[13px] leading-relaxed text-foreground/85">
                        <span className="text-emerald-600">↳</span>
                        <span>{item.a}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {c.bullets && (
                <ul className="list-disc space-y-1 pl-4">
                  {c.bullets.map((b, i) => (
                    <li key={i} className="text-[13px] leading-relaxed text-foreground/80">
                      {b}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
