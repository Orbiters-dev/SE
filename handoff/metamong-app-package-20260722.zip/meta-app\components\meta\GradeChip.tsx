import { Monkey, type MonkeyMood } from "@/components/meta/Monkey";
import { cn } from "@/lib/utils";

export type Grade = "S" | "A" | "B" | "C" | "NA";

const MOOD: Record<Grade, MonkeyMood> = {
  S: "ecstatic",  // 꺄악 + 하트
  A: "joyful",    // 볼 빨갛게 + 활짝 웃음
  B: "dizzy",
  C: "cry",
  NA: "dizzy",
};

// label 텍스트 색 (등급 칩)
const LABEL_STYLE: Record<Grade, string> = {
  S: "bg-[var(--good-bg)] text-[var(--good-fg)] border border-[var(--good)]/30",
  A: "bg-accent text-accent-foreground border border-accent/40",
  B: "bg-secondary text-secondary-foreground border border-border",
  C: "bg-[var(--bad-bg)] text-[var(--bad-fg)] border border-[var(--bad)]/30",
  NA: "bg-muted text-muted-foreground border border-border",
};

// row background tint (subtle)
export const GRADE_ROW_BG: Record<Grade, string> = {
  S: "bg-[var(--good-bg)]/30 hover:bg-[var(--good-bg)]/50",
  A: "bg-accent/20 hover:bg-accent/30",
  B: "bg-secondary/40 hover:bg-secondary/60",
  C: "bg-[var(--bad-bg)]/30 hover:bg-[var(--bad-bg)]/50",
  NA: "bg-muted/40 hover:bg-muted/60",
};

// strong card background (detail header)
export const GRADE_CARD_BG: Record<Grade, string> = {
  S: "bg-[var(--good-bg)]/60 border-[var(--good)]/40",
  A: "bg-accent/50 border-accent",
  B: "bg-secondary border-border",
  C: "bg-[var(--bad-bg)]/60 border-[var(--bad)]/40",
  NA: "bg-muted/50 border-border",
};

// 리스트/테이블용 콤팩트 등급 뱃지 (원숭이 없이 글자만)
export function GradeBadge({ grade, className }: { grade: Grade; className?: string }) {
  if (grade === "NA") return null;
  return (
    <span
      className={cn(
        "inline-flex shrink-0 items-center rounded-full px-1.5 py-0 text-[10px] font-bold leading-4",
        LABEL_STYLE[grade],
        className,
      )}
    >
      {grade}
    </span>
  );
}

export function GradeChip({
  grade, size = 36, bump = 0,
}: {
  grade: Grade;
  size?: number;
  bump?: 1 | -1 | 0;
}) {
  return (
    <div className="inline-flex items-center gap-1.5">
      <Monkey mood={MOOD[grade]} size={size} />
      <span className={cn("inline-flex items-center rounded-full px-2 py-0.5 text-sm font-bold", LABEL_STYLE[grade])}>
        {grade === "NA" ? "—" : grade}
        {bump !== 0 && (
          <span className="ml-0.5 text-[10px] opacity-70">
            {bump > 0 ? "▲" : "▼"}
          </span>
        )}
      </span>
    </div>
  );
}
