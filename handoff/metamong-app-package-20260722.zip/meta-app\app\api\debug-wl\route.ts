import { NextResponse } from "next/server";
import { fetchCollabs } from "@/lib/sheets";
import { fetchContentPosts } from "@/lib/datakeeper";
import { fetchWlAttributionByShortcode, type CollabKey } from "@/lib/wl-attribution";

export async function GET() {
  const [collabs, posts] = await Promise.all([fetchCollabs(), fetchContentPosts(365, "grosmimi")]);
  const postByShortcode = new Map<string, { post_date: string | null }>();
  for (const p of posts) if (p.post_id) postByShortcode.set(p.post_id, { post_date: p.post_date });
  const sheetAdCodes = new Map<string, string>();
  for (const c of collabs) if (c.adCode && c.postShortcode) sheetAdCodes.set(c.adCode, c.postShortcode);
  const collabKeys: CollabKey[] = collabs
    .filter((c) => c.postShortcode && c.creatorId)
    .map((c) => ({
      shortcode: c.postShortcode!,
      handle: c.creatorId,
      postDate: c.postShortcode ? postByShortcode.get(c.postShortcode)?.post_date ?? null : null,
      product: c.product,
    }));
  const wl = await fetchWlAttributionByShortcode(sheetAdCodes, collabKeys);
  return NextResponse.json({
    sheetCollabs: collabs.length,
    collabKeys: collabKeys.length,
    handlePrefixes: Array.from(new Set(collabKeys.map((c) => c.handle.toLowerCase().split(/[._-]/)[0]))).filter((h) => h.length >= 3),
    sheetAdCodes: sheetAdCodes.size,
    matchedAdCount: wl.matchedAdCount,
    unmatchedAdCount: wl.unmatchedAdCount,
    totalSpend: wl.totalSpend,
    totalImpressions: wl.totalImpressions,
    byShortcode: Array.from(wl.byShortcode.entries()).map(([sc, v]) => ({
      shortcode: sc,
      spend: v.spend,
      impressions: v.impressions,
      adCount: v.adIds.length,
      via: v.matchedVia,
    })),
    unmatchedAds: wl.unmatchedAds.slice(0, 50),
  });
}
