import Link from "next/link";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { EnvWarning } from "@/components/meta/EnvWarning";
import { StatusPill, SpendBar, RankBadge } from "@/components/meta/StatusBadge";
import { GradeBadge } from "@/components/meta/GradeChip";
import { buildAdGradeMap, type AdGradeTag } from "@/lib/ad-grade";
import { fetchAds, bestWorst, compositeBestWorst, type AdRow, type CompositeAd } from "@/lib/meta-aggregations";
import { fmtWon, fmtPct, fmtNum, isoDate, daysAgo } from "@/lib/format";
import {
  CTR_BENCH, CTR_LOW, FREQ_HIGH, KPI_CPC,
} from "@/lib/meta-constants";

export const revalidate = 60;

export default async function AdsPage() {
  let body: React.ReactNode;
  try {
    const today = new Date();
    const since = isoDate(daysAgo(7, today));
    const until = isoDate(daysAgo(1, today));
    const [adsRaw, gradeMap] = await Promise.all([
      fetchAds(since, until),
      buildAdGradeMap(),
    ]);
    const ads = adsRaw.filter((a) => a.spend > 0);

    const sortedCtr = bestWorst(ads, "ctr");
    const sortedCpc = bestWorst(ads, "cpc");
    const sortedCplpv = bestWorst(ads, "cplpv");
    const composite = compositeBestWorst(ads);

    const totalAds = ads.length;
    const totalSpend = ads.reduce((s, a) => s + a.spend, 0);
    const maxSpend = ads.reduce((m, a) => Math.max(m, a.spend), 0);

    body = (
      <>
        <section>
          <div className="mb-4 flex items-baseline justify-between">
            <h1 className="text-xl font-bold tracking-tight">광고 7일 풀</h1>
            <span className="text-xs text-muted-foreground">{since} ~ {until}</span>
          </div>
          <div className="grid grid-cols-3 gap-2 sm:gap-3">
            <SummaryStat label="광고 수" value={`${totalAds}`} />
            <SummaryStat label="총 지출" value={fmtWon(totalSpend)} />
            <SummaryStat label="총 LPV" value={fmtNum(ads.reduce((s, a) => s + a.lpv, 0))} />
          </div>
        </section>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-baseline justify-between gap-2">
              <CardTitle className="text-base">
                BEST / WORST 광고
                <span className="ml-1.5 align-middle text-[10px] font-semibold text-muted-foreground">최근 7일 · 종합</span>
              </CardTitle>
              <span className="text-xs text-muted-foreground">풀 {composite.poolSize}개</span>
            </div>
            <p className="text-xs text-muted-foreground">
              기준 — 노출 ≥200 광고만 · 종합점수 = 풀 내 percentile 가중합 (CPLPV 50% + CTR 30% + CPC 20%, LPV 효율이 1차 축) · WORST는 BEST 제외 후 선정
            </p>
          </CardHeader>
          <CardContent className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <CompositeList items={composite.best} tone="good" label="BEST" gradeMap={gradeMap} />
            <CompositeList items={composite.worst} tone="bad" label="WORST" gradeMap={gradeMap} />
          </CardContent>
        </Card>

        <BestWorstCard title="CTR" hint={`벤치 ${CTR_BENCH}% · 저성과 ${CTR_LOW}%`} best={sortedCtr.best} worst={sortedCtr.worst} valueKey="ctr" higherBetter gradeMap={gradeMap} />
        <BestWorstCard title="CPC" hint={`목표 ₩${KPI_CPC}`} best={sortedCpc.best} worst={sortedCpc.worst} valueKey="cpc" gradeMap={gradeMap} />
        <BestWorstCard title="CPLPV" hint="낮을수록 좋음" best={sortedCplpv.best} worst={sortedCplpv.worst} valueKey="cplpv" gradeMap={gradeMap} />

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">
              전체 ({totalAds})
              <span className="ml-1.5 align-middle text-[10px] font-semibold text-muted-foreground">최근 7일</span>
            </CardTitle>
            <p className="text-xs text-muted-foreground">
              임계 — CTR 벤치 {CTR_BENCH}% · CPC ₩{KPI_CPC} · Freq {FREQ_HIGH}+
            </p>
          </CardHeader>
          <CardContent className="overflow-x-auto p-0">
            <Table className="md:min-w-[780px]">
              <TableHeader>
                <TableRow>
                  <TableHead>광고</TableHead>
                  <TableHead className="w-[96px] md:w-[160px]">Spend</TableHead>
                  <TableHead className="text-right">CTR</TableHead>
                  <TableHead className="hidden text-right md:table-cell">CPC</TableHead>
                  <TableHead className="text-right">CPLPV</TableHead>
                  <TableHead className="hidden text-right md:table-cell">Freq</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {[...ads].sort((a, b) => b.spend - a.spend).map((a) => (
                  <TableRow key={a.ad_id} className="hover:bg-secondary/40">
                    <TableCell className="max-w-[120px] md:max-w-[260px]">
                      <Link href={`/ads/${a.ad_id}`} className="block hover:opacity-80">
                        <div className="flex items-center gap-1">
                          <span className="truncate text-sm font-semibold">{a.ad_name || "(unnamed)"}</span>
                          {gradeMap.get(a.ad_id) && <GradeBadge grade={gradeMap.get(a.ad_id)!.wlGrade} />}
                        </div>
                        <div className="truncate text-xs text-muted-foreground">{a.adset_name}</div>
                      </Link>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="text-sm font-semibold tabular-nums">{fmtWon(a.spend)}</div>
                        <SpendBar value={a.spend} max={maxSpend} />
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <CtrCell ctr={a.ctr} />
                    </TableCell>
                    <TableCell className="hidden text-right md:table-cell">
                      <CpcCell cpc={a.cpc} />
                    </TableCell>
                    <TableCell className="text-right tabular-nums text-sm">{fmtWon(a.cplpv)}</TableCell>
                    <TableCell className="hidden text-right md:table-cell">
                      <FreqCell freq={a.frequency} />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </>
    );
  } catch (e) {
    body = <EnvWarning error={e instanceof Error ? e.message : String(e)} />;
  }
  return <div className="space-y-6">{body}</div>;
}

function SummaryStat({ label, value }: { label: string; value: string }) {
  return (
    <Card className="border-border/60 bg-card/80">
      <CardContent className="p-3 sm:p-4">
        <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className="mt-1 text-base font-bold tabular-nums sm:text-lg">{value}</div>
      </CardContent>
    </Card>
  );
}

function CtrCell({ ctr }: { ctr: number }) {
  if (ctr === 0) return <span className="text-muted-foreground">—</span>;
  const tone = ctr >= CTR_BENCH ? "good" : ctr >= CTR_LOW ? "neutral" : "bad";
  return <StatusPill tone={tone}>{fmtPct(ctr)}</StatusPill>;
}

function CpcCell({ cpc }: { cpc: number }) {
  if (cpc === 0) return <span className="text-muted-foreground">—</span>;
  const tone = cpc <= KPI_CPC ? "good" : cpc <= KPI_CPC * 1.5 ? "neutral" : "bad";
  return <StatusPill tone={tone}>{fmtWon(cpc)}</StatusPill>;
}

function FreqCell({ freq }: { freq: number }) {
  if (freq === 0) return <span className="text-muted-foreground">—</span>;
  const tone = freq >= FREQ_HIGH ? "bad" : freq >= 2.0 ? "warn" : "neutral";
  return <StatusPill tone={tone}>{freq.toFixed(2)}</StatusPill>;
}

function BestWorstCard({
  title, hint, best, worst, valueKey, higherBetter, gradeMap,
}: {
  title: string;
  hint: string;
  best: AdRow[];
  worst: AdRow[];
  valueKey: keyof Pick<AdRow, "ctr" | "cpc" | "cplpv" | "spend">;
  higherBetter?: boolean;
  gradeMap: Map<string, AdGradeTag>;
}) {
  const fmt = (v: number) => valueKey === "ctr" ? fmtPct(v) : fmtWon(v);
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-baseline justify-between gap-2">
          <CardTitle className="text-base">
            {title}
            <span className="ml-1.5 align-middle text-[10px] font-semibold text-muted-foreground">최근 7일</span>
          </CardTitle>
          <span className="text-xs text-muted-foreground">{hint}</span>
        </div>
        <p className="text-[11px] text-muted-foreground">기준 — 7일 spend ≥ ₩1,000 광고 중 {title} 상/하위 5개</p>
      </CardHeader>
      <CardContent className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <RankList items={best} valueKey={valueKey} fmt={fmt} tone="good" label={higherBetter ? "TOP" : "최저 (좋음)"} gradeMap={gradeMap} />
        <RankList items={worst} valueKey={valueKey} fmt={fmt} tone="bad" label={higherBetter ? "BOTTOM" : "최고 (개선 필요)"} gradeMap={gradeMap} />
      </CardContent>
    </Card>
  );
}

function CompositeList({
  items, tone, label, gradeMap,
}: {
  items: CompositeAd[];
  tone: "good" | "bad";
  label: string;
  gradeMap: Map<string, AdGradeTag>;
}) {
  return (
    <div className="rounded-xl border border-border/60 bg-secondary/40 p-3">
      <div className="mb-2 flex items-center gap-2">
        <StatusPill tone={tone}>{label}</StatusPill>
        <span className="text-[10px] text-muted-foreground">종합점수 순</span>
      </div>
      <ol className="space-y-2.5">
        {items.length === 0 && <li className="text-sm text-muted-foreground">풀 부족 (노출 ≥200 광고 2개 미만)</li>}
        {items.map((a, i) => (
          <li key={a.ad_id}>
            <Link
              href={`/ads/${a.ad_id}`}
              className="-mx-1.5 flex items-center gap-2.5 rounded-lg px-1.5 py-0.5 transition-colors hover:bg-secondary/70"
            >
              <RankBadge rank={i + 1} tone={tone} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1">
                  <span className="truncate text-sm font-medium">{a.ad_name || "(unnamed)"}</span>
                  {gradeMap.get(a.ad_id) && <GradeBadge grade={gradeMap.get(a.ad_id)!.wlGrade} />}
                </div>
                <div className="truncate text-[11px] tabular-nums text-muted-foreground">
                  CPLPV {a.cplpv > 0 ? fmtWon(a.cplpv) : "—"} · CTR {fmtPct(a.ctr)} · CPC {a.cpc > 0 ? fmtWon(a.cpc) : "—"} · Spend {fmtWon(a.spend)}
                </div>
              </div>
              <span className="shrink-0 text-sm font-bold tabular-nums">{a.score.toFixed(0)}점</span>
            </Link>
          </li>
        ))}
      </ol>
    </div>
  );
}

function RankList({
  items, valueKey, fmt, tone, label, gradeMap,
}: {
  items: AdRow[];
  valueKey: keyof AdRow;
  fmt: (v: number) => string;
  tone: "good" | "bad";
  label: string;
  gradeMap: Map<string, AdGradeTag>;
}) {
  return (
    <div className="rounded-xl border border-border/60 bg-secondary/40 p-3">
      <div className="mb-2 flex items-center gap-2">
        <StatusPill tone={tone}>{label}</StatusPill>
      </div>
      <ol className="space-y-2">
        {items.length === 0 && <li className="text-sm text-muted-foreground">데이터 없음</li>}
        {items.map((a, i) => (
          <li key={a.ad_id}>
            <Link
              href={`/ads/${a.ad_id}`}
              className="-mx-1.5 flex items-center gap-2.5 rounded-lg px-1.5 py-0.5 transition-colors hover:bg-secondary/70"
            >
              <RankBadge rank={i + 1} tone={tone} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1">
                  <span className="truncate text-sm font-medium">{a.ad_name || "(unnamed)"}</span>
                  {gradeMap.get(a.ad_id) && <GradeBadge grade={gradeMap.get(a.ad_id)!.wlGrade} />}
                </div>
                <div className="truncate text-[11px] text-muted-foreground">{a.adset_name}</div>
              </div>
              <span className="shrink-0 text-sm font-bold tabular-nums">{fmt(Number(a[valueKey] ?? 0))}</span>
            </Link>
          </li>
        ))}
      </ol>
    </div>
  );
}
