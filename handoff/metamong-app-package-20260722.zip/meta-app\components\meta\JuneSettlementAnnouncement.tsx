"use client";

// 6월 메타 광고 총 결산 (2026-07-01, 24h 한정) — 메타몽 산출.
// 표시 게이트(시간·dismiss)는 AnnouncementStack이 관리. 여기는 표시 전용.
// ~2026-07-02 19:30 KST(10:30 UTC) 자동 미표시. X 닫기 = 같은 탭 세션 동안 다시 안 뜸.
// 통화 KRW 통일 (1엔=9.58원). 합산 지표 = Total ROAS 라벨.

import type { ReactNode } from "react";
import { X } from "lucide-react";
import { Monkey } from "@/components/meta/Monkey";
import { cn } from "@/lib/utils";

export const JUNE_SETTLEMENT_SHOW_UNTIL_UTC = Date.UTC(2026, 6, 2, 10, 30, 0); // 2026-07-02 19:30 KST
export const JUNE_SETTLEMENT_DISMISS_KEY = "june_settlement_20260701_dismissed";

interface Card {
  tag: string;
  tone: "decision" | "info";
  title: string;
  bullets: ReactNode[];
}

const CARDS: Card[] = [
  {
    tag: "총량",
    tone: "info",
    title: "6월 집행 규모 (MoM)",
    bullets: [
      <>
        Amount Spent <b>₩7,656,066</b> (5월 대비 <b>+75.7%</b>)
      </>,
      <>
        CPLPV <b>₩124</b> (+9.7%) · CTR(all) <b>7.72%</b> (+1.13%p)
      </>,
      <>
        LPV <b>61,924</b> · 노출 <b>108.5만</b> · 도달 <b>61.9만</b>
      </>,
    ],
  },
  {
    tag: "매출·ROAS",
    tone: "decision",
    title: "라쿠텐 매출 vs 광고비",
    bullets: [
      <>
        라쿠텐 매출(정가) <b>₩9,875,447</b> · 190주문
      </>,
      <>
        광고비 = Meta <b>₩7,656,066</b> + RPP <b>₩1,024,121</b> = <b>₩8,680,187</b>
      </>,
      <>
        <b>Total ROAS 1.14x</b> (Meta-only 1.29x)
      </>,
    ],
  },
  {
    tag: "슈퍼세일",
    tone: "decision",
    title: "세일 집중의 효과 (Meta 기준)",
    bullets: [
      <>
        슈퍼세일 <b>2.74x</b> vs 평시 <b>0.66x</b> (4.2배차)
      </>,
      <>
        8일(6/4~11)이 <b>월매출의 64%</b> (₩6.36M)
      </>,
    ],
  },
  {
    tag: "구조",
    tone: "info",
    title: "단계·제품·명명",
    bullets: [
      <>
        Proven <b>86%</b> 집중 · CPLPV <b>₩120</b> (풀평균 124↓)
      </>,
      <>
        제품: PPSU <b>₩114</b> &lt; Stainless <b>₩126</b>
      </>,
      <>
        Traffic 레거시 <b>₩176</b> (풀 최악) · 명명체계 6/19 도입 후 spend <b>85%</b> 신규규칙
      </>,
    ],
  },
  {
    tag: "BEST 3",
    tone: "decision",
    title: "6월 최고 효율 (CPLPV) · 콘텐츠 태그",
    bullets: [
      <>
        <b>nee_and_twins ₩87</b> (WL-G·PPSU) — 라이프스타일·사용 상황 / 식사 시간·하이체어
      </>,
      <>
        <b>ichikuru_fufu ₩108</b> (WL-G·PPSU) — 기능·성능 / 모듈러 시스템 (교체·호환)
      </>,
      <>
        <b>haruyoshi09126 ₩114</b> (WL-P·Stainless) — 디자인·발견 / 아이가 직접 고르는 컵
      </>,
    ],
  },
  {
    tag: "WORST 3",
    tone: "info",
    title: "6월 최저 효율 (CPLPV)",
    bullets: [
      <>
        <b>rii_mama_ikuji ₩183</b> (WL-P·PPSU)
      </>,
      <>
        <b>arara_norarara ₩168</b> (WL-G·Stainless)
      </>,
      <>
        <b>ebi_ikuji ₩137</b> (WL-G·PPSU)
      </>,
    ],
  },
  {
    tag: "7월 액션",
    tone: "decision",
    title: "이번 달 방향",
    bullets: [
      <>
        상시(평시) 효율이 관건 — <b>평시 ROAS 0.66x</b>, Proven 중심(CPLPV ₩120) 배분 유지
      </>,
      <>
        WL 신규 소재 지속 (CTR 6.78%→<b>8.27%</b> 상승 동력)
      </>,
      <>
        <b>CPLPV +9.7%</b> 관리 — 스펜드 확대 시 한계단가 모니터
      </>,
    ],
  },
];

export function JuneSettlementAnnouncement({ onClose }: { onClose: () => void }) {
  const dismiss = () => {
    sessionStorage.setItem(JUNE_SETTLEMENT_DISMISS_KEY, "1");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={dismiss} />
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-border bg-background shadow-2xl">
        <button
          onClick={dismiss}
          aria-label="닫기"
          className="absolute right-3 top-3 rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <X className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-3 border-b border-border/60 bg-secondary/40 px-5 py-4">
          <Monkey mood="rich" size={48} />
          <div>
            <div className="text-base font-bold tracking-tight">6월 메타 광고 총 결산</div>
            <div className="text-xs text-muted-foreground">2026-06 · 메타몽</div>
          </div>
        </div>
        <div className="max-h-[60vh] space-y-3 overflow-y-auto px-5 py-4">
          {CARDS.map((c, ci) => (
            <div key={ci} className="rounded-xl border border-border/60 bg-secondary/30 px-4 py-3">
              <span
                className={cn(
                  "mb-2 inline-block rounded-md px-2 py-0.5 text-[11px] font-bold",
                  c.tone === "decision" && "bg-emerald-100 text-emerald-700",
                  c.tone === "info" && "bg-secondary text-muted-foreground",
                )}
              >
                {c.tag}
              </span>
              <div className="mb-1.5 text-sm font-bold">{c.title}</div>
              <ul className="list-disc space-y-1 pl-4">
                {c.bullets.map((b, i) => (
                  <li key={i} className="text-[13px] leading-relaxed text-foreground/80">
                    {b}
                  </li>
                ))}
              </ul>
            </div>
          ))}
          <div className="rounded-lg bg-secondary/40 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
            Total ROAS = 블렌디드(라쿠텐 총매출 ÷ 총광고비, 오가닉 포함) · 1엔=9.58원 · RPP는 월총액 기준
          </div>
        </div>
      </div>
    </div>
  );
}
