"use client";

// 콘텐츠 상세 일별/누적 그래프. organic view 는 항상, paid(WL) 지표는 WL 콘텐츠만.
// 각 지표를 "일별"과 "누적(적분)" 두 섹션으로 분리.

import {
  Area, AreaChart, Line, LineChart, ResponsiveContainer,
  Tooltip, XAxis, YAxis, CartesianGrid,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { fmtWon, fmtPct, fmtNum, fmtCompact } from "@/lib/format";

export interface OrganicPoint { date: string; daily: number; cum: number }
export interface PaidPoint {
  date: string;
  spend: number; spendCum: number;
  lpv: number; lpvCum: number;
  ctr: number; ctrCum: number;
  cplpv: number; cplpvCum: number;
}

const AXIS = { fontSize: 10, fill: "var(--muted-foreground)" };
const short = (d: string) => d.slice(5).replace("-", "/");
const tip = {
  contentStyle: { background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12, fontSize: 12 },
  labelStyle: { color: "var(--muted-foreground)", fontSize: 11 },
};
const C1 = "var(--primary)";
const C2 = "var(--chart-2, #8a6f4d)";

function ChartCard({ title, hint, children }: { title: string; hint?: string; children: React.ReactNode }) {
  return (
    <Card>
      <CardHeader className="pb-1">
        <div className="flex items-baseline justify-between">
          <CardTitle className="text-sm">{title}</CardTitle>
          {hint && <span className="text-[10px] text-muted-foreground">{hint}</span>}
        </div>
      </CardHeader>
      <CardContent className="pl-0 pr-3"><div className="h-[150px] w-full">{children}</div></CardContent>
    </Card>
  );
}

const common = { margin: { top: 4, right: 4, bottom: 0, left: 0 } };
const grid = <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />;
const xAxis = <XAxis dataKey="date" tickFormatter={short} tick={AXIS} tickLine={false} axisLine={false} minTickGap={28} />;

function ViewsArea({ data, dataKey, color }: { data: object[]; dataKey: string; color: string }) {
  return (
    <ResponsiveContainer>
      <AreaChart data={data} {...common}>
        {grid}{xAxis}
        <YAxis tick={AXIS} tickLine={false} axisLine={false} width={52} tickFormatter={(v: number) => fmtCompact(v)} />
        <Tooltip {...tip} formatter={(v) => [fmtNum(v as number), "view"]} labelFormatter={(l) => short(String(l))} />
        <Area type="monotone" dataKey={dataKey} stroke={color} fill={color} fillOpacity={0.18} strokeWidth={2} />
      </AreaChart>
    </ResponsiveContainer>
  );
}
function SpendArea({ data, dataKey }: { data: object[]; dataKey: string }) {
  return (
    <ResponsiveContainer>
      <AreaChart data={data} {...common}>
        {grid}{xAxis}
        <YAxis tick={AXIS} tickLine={false} axisLine={false} width={52} tickFormatter={(v: number) => fmtCompact(v)} />
        <Tooltip {...tip} formatter={(v) => [fmtWon(v as number), "Spend"]} labelFormatter={(l) => short(String(l))} />
        <Area type="monotone" dataKey={dataKey} stroke={C2} fill={C2} fillOpacity={0.18} strokeWidth={2} />
      </AreaChart>
    </ResponsiveContainer>
  );
}
function LpvArea({ data, dataKey }: { data: object[]; dataKey: string }) {
  return (
    <ResponsiveContainer>
      <AreaChart data={data} {...common}>
        {grid}{xAxis}
        <YAxis tick={AXIS} tickLine={false} axisLine={false} width={44} tickFormatter={(v: number) => fmtNum(v)} />
        <Tooltip {...tip} formatter={(v) => [fmtNum(v as number), "LPV"]} labelFormatter={(l) => short(String(l))} />
        <Area type="monotone" dataKey={dataKey} stroke={C1} fill={C1} fillOpacity={0.18} strokeWidth={2} />
      </AreaChart>
    </ResponsiveContainer>
  );
}
function CtrLine({ data, dataKey }: { data: object[]; dataKey: string }) {
  return (
    <ResponsiveContainer>
      <LineChart data={data} {...common}>
        {grid}{xAxis}
        <YAxis tick={AXIS} tickLine={false} axisLine={false} width={40} tickFormatter={(v: number) => `${v}%`} />
        <Tooltip {...tip} formatter={(v) => [fmtPct(v as number), "CTR"]} labelFormatter={(l) => short(String(l))} />
        <Line type="monotone" dataKey={dataKey} stroke={C1} strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}
function CplpvLine({ data, dataKey }: { data: object[]; dataKey: string }) {
  return (
    <ResponsiveContainer>
      <LineChart data={data} {...common}>
        {grid}{xAxis}
        <YAxis tick={AXIS} tickLine={false} axisLine={false} width={48} tickFormatter={(v: number) => `₩${fmtNum(v)}`} />
        <Tooltip {...tip} formatter={(v) => [fmtWon(v as number), "CPLPV"]} labelFormatter={(l) => short(String(l))} />
        <Line type="monotone" dataKey={dataKey} stroke={C2} strokeWidth={2} dot={false} />
      </LineChart>
    </ResponsiveContainer>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return <div className="md:col-span-2 pt-1 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">{children}</div>;
}

export function ContentCharts({ organic, paid }: { organic: OrganicPoint[]; paid?: PaidPoint[] | null }) {
  const hasPaid = !!(paid && paid.length > 0);
  return (
    <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
      <SectionLabel>일별</SectionLabel>
      <ChartCard title="Organic view (일별)" hint="그날 순증 (전체−paid)"><ViewsArea data={organic} dataKey="daily" color={C1} /></ChartCard>
      {hasPaid && <ChartCard title="Paid Spend (일별)" hint="₩"><SpendArea data={paid!} dataKey="spend" /></ChartCard>}
      {hasPaid && <ChartCard title="Paid LPV (일별)"><LpvArea data={paid!} dataKey="lpv" /></ChartCard>}
      {hasPaid && <ChartCard title="Paid CPLPV (일별)" hint="낮을수록 좋음"><CplpvLine data={paid!} dataKey="cplpv" /></ChartCard>}
      {hasPaid && <ChartCard title="Paid CTR (일별)" hint="%"><CtrLine data={paid!} dataKey="ctr" /></ChartCard>}

      <SectionLabel>누적 (적분)</SectionLabel>
      <ChartCard title="Organic view (누적)" hint="전체 누적−paid"><ViewsArea data={organic} dataKey="cum" color={C1} /></ChartCard>
      {hasPaid && <ChartCard title="Paid Spend (누적)" hint="₩"><SpendArea data={paid!} dataKey="spendCum" /></ChartCard>}
      {hasPaid && <ChartCard title="Paid LPV (누적)"><LpvArea data={paid!} dataKey="lpvCum" /></ChartCard>}
      {hasPaid && <ChartCard title="Paid CPLPV (누적)" hint="누적 spend/LPV"><CplpvLine data={paid!} dataKey="cplpvCum" /></ChartCard>}
      {hasPaid && <ChartCard title="Paid CTR (누적)" hint="누적 clicks/노출"><CtrLine data={paid!} dataKey="ctrCum" /></ChartCard>}
    </div>
  );
}
