// SERVER-ONLY. WL Meta spend → 인플루언서 콜라보 매칭.
// 4-track (2026-06-10 세은 검사 승인 — A표 반영):
//  1. Partnership ad: creative.instagram_permalink_url shortcode = 시트 게시물 정확 일치
//  2. 게시자 계정: 광고 게시물의 실제 username = 시트 Creator ID 정확 일치
//     (인플 행 여러 개면 광고명 제품 토큰 + 날짜 근접으로 선택. 공식 계정 grosmimi_japan 제외)
//  3. Use existing post: 시트 Ad code (col 27) 수동 입력 활용
//  4. ad_name 안 인플 핸들 substring (예: "coni") + 날짜 매칭 (보수적 fallback)

import "server-only";
import { fetchInsights, fetchAdCreatives, fetchAdPosterUsernames, fetchAdStatuses } from "./dk-meta";   // DK 단일소스
import { shortcodeFromPermalink, extractLpv } from "./meta-api";  // 순수 헬퍼
import { toFloat } from "./format";

const OFFICIAL_HANDLE = "grosmimi_japan";

export interface AdSpendByShortcode {
  shortcode: string;
  spend: number;
  impressions: number;
  clicks: number;
  lpv: number;
  adIds: string[];
  matchedVia: "partnership" | "poster_username" | "ad_code" | "ad_name_handle";
}

export interface UnmatchedAd {
  adId: string;
  adName: string;
  spend: number;
  permaShortcode: string | null;  // permalink는 있는데 시트 콜라보 shortcode 와 불일치한 경우
}

export interface WlAttributionResult {
  byShortcode: Map<string, AdSpendByShortcode>;
  totalSpend: number;
  totalImpressions: number;
  matchedAdCount: number;
  unmatchedAdCount: number;
  unmatchedAds: UnmatchedAd[];
}

export interface CollabKey {
  shortcode: string;
  handle: string;
  postDate: string | null;  // YYYY-MM-DD (DK or 시트 expected_upload)
  product?: string;         // 시트 Product — 동일 인플 다건 행 선택용
}

// 동일 인플루언서 행 여러 개일 때 광고명 제품 토큰(ppsu/stain + 200/300) + 날짜 근접으로 선택
function pickCollabForCreator(rows: CollabKey[], adNameLower: string, adDate: string | null): CollabKey {
  let best = rows[0];
  let bestScore = -Infinity;
  for (const c of rows) {
    const p = (c.product ?? "").toLowerCase();
    let score = 0;
    if (adNameLower.includes("ppsu") && p.includes("ppsu")) score += 4;
    if (adNameLower.includes("stain") && p.includes("stain")) score += 4;
    for (const size of ["200", "300"]) {
      if (adNameLower.includes(size) && p.includes(size)) score += 2;
    }
    if (adDate && c.postDate) {
      const gap = Math.abs(
        (new Date(`${adDate}T00:00:00Z`).getTime() - new Date(`${c.postDate}T00:00:00Z`).getTime()) / 86_400_000,
      );
      score += Math.max(0, 1 - gap / 365);  // 근접할수록 +0~1
    }
    if (score > bestScore) {
      best = c;
      bestScore = score;
    }
  }
  return best;
}

function extractTokens(adName: string): Set<string> {
  return new Set(
    adName.toLowerCase().split(/[|\s_\/,()]+/).map((t) => t.trim()).filter((t) => t.length >= 3),
  );
}

function extractDate(adName: string): string | null {
  const m = adName.match(/(20\d{6})/);  // yyyymmdd starting with 20
  if (!m) return null;
  const d = m[1];
  return `${d.slice(0, 4)}-${d.slice(4, 6)}-${d.slice(6, 8)}`;
}

function handlePrefix(handle: string): string {
  return handle.toLowerCase().split(/[._-]/)[0];
}

export async function fetchWlAttributionByShortcode(
  sheetAdCodes: Map<string, string> = new Map(),
  collabKeys: CollabKey[] = [],
): Promise<WlAttributionResult> {
  // 전체 이력 (계정 최초 광고 2025-12 ~ 현재) — last_90d 로 자르지 않는다. DK 백필분까지 전부 합산.
  const until = new Date().toISOString().slice(0, 10);
  const ads = await fetchInsights({ level: "ad", timeRange: { since: "2025-12-01", until } });
  if (ads.length === 0) {
    return { byShortcode: new Map(), totalSpend: 0, totalImpressions: 0, matchedAdCount: 0, unmatchedAdCount: 0, unmatchedAds: [] };
  }

  const adIds = ads.map((a) => a.ad_id).filter((id): id is string => !!id);
  const [permaMap, posterMap, statuses] = await Promise.all([
    fetchAdCreatives(adIds),
    fetchAdPosterUsernames(adIds),
    fetchAdStatuses(adIds),
  ]);
  // "집행 중" 카운트(adIds)는 ACTIVE 광고만. 졸업/종료로 OFF 된 옛 광고(예: Testing→Proven 후 끈 것)를
  // 계속 집행 중으로 세던 문제 해결. spend/impr/lpv 는 이력 그대로 합산(전체 WL 투자 반영). 2026-07-07 세은 규칙.
  // status 조회 전체 실패(map empty) 시에만 fail-open(전부 인정) — 빈 카운트 방지.
  const isActiveAd = (id: string) => (statuses.size === 0 ? true : statuses.get(id) === "ACTIVE");

  // collab index by handle prefix + exact handle + set of collab shortcodes
  const byHandlePrefix = new Map<string, CollabKey[]>();
  const byHandleExact = new Map<string, CollabKey[]>();
  const collabShortcodes = new Set<string>();
  for (const c of collabKeys) {
    collabShortcodes.add(c.shortcode);
    const exact = c.handle.toLowerCase().trim();
    if (exact) {
      const arrE = byHandleExact.get(exact) ?? [];
      arrE.push(c);
      byHandleExact.set(exact, arrE);
    }
    const hp = handlePrefix(c.handle);
    if (hp.length < 3) continue;
    const arr = byHandlePrefix.get(hp) ?? [];
    arr.push(c);
    byHandlePrefix.set(hp, arr);
  }

  const byShortcode = new Map<string, AdSpendByShortcode>();
  let matched = 0;
  let unmatched = 0;
  const unmatchedAds: UnmatchedAd[] = [];

  for (const ad of ads) {
    const adId = ad.ad_id;
    if (!adId) continue;
    const spend = toFloat(ad.spend);
    const impressions = toFloat(ad.impressions);
    const clicks = toFloat(ad.clicks);
    const lpv = extractLpv(ad.actions);

    let shortcode: string | null = null;
    let matchedVia: "partnership" | "poster_username" | "ad_code" | "ad_name_handle" | null = null;

    // 1. partnership permalink — 단 시트 콜라보 shortcode 와 매칭될 때만 사용
    const perma = permaMap.get(adId);
    if (perma) {
      const cand = shortcodeFromPermalink(perma);
      if (cand && collabShortcodes.has(cand)) {
        shortcode = cand;
        matchedVia = "partnership";
      }
    }

    const adName = ad.ad_name ?? "";

    // 2. 게시자 계정 = 시트 Creator ID 정확 일치 (광고 게시물이 시트 등록 게시물과 달라도 매칭)
    if (!shortcode) {
      const poster = posterMap.get(adId);
      if (poster && poster !== OFFICIAL_HANDLE) {
        const rows = byHandleExact.get(poster);
        if (rows && rows.length > 0) {
          const picked = pickCollabForCreator(rows, adName.toLowerCase(), extractDate(adName));
          shortcode = picked.shortcode;
          matchedVia = "poster_username";
        }
      }
    }

    // 3. sheet adcode substring
    if (!shortcode && adName) {
      for (const [code, sc] of sheetAdCodes) {
        if (code && adName.includes(code)) {
          shortcode = sc;
          matchedVia = "ad_code";
          break;
        }
      }
    }

    // 4. ad_name 안 인플 핸들 substring + 날짜 가까운 콘텐츠
    if (!shortcode && adName) {
      const tokens = extractTokens(adName);
      const adDate = extractDate(adName);
      let bestCollab: CollabKey | null = null;
      let bestGap = Infinity;
      for (const [hp, collabs] of byHandlePrefix) {
        if (!tokens.has(hp)) continue;
        for (const c of collabs) {
          let gap: number;
          if (adDate && c.postDate) {
            const ms = new Date(`${adDate}T00:00:00Z`).getTime() - new Date(`${c.postDate}T00:00:00Z`).getTime();
            gap = Math.abs(ms / 86_400_000);
          } else if (adDate || c.postDate) {
            gap = 999;  // 한 쪽만 있으면 큰 gap
          } else {
            gap = 1_000_000;  // 둘 다 없으면 첫 매칭
          }
          if (gap < bestGap) {
            bestCollab = c;
            bestGap = gap;
          }
        }
      }
      if (bestCollab) {
        shortcode = bestCollab.shortcode;
        matchedVia = "ad_name_handle";
      }
    }

    if (!shortcode) {
      unmatched++;
      const permaCand = perma ? shortcodeFromPermalink(perma) : null;
      unmatchedAds.push({ adId, adName, spend, permaShortcode: permaCand });
      continue;
    }
    matched++;

    const cur = byShortcode.get(shortcode) ?? {
      shortcode, spend: 0, impressions: 0, clicks: 0, lpv: 0, adIds: [], matchedVia: matchedVia!,
    };
    cur.spend += spend;
    cur.impressions += impressions;
    cur.clicks += clicks;
    cur.lpv += lpv;
    if (isActiveAd(adId) && !cur.adIds.includes(adId)) cur.adIds.push(adId);
    byShortcode.set(shortcode, cur);
  }

  const totalSpend = Array.from(byShortcode.values()).reduce((s, v) => s + v.spend, 0);
  const totalImpressions = Array.from(byShortcode.values()).reduce((s, v) => s + v.impressions, 0);

  unmatchedAds.sort((a, b) => b.spend - a.spend);
  return { byShortcode, totalSpend, totalImpressions, matchedAdCount: matched, unmatchedAdCount: unmatched, unmatchedAds };
}
