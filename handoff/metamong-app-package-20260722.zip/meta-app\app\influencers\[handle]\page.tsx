import Link from "next/link";
import { notFound } from "next/navigation";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { ArrowLeft, ExternalLink } from "lucide-react";
import { GradeChip, GRADE_CARD_BG } from "@/components/meta/GradeChip";
import { ScrollableTable } from "@/components/meta/ScrollableTable";
import { ContentCharts, type OrganicPoint, type PaidPoint } from "@/components/meta/ContentCharts";
import { fetchInfluencer, type EnrichedCollab } from "@/lib/influencer-aggregation";
import { fetchContentTags, type ContentTag } from "@/lib/sheets";
import { dkQuery } from "@/lib/datakeeper";
import { fetchAdDaily } from "@/lib/dk-meta";
import { extractLpv } from "@/lib/meta-api";
import { fmtCompact, fmtPct, toFloat, isoDate } from "@/lib/format";
import { cn } from "@/lib/utils";

// 콘텐츠별 일별 시계열: organic view(항상) + paid(WL 콘텐츠만)
async function buildContentSeries(c: EnrichedCollab): Promise<{ organic: OrganicPoint[]; paid: PaidPoint[] | null }> {
  // 전체(누적) view by date
  let totalByDate: { date: string; views: number }[] = [];
  if (c.postShortcode) {
    const rows = await dkQuery<{ date: string; views: number | string | null }>(
      "content_metrics_daily", { postId: c.postShortcode, days: 400, limit: 5000 },
    );
    totalByDate = rows
      .map((r) => ({ date: r.date, views: toFloat(r.views) }))
      .filter((r) => r.date && r.views > 0)
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  // paid 일별 raw (spend/impr/clicks/lpv per date)
  let paidDaily: { date: string; spend: number; impr: number; clicks: number; lpv: number }[] = [];
  if (c.hasWl && c.wlAdIds.length > 0) {
    const since = c.postDate ?? "2025-12-01";
    const until = isoDate(new Date());
    const byDate = new Map<string, { spend: number; impr: number; clicks: number; lpv: number }>();
    const perAd = await Promise.all(c.wlAdIds.map((adId) => fetchAdDaily(adId, since, until)));
    for (const rows of perAd) {
      for (const r of rows) {
        const d = r.date_start ?? "";
        if (!d) continue;
        const e = byDate.get(d) ?? { spend: 0, impr: 0, clicks: 0, lpv: 0 };
        e.spend += toFloat(r.spend); e.impr += toFloat(r.impressions);
        e.clicks += toFloat(r.clicks); e.lpv += extractLpv(r.actions);
        byDate.set(d, e);
      }
    }
    paidDaily = [...byDate.entries()]
      .map(([date, e]) => ({ date, ...e }))
      .sort((a, b) => a.date.localeCompare(b.date));
  }

  // paid: 일별 + 누적(적분)
  let paid: PaidPoint[] | null = null;
  if (paidDaily.length > 0) {
    let sC = 0, lC = 0, iC = 0, cC = 0;
    paid = paidDaily.map((e) => {
      sC += e.spend; lC += e.lpv; iC += e.impr; cC += e.clicks;
      return {
        date: e.date,
        spend: e.spend, spendCum: sC,
        lpv: e.lpv, lpvCum: lC,
        ctr: e.impr > 0 ? (e.clicks / e.impr) * 100 : 0,
        ctrCum: iC > 0 ? (cC / iC) * 100 : 0,
        cplpv: e.lpv > 0 ? e.spend / e.lpv : 0,
        cplpvCum: lC > 0 ? sC / lC : 0,
      };
    });
  }

  // organic: 누적 = 그날 전체 누적 view − 그날까지 누적 paid(LPV) · 일별 = 누적의 순증
  const organic: OrganicPoint[] = [];
  let prevCum: number | null = null;
  for (const t of totalByDate) {
    const cumLpv = paidDaily.reduce((s, p) => (p.date <= t.date ? s + p.lpv : s), 0);
    const cum = Math.max(0, t.views - cumLpv);
    const daily = prevCum == null ? cum : Math.max(0, cum - prevCum);
    organic.push({ date: t.date, daily, cum });
    prevCum = cum;
  }

  return { organic, paid };
}

export const revalidate = 300;

function fmtKrw(v: number): string {
  return `₩${Math.round(v).toLocaleString("en-US")}`;
}
function fmtViews(v: number | null): string {
  if (v == null) return "—";
  return fmtCompact(v);
}
function fmtRate(v: number | null): string {
  if (v == null) return "—";
  if (v >= 1_000) return `₩${Math.round(v).toLocaleString("en-US")}`;
  if (v >= 100) return `₩${v.toFixed(0)}`;
  if (v >= 10) return `₩${v.toFixed(1)}`;
  if (v >= 1) return `₩${v.toFixed(2)}`;
  return `₩${v.toFixed(3)}`;
}
function fmtVtr(v: number | null): string {
  if (v == null) return "—";
  return `${(v * 100).toFixed(1)}%`;
}
function fmtFollowers(v: number | null): string {
  if (v == null) return "—";
  return fmtCompact(v);
}

export default async function InfluencerDetailPage({
  params,
}: {
  params: Promise<{ handle: string }>;
}) {
  const { handle } = await params;
  const decoded = decodeURIComponent(handle);
  const p = await fetchInfluencer(decoded);
  if (!p) notFound();

  const tags = await fetchContentTags().catch(() => new Map<string, ContentTag>());

  const seriesList = await Promise.all(
    p.collabs.map(async (c) => ({ c, ...(await buildContentSeries(c)) })),
  );

  return (
    <div className="space-y-6">
      <Link href="/influencers" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-4 w-4" /> 풀로 돌아가기
      </Link>

      <section>
        <Card className={cn("border-2", GRADE_CARD_BG[p.finalGrade])}>
          <CardContent className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center">
            <GradeChip grade={p.finalGrade} size={72} bump={p.qualBump} />
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5">
                <h1 className="text-xl font-bold">@{p.igHandle}</h1>
                {p.hasWl && <Badge variant="default">WL</Badge>}
              </div>
              {p.primaryCollabUrl && (
                <a
                  href={p.primaryCollabUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-1.5 inline-flex items-center gap-1.5 rounded-full bg-primary px-3 py-1 text-xs font-bold text-primary-foreground shadow-sm hover:opacity-90"
                >
                  <ExternalLink className="h-3 w-3" /> 콜라보 영상 보기
                </a>
              )}
              <div className="mt-2 flex flex-wrap gap-1.5 text-[11px]">
                <Badge variant="secondary">{p.collabCount} 콜라보</Badge>
                {p.master?.creatorType && <Badge variant="outline">{p.master.creatorType}</Badge>}
                {p.master?.status && <Badge variant="outline">{p.master.status}</Badge>}
                {p.followers != null && <Badge variant="outline">팔로워 {fmtFollowers(p.followers)}</Badge>}
              </div>
            </div>
            <div className="text-right">
              <div className="text-[10px] font-semibold uppercase text-muted-foreground">최고 등급</div>
              <div className="text-3xl font-bold">{p.finalGrade === "NA" ? "—" : p.finalGrade}</div>
              <div className="text-[11px] text-muted-foreground">
                {p.finalGrade === "NA" ? "데이터 부족" : `최고 콘텐츠 등급`}
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      <section className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">비용 합계</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5 text-sm">
            <Line label="보수" value={fmtKrw(p.totalFeeJpy)} />
            <Line label="제품 원가" value={fmtKrw(p.totalCogsJpy)} />
            <Line label="WL 광고비" value={fmtKrw(p.totalWlSpendJpy)} bold />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">노출 합계</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5 text-sm">
            <Line label="Organic D+14 합" value={fmtViews(p.totalOrganicView || null)} />
            <Line label="WL impressions" value={fmtViews(p.totalWlImpressions || null)} />
            <Line label="평균 VTR" value={fmtVtr(p.avgOrganicVtr)} bold />
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">평균 단가</CardTitle>
          </CardHeader>
          <CardContent className="space-y-1.5 text-sm">
            <Line label="Organic 단가" value={fmtRate(p.avgOrganicRate)} bold />
            <Line label="WL CPM" value={fmtRate(p.avgWlCpm)} />
            <Line label="ER 평균" value={p.avgEngagementRate != null ? fmtPct(p.avgEngagementRate, 1) : "—"} />
          </CardContent>
        </Card>
      </section>

      <section>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          <Stat label="평균 D+14 view" value={fmtViews(p.avgD30Views)} hint="발현률 normalize 포함" />
          <Stat label="현재 누적 view (평균)" value={fmtViews(p.avgCurrentViews)} />
          <Stat label="정량 percentile" value={p.quantPercentile != null ? `${p.quantPercentile.toFixed(0)}%` : "—"} />
          <Stat label="정성 Overall 평균" value={p.qualitativeMean != null ? p.qualitativeMean.toFixed(2) : "—"} />
          <Stat label="Master Compliance" value={p.master?.complianceRating || "—"} />
          <Stat label="Master Overall" value={p.master?.overallRating || "—"} />
        </div>
      </section>

      {seriesList.filter((s) => s.organic.length > 0 || (s.paid && s.paid.length > 0)).map((s, i) => (
        <Card key={`chart-${s.c.internalId}-${i}`}>
          <CardHeader className="pb-2">
            <div className="flex flex-wrap items-center gap-2">
              <CardTitle className="text-base">콘텐츠 지표 — {s.c.product || "콘텐츠"}</CardTitle>
              {s.c.hasWl
                ? <Badge variant="default" className="text-[10px]">WL · organic + paid</Badge>
                : <Badge variant="secondary" className="text-[10px]">organic</Badge>}
              {s.c.period && <span className="text-[11px] text-muted-foreground">{s.c.period}</span>}
              <TagDetail tag={s.c.postShortcode ? tags.get(s.c.postShortcode) : undefined} />
            </div>
          </CardHeader>
          <CardContent>
            <ContentCharts organic={s.organic} paid={s.c.hasWl ? s.paid : null} />
          </CardContent>
        </Card>
      ))}

      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">콜라보 이력 ({p.collabs.length})</CardTitle>
          <p className="text-xs text-muted-foreground">행 색 = 콘텐츠 등급</p>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollableTable>
          <Table className="min-w-[1100px]">
            <TableHeader>
              <TableRow>
                <TableHead className="w-[60px]">등급</TableHead>
                <TableHead>기간</TableHead>
                <TableHead>제품 (SKU)</TableHead>
                <TableHead className="w-[180px]">태그(자동)</TableHead>
                <TableHead>Deal</TableHead>
                <TableHead className="text-right">Fee</TableHead>
                <TableHead className="text-right">COGS</TableHead>
                <TableHead className="text-right">WL spend</TableHead>
                <TableHead className="text-right">D+14 view</TableHead>
                <TableHead className="text-right">단가</TableHead>
                <TableHead className="text-right">VTR</TableHead>
                <TableHead className="text-right">ER</TableHead>
                <TableHead className="text-right">정성</TableHead>
                <TableHead>URL</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {p.collabs.map((c: EnrichedCollab, i: number) => (
                <TableRow key={`${c.internalId}-${i}`}>
                  <TableCell><GradeChip grade={c.finalGrade} size={24} bump={c.qualBump} /></TableCell>
                  <TableCell className="text-xs">{c.period}</TableCell>
                  <TableCell className="max-w-[180px]">
                    <div className="truncate text-sm font-medium">{c.product || "—"}</div>
                    <div className="text-[11px] text-muted-foreground">
                      {c.cogs.sku ? `SKU: ${c.cogs.sku}` : "—"}
                    </div>
                  </TableCell>
                  <TableCell className="align-top">
                    <TagDetail tag={c.postShortcode ? tags.get(c.postShortcode) : undefined} />
                  </TableCell>
                  <TableCell>
                    {(() => {
                      const dt = (c.dealType ?? "").trim().toLowerCase();
                      const isPaid = dt === "paid";
                      const label = isPaid ? "Paid" : dt ? "Gift" : "—";
                      return (
                        <Badge variant={isPaid ? "default" : "secondary"} className="text-[10px]">
                          {label}
                        </Badge>
                      );
                    })()}
                  </TableCell>
                  <TableCell className="text-right tabular-nums text-sm">
                    {c.feeKrw > 0 ? fmtKrw(c.feeKrw) : <span className="text-muted-foreground">—</span>}
                  </TableCell>
                  <TableCell className="text-right tabular-nums text-sm">
                    {c.cogs.unitKrw > 0 ? fmtKrw(c.cogs.unitKrw) : <span className="text-muted-foreground">—</span>}
                  </TableCell>
                  <TableCell className="text-right tabular-nums text-sm">
                    {c.wlSpendKrw > 0 ? fmtKrw(c.wlSpendKrw) : <span className="text-muted-foreground">—</span>}
                  </TableCell>
                  <TableCell className="text-right tabular-nums text-sm">
                    <div>{fmtViews(c.organicView)}</div>
                    {c.viewMethod === "normalized" && c.viewSourceAge != null && (
                      <div className="text-[9px] text-muted-foreground">D+{c.viewSourceAge}→환산</div>
                    )}
                  </TableCell>
                  <TableCell className="text-right tabular-nums text-sm font-medium">
                    {fmtRate(c.organicRateJpyPerView)}
                  </TableCell>
                  <TableCell className="text-right tabular-nums text-sm">
                    {fmtVtr(c.organicVtr)}
                  </TableCell>
                  <TableCell className="text-right tabular-nums text-sm">
                    {c.engagementRate != null ? fmtPct(c.engagementRate, 1) : "—"}
                  </TableCell>
                  <TableCell className="text-right tabular-nums text-sm">{c.overall || "—"}</TableCell>
                  <TableCell className="max-w-[80px]">
                    {c.url ? (
                      <a href={c.url} target="_blank" rel="noopener noreferrer" className="text-xs text-primary underline truncate block">
                        보기
                      </a>
                    ) : "—"}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          </ScrollableTable>
        </CardContent>
      </Card>

      {p.collabs.some((c) => c.overall) && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">정성 6축 평균</CardTitle>
            <p className="text-xs text-muted-foreground">시트 Performance Evaluation 그룹</p>
          </CardHeader>
          <CardContent>
            <QualBreakdown collabs={p.collabs} />
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function TagDetail({ tag }: { tag?: ContentTag }) {
  if (!tag) return <span className="text-xs text-muted-foreground">—</span>;
  // 상세 페이지는 넓으니 클릭 없이 처음부터 설명까지 펼침
  return (
    <div className="space-y-0.5 text-[11px] leading-snug">
      <div className="flex flex-wrap items-center gap-1">
        <Badge variant="secondary" className="text-[10px]">{tag.kmPrimary || "—"}</Badge>
        <Badge variant="outline" className="text-[10px]">{tag.hookPrimary || "—"}</Badge>
        {tag.confidence && (
          <span className={cn("text-[10px]", tag.confidence === "低" ? "text-[var(--bad-fg)]" : "text-muted-foreground")}>
            信 {tag.confidence}
          </span>
        )}
      </div>
      <div className="text-muted-foreground"><span className="font-semibold text-foreground">키메세지</span> {tag.kmPrimaryDesc || "—"}</div>
      <div className="text-muted-foreground"><span className="font-semibold text-foreground">훅</span> {tag.hookPrimaryName || "—"}</div>
      {tag.kmSub && <div className="text-muted-foreground"><span className="font-semibold text-foreground">부</span> {tag.kmSub}</div>}
    </div>
  );
}

function Stat({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <Card className="border-border/60 bg-card/80">
      <CardContent className="p-3">
        <div className="text-[10px] font-semibold uppercase text-muted-foreground">{label}</div>
        <div className="mt-1 text-base font-bold tabular-nums">{value}</div>
        {hint && <div className="text-[10px] text-muted-foreground">{hint}</div>}
      </CardContent>
    </Card>
  );
}

function Line({ label, value, bold }: { label: string; value: string; bold?: boolean }) {
  return (
    <div className="flex items-baseline justify-between">
      <span className={cn("text-xs", bold ? "font-semibold" : "text-muted-foreground")}>{label}</span>
      <span className={cn("tabular-nums", bold ? "text-base font-bold" : "text-sm")}>{value}</span>
    </div>
  );
}

interface CollabLite {
  scriptFollow: string;
  compliance: string;
  easeOfWork: string;
  hook: string;
  wowScene: string;
  overall: string;
}

function QualBreakdown({ collabs }: { collabs: CollabLite[] }) {
  const axes: { key: keyof CollabLite; label: string }[] = [
    { key: "scriptFollow", label: "Script Follow" },
    { key: "compliance", label: "Compliance" },
    { key: "easeOfWork", label: "Ease-of-work" },
    { key: "hook", label: "Hook" },
    { key: "wowScene", label: "Wow Scene" },
    { key: "overall", label: "Overall" },
  ];
  function parseScore(s: string): number | null {
    if (!s) return null;
    const n = parseFloat(s.replace(/[^\d.]/g, ""));
    return Number.isFinite(n) ? n : null;
  }
  function mean(xs: (number | null)[]): number | null {
    const v = xs.filter((x): x is number => x != null);
    if (!v.length) return null;
    return v.reduce((a, b) => a + b, 0) / v.length;
  }
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
      {axes.map((a) => {
        const m = mean(collabs.map((c) => parseScore(c[a.key])));
        return (
          <div key={a.key} className="rounded-lg border border-border/60 bg-secondary/40 p-3">
            <div className="text-[10px] font-semibold uppercase text-muted-foreground">{a.label}</div>
            <div className="mt-1 text-lg font-bold tabular-nums">{m != null ? m.toFixed(2) : "—"}</div>
          </div>
        );
      })}
    </div>
  );
}
