// 제품명 표기 통일 (2026-06-10 세은 지시): 상품명+용량-색상
//   ppsu200-pink / ppsu300-skyblue ... (pink, skyblue, white, charcoal)
//   stain200-bear / stain300-cherry ... (bear, cherry, olive)
//   fliptop-dino / fliptop-unicorn (용량 없음)
// 패턴 매칭 실패 시 시트 원문 그대로 반환.

// 타입별 허용 색상 (세은 정의) — 셀에 다른 제품 단어가 섞여도 해당 타입 색상만 채택
const COLORS: Record<string, string[]> = {
  ppsu: ["pink", "skyblue", "white", "charcoal"],
  stain: ["bear", "cherry", "olive"],
  fliptop: ["dino", "unicorn"],
};
const SIZE_RE = /(200|300)/;

export function normalizeProduct(raw: string): string {
  const trimmed = (raw ?? "").trim();
  if (!trimmed) return "";
  const s = trimmed.toLowerCase().replace(/sky\s+blue/g, "skyblue");

  const type = s.includes("ppsu")
    ? "ppsu"
    : s.includes("stain")
      ? "stain"
      : s.includes("flip")
        ? "fliptop"
        : null;
  if (!type) return trimmed;

  let color: string | null = null;
  let colorIdx = Infinity;
  for (const c of COLORS[type]) {
    const idx = s.indexOf(c);
    if (idx >= 0 && idx < colorIdx) {
      color = c;
      colorIdx = idx;
    }
  }

  if (type === "fliptop") return color ? `fliptop-${color}` : "fliptop";

  const sizeMatch = s.match(SIZE_RE);
  const size = sizeMatch ? sizeMatch[1] : "";
  return `${type}${size}${color ? `-${color}` : ""}`;
}
