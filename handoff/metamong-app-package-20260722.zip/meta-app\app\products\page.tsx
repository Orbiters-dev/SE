import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { EnvWarning } from "@/components/meta/EnvWarning";
import { fetchProductMetrics } from "@/lib/product-metrics";
import { fmtWon, fmtNum } from "@/lib/format";

export const revalidate = 3600;   // 1시간 캐시
export const maxDuration = 60;    // RMS 다중 호출 대비

interface UniRow {
  month: string;
  access: number;
  lpv: number;
  ratio: number;     // 메타 유입 비중 %
  orders: number;
  cplpv: number;
  spend: number;
  cvr: number;       // 전환율 %
  inProgress: boolean;
}

export default async function ProductsPage() {
  let body: React.ReactNode;
  try {
    const { rows, totalMonthly, thisMonth } = await fetchProductMetrics();

    const total: UniRow[] = totalMonthly.map((t) => ({
      month: t.month, access: t.access, lpv: t.metaLpv, ratio: t.ratio,
      orders: t.orders, cplpv: t.cplpv, spend: t.spend, cvr: t.cvr, inProgress: t.inProgress,
    }));
    const byProduct = (p: "PPSU" | "Stainless"): UniRow[] =>
      rows
        .filter((r) => r.product === p)
        .sort((a, b) => b.month.localeCompare(a.month))
        .map((r) => ({
          month: r.month, access: r.access, lpv: r.lpv, ratio: r.ratio,
          orders: r.orders, cplpv: r.cplpv, spend: r.spend, cvr: r.cvr, inProgress: r.inProgress,
        }));

    body = (
      <>
        <section>
          <div className="mb-1 flex items-baseline justify-between">
            <h1 className="text-xl font-bold tracking-tight">제품 성과 (전환)</h1>
            <span className="text-xs text-muted-foreground">전체 · PPSU · Stainless · 월별</span>
          </div>
          <p className="text-xs text-muted-foreground">
            <b>전체 = PPSU + Stainless 합</b> (니플·교체스트로 등 제외). 메타유입 = Meta가 Rakuten LP로 보낸 LPV(ad_name ASIN 분류).
            접속자수·주문·전환율 = RMS 商品ページ API(visitAll/unitsAll, 商品管理番号 분류). 유입 비중 = 메타유입 ÷ 접속자수.
            {" "}1~{thisMonth.slice(5)}월 전부 RMS 실측, 매일 09:00 자동 갱신.
          </p>
        </section>

        <MetricCard title="전체 (PPSU + Stainless)" rows={total} />
        <MetricCard title="PPSU" rows={byProduct("PPSU")} />
        <MetricCard title="Stainless" rows={byProduct("Stainless")} />
      </>
    );
  } catch (e) {
    body = <EnvWarning error={e instanceof Error ? e.message : String(e)} />;
  }
  return <div className="space-y-6">{body}</div>;
}

function MetricCard({ title, rows }: { title: string; rows: UniRow[] }) {
  const sumLpv = rows.reduce((s, r) => s + r.lpv, 0);
  const sumOrders = rows.reduce((s, r) => s + r.orders, 0);
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-baseline justify-between gap-2">
          <CardTitle className="text-base">{title}</CardTitle>
          <span className="text-xs text-muted-foreground">누적 유입 {fmtNum(sumLpv)} · 주문 {fmtNum(sumOrders)}</span>
        </div>
      </CardHeader>
      <CardContent className="overflow-x-auto p-0">
        <Table className="md:min-w-[860px]">
          <TableHeader>
            <TableRow>
              <TableHead>월</TableHead>
              <TableHead className="text-right">접속자수</TableHead>
              <TableHead className="text-right">메타유입</TableHead>
              <TableHead className="text-right">유입비중</TableHead>
              <TableHead className="hidden text-right md:table-cell">주문</TableHead>
              <TableHead className="hidden text-right md:table-cell">CPLPV</TableHead>
              <TableHead className="hidden text-right md:table-cell">Spend</TableHead>
              <TableHead className="text-right">전환율</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((r) => (
              <TableRow key={r.month} className="hover:bg-secondary/40">
                <TableCell className="font-medium">
                  {r.month}
                  {r.inProgress && <span className="ml-1.5 align-middle text-[10px] font-semibold text-muted-foreground">진행중</span>}
                </TableCell>
                <TableCell className="text-right tabular-nums">{r.access > 0 ? fmtNum(r.access) : "—"}</TableCell>
                <TableCell className="text-right tabular-nums">{r.lpv > 0 ? fmtNum(r.lpv) : "—"}</TableCell>
                <TableCell className="text-right tabular-nums font-semibold">{r.access > 0 && r.lpv > 0 ? `${r.ratio.toFixed(1)}%` : "—"}</TableCell>
                <TableCell className="hidden text-right tabular-nums md:table-cell">{r.orders > 0 ? fmtNum(r.orders) : "—"}</TableCell>
                <TableCell className="hidden text-right tabular-nums md:table-cell">{r.cplpv > 0 ? fmtWon(r.cplpv) : "—"}</TableCell>
                <TableCell className="hidden text-right tabular-nums md:table-cell">{r.spend > 0 ? fmtWon(r.spend) : "—"}</TableCell>
                <TableCell className="text-right tabular-nums">{r.access > 0 && r.orders > 0 ? `${r.cvr.toFixed(2)}%` : "—"}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
