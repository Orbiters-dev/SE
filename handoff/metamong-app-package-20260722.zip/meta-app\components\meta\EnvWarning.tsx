import { Card, CardContent } from "@/components/ui/card";
import { Monkey } from "@/components/meta/Monkey";

export function EnvWarning({ error }: { error: string }) {
  return (
    <Card>
      <CardContent className="flex flex-col items-center gap-3 p-8 text-center">
        <Monkey mood="dizzy" size={84} />
        <div>
          <h2 className="text-base font-bold">데이터를 불러오지 못했어요</h2>
          <p className="mt-1 text-sm text-muted-foreground">{error}</p>
        </div>
        <p className="text-xs text-muted-foreground">
          <code className="rounded bg-muted px-1 py-0.5">.env.local</code> 의{" "}
          <code className="rounded bg-muted px-1 py-0.5">META_JP_ACCESS_TOKEN</code> ·{" "}
          <code className="rounded bg-muted px-1 py-0.5">META_JP_AD_ACCOUNT_ID</code> 확인 필요
        </p>
      </CardContent>
    </Card>
  );
}
