"use client";

// 콘텐츠 풀 목록 셀 — 태그 칩 요약만 표시, 클릭 시 편집 모달(TagEditor + 자동 태그 상세).
// 목록 인라인 드롭다운 제거 (2026-07-13 세은: "목록은 탭만, 클릭해서 수정").

import { useEffect, useState } from "react";
import { TagEditor } from "./TagEditor";
import type { KmGroup, TaxonomyOption } from "@/lib/sheets-types";

interface Props {
  shortcode: string | null;
  handle: string;          // @없이
  url: string | null;      // 영상 링크 (모달 헤더)
  kmAuto: string;
  hookAuto: string;
  kmManual: string[];
  hookManual: string[];
  kmAutoRejected: boolean;
  kmPrimaryDesc: string;
  kmSub: string;
  hookPrimaryName: string;
  evidence: string;
  confidence: string;
  kmGroups: KmGroup[];
  hooks: TaxonomyOption[];
}

const short = (s: string, n = 24) => (s.length > n ? `${s.slice(0, n)}…` : s);

export function TagCell(p: Props) {
  const [open, setOpen] = useState(false);
  // TagEditor 저장 성공을 미러 — 모달 닫아도 요약 칩이 최신 상태 유지
  const [km, setKm] = useState<string[]>(p.kmManual);
  const [hook, setHook] = useState<string[]>(p.hookManual);
  const [kmRejected, setKmRejected] = useState<boolean>(p.kmAutoRejected);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  const kmLabel = (code: string) => {
    for (const g of p.kmGroups) {
      const o = g.options.find((x) => x.code === code);
      if (o) return o.label;
    }
    return "";
  };
  const hookLabel = (code: string) => p.hooks.find((x) => x.code === code)?.label ?? "";

  if (!p.shortcode) {
    return <span className="text-xs text-muted-foreground">URL 없음</span>;
  }

  function SummaryChips({ list, auto, rejected, labelOf }: {
    list: string[]; auto: string; rejected?: boolean; labelOf: (c: string) => string;
  }) {
    if (list.length > 0) {
      return (
        <>
          {list.map((code) => (
            <span
              key={code}
              className="inline-flex max-w-[200px] truncate rounded bg-[var(--good-bg)] px-1.5 py-0.5 text-[10px] font-medium text-[var(--good-fg)]"
              title={`${code} ${labelOf(code)}`}
            >
              {code} {short(labelOf(code), 16)}
            </span>
          ))}
        </>
      );
    }
    if (rejected) {
      return <span className="text-[10px] text-muted-foreground">— 미분류 (자동 기각)</span>;
    }
    return auto ? (
      <span
        className="inline-flex max-w-[200px] truncate rounded bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground"
        title={`자동 태그: ${auto} ${labelOf(auto)}`}
      >
        자동 {auto} {short(labelOf(auto), 16)}
      </span>
    ) : (
      <span className="text-[10px] text-muted-foreground">— 미분류</span>
    );
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        title="클릭해서 태그 편집"
        className="block w-full rounded-md p-1 -m-1 text-left hover:bg-muted/60 hover:ring-1 hover:ring-ring/40"
      >
        <div className="space-y-0.5">
          <div className="flex flex-wrap items-center gap-1">
            <span className="w-[20px] shrink-0 text-[9px] font-semibold text-muted-foreground">KM</span>
            <SummaryChips list={km} auto={p.kmAuto} rejected={kmRejected} labelOf={kmLabel} />
          </div>
          <div className="flex flex-wrap items-center gap-1">
            <span className="w-[20px] shrink-0 text-[9px] font-semibold text-muted-foreground">훅</span>
            <SummaryChips list={hook} auto={p.hookAuto} labelOf={hookLabel} />
          </div>
        </div>
      </button>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4"
          onClick={() => setOpen(false)}
        >
          <div
            className="max-h-[85vh] w-full max-w-md overflow-y-auto rounded-lg border bg-background p-4 shadow-xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-3 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 truncate">
                <span className="truncate text-sm font-semibold">@{p.handle}</span>
                {p.url && (
                  <a
                    href={p.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="shrink-0 rounded-full bg-primary/90 px-2 py-0.5 text-[10px] font-semibold text-primary-foreground hover:bg-primary"
                  >
                    영상 ↗
                  </a>
                )}
              </div>
              <button
                type="button"
                aria-label="닫기"
                className="shrink-0 rounded px-1.5 text-lg leading-none text-muted-foreground hover:bg-muted"
                onClick={() => setOpen(false)}
              >
                ×
              </button>
            </div>

            <TagEditor
              shortcode={p.shortcode}
              kmAuto={p.kmAuto}
              hookAuto={p.hookAuto}
              kmManual={km}
              hookManual={hook}
              kmAutoRejected={kmRejected}
              kmGroups={p.kmGroups}
              hooks={p.hooks}
              onChange={(s) => { setKm(s.km); setHook(s.hook); setKmRejected(s.kmRejected); }}
            />

            {(p.kmPrimaryDesc || p.hookPrimaryName || p.evidence) && (
              <div className="mt-3 space-y-1 rounded-md border bg-muted/40 p-2 text-[11px] leading-snug">
                <div className="text-[9px] font-semibold text-muted-foreground">자동 태그 상세 (LLM 분류 근거)</div>
                {p.kmPrimaryDesc && <div><span className="font-semibold">키메세지</span> {p.kmPrimaryDesc}</div>}
                {p.kmSub && <div><span className="font-semibold">부</span> {p.kmSub}</div>}
                {p.hookPrimaryName && <div><span className="font-semibold">훅</span> {p.hookPrimaryName}</div>}
                {p.evidence && <div><span className="font-semibold">근거</span> {p.evidence}</div>}
                {p.confidence && <div><span className="font-semibold">신뢰</span> {p.confidence}</div>}
              </div>
            )}
            <div className="mt-2 text-[10px] text-muted-foreground">
              틀린 자동 태그는 × 로 기각 — 기각·수동 교정은 다음 자동 태깅부터 학습됩니다.
            </div>
          </div>
        </div>
      )}
    </>
  );
}
