// SERVER-ONLY. ad_id → 콘텐츠 풀 등급 태깅.
// buildContentPool 의 WL 귀속 결과(wlAdIds)를 뒤집어 ad_id 인덱스로 만든다.

import "server-only";
import { buildContentPool, type Grade } from "./influencer-aggregation";

export interface AdGradeTag {
  igHandle: string;
  wlGrade: Grade;
  organicGrade: Grade;
  product: string;
}

export async function buildAdGradeMap(): Promise<Map<string, AdGradeTag>> {
  const map = new Map<string, AdGradeTag>();
  try {
    const pool = await buildContentPool();
    for (const c of pool) {
      for (const id of c.wlAdIds) {
        map.set(id, {
          igHandle: c.igHandle,
          wlGrade: c.wlGrade,
          organicGrade: c.organicGrade,
          product: c.product,
        });
      }
    }
  } catch {
    // 풀 빌드 실패 시 태깅 없이 진행 (광고 페이지 자체는 떠야 함)
  }
  return map;
}
