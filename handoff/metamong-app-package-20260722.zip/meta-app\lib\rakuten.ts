// SERVER-ONLY. Rakuten RMS Order API client (TS port of tools/rakuten_rms_client.py).
// Auth: ESA header (RMS_ESA_AUTH env = "ESA base64(serviceSecret:licenseKey)").
// Used for product-level monthly order units (PPSU / Stainless) on the Products tab.
//
// NOTE: RMS searchOrder 403s on long date ranges (rate/range limit). Keep windows short
// (<= ~40 days). Past months use static seed in product-metrics.ts; only the current
// month is fetched live here.

import "server-only";

const BASE = "https://api.rms.rakuten.co.jp";

function authHeader(): string {
  const v = process.env.RMS_ESA_AUTH;
  if (!v) throw new Error("RMS_ESA_AUTH missing in env");
  return v;
}

// JST datetime string: "YYYY-MM-DDTHH:MM:SS+0900"
function jstStamp(d: Date): string {
  const jst = new Date(d.getTime() + 9 * 3600 * 1000);
  const p = (n: number) => String(n).padStart(2, "0");
  return (
    `${jst.getUTCFullYear()}-${p(jst.getUTCMonth() + 1)}-${p(jst.getUTCDate())}` +
    `T${p(jst.getUTCHours())}:${p(jst.getUTCMinutes())}:${p(jst.getUTCSeconds())}+0900`
  );
}

async function rmsPost<T>(path: string, body: unknown, revalidate: number): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json;charset=UTF-8",
      Authorization: authHeader(),
    },
    body: JSON.stringify(body),
    next: { revalidate },
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`RMS ${path} ${res.status}: ${txt.slice(0, 200)}`);
  }
  return (await res.json()) as T;
}

interface SearchOrderResp {
  orderNumberList?: string[];
  PaginationResponseModel?: { totalPages?: number };
}

// searchOrder in 7-day chunks (dateType=1 = order date). Returns unique order numbers.
async function searchOrderNumbers(since: Date, until: Date, revalidate: number): Promise<string[]> {
  const seen = new Set<string>();
  const chunkMs = 7 * 86_400_000;
  for (let start = since.getTime(); start < until.getTime(); start += chunkMs) {
    const chunkStart = new Date(start);
    const chunkEnd = new Date(Math.min(start + chunkMs, until.getTime()));
    let page = 1;
    for (;;) {
      const data = await rmsPost<SearchOrderResp>(
        "/es/2.0/order/searchOrder",
        {
          dateType: 1,
          startDatetime: jstStamp(chunkStart),
          endDatetime: jstStamp(chunkEnd),
          PaginationRequestModel: { requestRecordsAmount: 1000, requestPage: page },
        },
        revalidate,
      );
      for (const n of data.orderNumberList ?? []) seen.add(n);
      const total = data.PaginationResponseModel?.totalPages ?? 1;
      if (page >= total) break;
      page += 1;
    }
  }
  return [...seen];
}

interface OrderItem {
  manageNumber?: string;
  units?: number;
}
interface OrderPackage {
  ItemModelList?: OrderItem[];
}
interface OrderModel {
  orderDatetime?: string;
  orderProgress?: number;
  PackageModelList?: OrderPackage[];
}
interface GetOrderResp {
  OrderModelList?: OrderModel[];
}

async function getOrders(numbers: string[], revalidate: number): Promise<OrderModel[]> {
  const out: OrderModel[] = [];
  for (let i = 0; i < numbers.length; i += 100) {
    const batch = numbers.slice(i, i + 100);
    const data = await rmsPost<GetOrderResp>(
      "/es/2.0/order/getOrder",
      { orderNumberList: batch, version: 3 },
      revalidate,
    );
    out.push(...(data.OrderModelList ?? []));
  }
  return out;
}

export type Product = "PPSU" | "Stainless";

// manageNumber → product. Nipple/straw refills (grosmimi_srawnipple…) excluded → null.
export function classifyProduct(manageNumber?: string): Product | null {
  if (!manageNumber) return null;
  const mn = manageNumber.toLowerCase();
  if (mn.includes("ppsu")) return "PPSU";
  if (mn.includes("stainless")) return "Stainless";
  return null;
}

// orderProgress 900 = 캔슬확정 (취소 제외). 그 외는 유효 주문으로 집계.
const CANCELLED_PROGRESS = new Set<number>([900]);

export interface ProductOrderUnits {
  // key "YYYY-MM" → { PPSU, Stainless } (units 합산, 니플·취소 제외)
  [month: string]: { PPSU: number; Stainless: number };
}

// 최근 windowDays(<=40 권장) 주문 → 월별 제품 units. 현재 달 라이브 집계용.
export async function fetchProductOrderUnits(
  windowDays = 35,
  revalidate = 3600,
): Promise<ProductOrderUnits> {
  const until = new Date();
  const since = new Date(until.getTime() - windowDays * 86_400_000);
  const numbers = await searchOrderNumbers(since, until, revalidate);
  const out: ProductOrderUnits = {};
  if (numbers.length === 0) return out;
  const orders = await getOrders(numbers, revalidate);
  for (const o of orders) {
    if (o.orderProgress !== undefined && CANCELLED_PROGRESS.has(o.orderProgress)) continue;
    const month = (o.orderDatetime ?? "").slice(0, 7);
    if (!month) continue;
    for (const pkg of o.PackageModelList ?? []) {
      for (const it of pkg.ItemModelList ?? []) {
        const prod = classifyProduct(it.manageNumber);
        if (!prod) continue;
        const bucket = out[month] ?? (out[month] = { PPSU: 0, Stainless: 0 });
        bucket[prod] += it.units ?? 0;
      }
    }
  }
  return out;
}
