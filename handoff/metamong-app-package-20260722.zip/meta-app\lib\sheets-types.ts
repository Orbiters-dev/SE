// sheets.ts(서버 전용)와 클라이언트 컴포넌트가 공유하는 순수 타입.

export interface TaxonomyOption { code: string; label: string; group?: string }
export interface KmGroup { subject: string; subjectName: string; options: TaxonomyOption[] }
export interface Taxonomy { kmGroups: KmGroup[]; hooks: TaxonomyOption[] }
