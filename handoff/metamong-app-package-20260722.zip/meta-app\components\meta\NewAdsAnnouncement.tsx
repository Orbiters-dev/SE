"use client";

// 최근 신규 등록 광고 + 효율 (2026-07-01, 24h 한정) — 메타몽.
// 표시 게이트는 AnnouncementStack이 관리 (결산 팝업 다음 순서). 여기는 표시 전용.
// ~2026-07-02 19:30 KST(10:30 UTC) 자동 미표시. X 닫기 = 같은 탭 세션 동안 다시 안 뜸.
// 효율 = 최근 창(6/17~7/1) 실측. 운영중 / OFF 분리, 각 CPLPV 오름차순. Testing/Proven 표기.

import { X } from "lucide-react";
import { Monkey } from "@/components/meta/Monkey";
import { cn } from "@/lib/utils";

export const NEW_ADS_SHOW_UNTIL_UTC = Date.UTC(2026, 6, 2, 10, 30, 0); // 2026-07-02 19:30 KST
export const NEW_ADS_DISMISS_KEY = "new_ads_20260701_dismissed";

interface AdRow {
  created: string;
  creator: string;
  stage: "Proven" | "Testing";
  type: string; // WL-G / WL-P
  line: string; // PPSU / Stainless / —
  cplpv: number | null;
  ctr: number;
  cpc: number;
  spend: number;
  status: "운영중" | "OFF";
}

// 최근 등록(>=6/17) 광고, 운영중 → OFF, 각 CPLPV 오름차순
const ADS: AdRow[] = [
  { created: "6/30", creator: "rhythmical_mama", stage: "Testing", type: "WL-P", line: "—", cplpv: 73, ctr: 14.65, cpc: 49, spend: 12258, status: "운영중" },
  { created: "6/19", creator: "ichikuru_fufu", stage: "Proven", type: "WL-G", line: "PPSU", cplpv: 96, ctr: 10.83, cpc: 72, spend: 425266, status: "운영중" },
  { created: "6/19", creator: "aomaru_diary", stage: "Proven", type: "WL-G", line: "PPSU", cplpv: 115, ctr: 10.91, cpc: 91, spend: 9637, status: "운영중" },
  { created: "6/19", creator: "can_twins_", stage: "Proven", type: "WL-P", line: "Stainless", cplpv: 133, ctr: 7.61, cpc: 90, spend: 1051188, status: "운영중" },
  { created: "6/19", creator: "ebi_ikuji", stage: "Testing", type: "WL-G", line: "PPSU", cplpv: 135, ctr: 6.7, cpc: 119, spend: 96644, status: "운영중" },
  { created: "6/19", creator: "minkoro_kosodate", stage: "Testing", type: "WL-P", line: "Stainless", cplpv: 135, ctr: 6.51, cpc: 111, spend: 97143, status: "운영중" },
  { created: "6/30", creator: "nee_and_twins", stage: "Proven", type: "WL-G", line: "PPSU", cplpv: 138, ctr: 6.96, cpc: 106, spend: 23470, status: "운영중" },
  { created: "6/19", creator: "arara_norarara", stage: "Proven", type: "WL-G", line: "Stainless", cplpv: 145, ctr: 8.07, cpc: 86, spend: 112079, status: "운영중" },
  { created: "6/19", creator: "yukina_mum", stage: "Testing", type: "WL-P", line: "PPSU", cplpv: 153, ctr: 7.72, cpc: 134, spend: 96664, status: "운영중" },
  { created: "6/19", creator: "nopi_ikuji", stage: "Proven", type: "WL-G", line: "PPSU", cplpv: 192, ctr: 5.89, cpc: 123, spend: 5175, status: "운영중" },
  { created: "6/19", creator: "nee_and_twins", stage: "Testing", type: "WL-G", line: "PPSU", cplpv: 87, ctr: 11.39, cpc: 71, spend: 88090, status: "OFF" },
  { created: "6/19", creator: "rii_mama_ikuji", stage: "Testing", type: "WL-P", line: "PPSU", cplpv: 182, ctr: 6.5, cpc: 149, spend: 96787, status: "OFF" },
];

function cplpvTone(v: number | null) {
  if (v === null) return "bg-secondary text-muted-foreground";
  if (v <= 110) return "bg-emerald-100 text-emerald-700";
  if (v <= 140) return "bg-amber-100 text-amber-700";
  return "bg-rose-100 text-rose-700";
}

function stageTone(s: AdRow["stage"]) {
  return s === "Proven"
    ? "bg-emerald-50 text-emerald-600"
    : "bg-indigo-50 text-indigo-600";
}

function AdItem({ a }: { a: AdRow }) {
  return (
    <div className="flex items-center gap-3 rounded-xl border border-border/60 bg-secondary/30 px-3 py-2.5">
      <span
        className={cn(
          "flex h-10 w-14 shrink-0 flex-col items-center justify-center rounded-lg text-[13px] font-bold leading-none",
          cplpvTone(a.cplpv),
        )}
      >
        <span className="text-[9px] font-medium opacity-70">CPLPV</span>
        ₩{a.cplpv ?? "-"}
      </span>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5">
          <span className="truncate text-[13px] font-bold">{a.creator}</span>
          <span
            className={cn(
              "shrink-0 rounded px-1 py-0.5 text-[9px] font-semibold",
              stageTone(a.stage),
            )}
          >
            {a.stage}
          </span>
        </div>
        <div className="mt-0.5 text-[11px] text-muted-foreground">
          {a.created} · {a.type} · {a.line} · CTR {a.ctr}% · CPC ₩{a.cpc} · ₩{a.spend.toLocaleString()}
        </div>
      </div>
    </div>
  );
}

export function NewAdsAnnouncement({ onClose }: { onClose: () => void }) {
  const dismiss = () => {
    sessionStorage.setItem(NEW_ADS_DISMISS_KEY, "1");
    onClose();
  };

  const running = ADS.filter((a) => a.status === "운영중");
  const off = ADS.filter((a) => a.status === "OFF");

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={dismiss} />
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-border bg-background shadow-2xl">
        <button
          onClick={dismiss}
          aria-label="닫기"
          className="absolute right-3 top-3 rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <X className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-3 border-b border-border/60 bg-secondary/40 px-5 py-4">
          <Monkey mood="rich" size={48} />
          <div>
            <div className="text-base font-bold tracking-tight">최근 신규 광고 · 효율</div>
            <div className="text-xs text-muted-foreground">등록 6/17~ · 효율 6/17~7/1 실측 · 메타몽</div>
          </div>
        </div>
        <div className="max-h-[62vh] overflow-y-auto px-4 py-4">
          <div className="mb-1.5 flex items-center gap-2">
            <span className="text-[11px] font-bold text-emerald-600">● 운영 중</span>
            <span className="text-[11px] text-muted-foreground">{running.length}건</span>
          </div>
          <div className="space-y-2">
            {running.map((a, i) => (
              <AdItem key={`r${i}`} a={a} />
            ))}
          </div>

          <div className="mb-1.5 mt-4 flex items-center gap-2">
            <span className="text-[11px] font-bold text-muted-foreground">● OFF (정지)</span>
            <span className="text-[11px] text-muted-foreground">{off.length}건</span>
          </div>
          <div className="space-y-2 opacity-70">
            {off.map((a, i) => (
              <AdItem key={`o${i}`} a={a} />
            ))}
          </div>

          <div className="mt-3 rounded-lg bg-secondary/40 px-3 py-2 text-[11px] leading-relaxed text-muted-foreground">
            CPLPV 색: 초록 ≤₩110 · 노랑 ≤₩140 · 빨강 &gt;₩140 · 풀평균 ₩124 · 단계 Proven/Testing 표기
          </div>
        </div>
      </div>
    </div>
  );
}
