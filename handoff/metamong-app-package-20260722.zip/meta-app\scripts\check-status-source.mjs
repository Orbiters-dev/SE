// 절대 룰 가드 (2026-07-09 세은): 광고 on/off(effective_status) 판정은 Graph 실시간만.
// DK raw_meta_ad_creative 등 적재 테이블은 push 파이프라인이 죽으면 stale ACTIVE 로 남아
// 이미 졸업/OFF 한 광고가 후보에 재등장한다 (7/9 RHYTHMICAL_MAMA 사고).
//
// 차단 대상 (allowlist 밖):
//   1) raw_meta_ad_creative 테이블 참조 — status 의 stale 소스
//   2) 같은 파일에서 dkQuery + effective_status 동시 사용 — DK 에서 status 직접 조회 시도
// fetchAdStatuses()/fetchAdInfo() 가 돌려준 정규화 객체의 필드 사용은 허용 (그 함수들이 Graph 우선).
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";

const ALLOW = new Set([
  join("lib", "dk-meta.ts"),      // 유일한 status 게이트 (Graph 우선 + DK fallback)
  join("lib", "meta-api.ts"),     // Graph 직접 호출 구현체
]);

const ROOTS = ["app", "lib", "components"];
const violations = [];

function walk(dir) {
  let entries;
  try { entries = readdirSync(dir); } catch { return; }
  for (const e of entries) {
    const p = join(dir, e);
    const st = statSync(p);
    if (st.isDirectory()) { walk(p); continue; }
    if (!/\.(ts|tsx)$/.test(e)) continue;
    if (ALLOW.has(p)) continue;
    const src = readFileSync(p, "utf-8");
    const code = src.split("\n").filter((l) => !l.trim().startsWith("//")).join("\n");
    if (/raw_meta_ad_creative/.test(code)) {
      violations.push(`${p}: raw_meta_ad_creative 직접 참조 (stale status 소스)`);
    }
    if (/dkQuery/.test(code) && /effective_status/.test(code)) {
      violations.push(`${p}: dkQuery + effective_status 조합 (DK 에서 status 직접 조회 금지)`);
    }
  }
}

ROOTS.forEach(walk);

if (violations.length > 0) {
  console.error("\n[status-source guard] FAIL:");
  violations.forEach((v) => console.error("  " + v));
  console.error(
    "\non/off 판정은 lib/dk-meta.ts fetchAdStatuses() (Graph 실시간 우선) 만 사용하라." +
    "\nDK 적재 테이블 직접 읽기 금지 — stale ACTIVE 가 졸업/OFF 후보 유령을 만든다 (2026-07-09 룰).\n",
  );
  process.exit(1);
}
console.log("[status-source guard] PASS");
