<!-- BEGIN:nextjs-agent-rules -->
# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` before writing any code. Heed deprecation notices.
<!-- END:nextjs-agent-rules -->

# 절대 룰: 광고 on/off(effective_status) = Graph 실시간만 (2026-07-09 세은)

졸업/OFF/증액 후보·"집행 중" 카운트 등 모든 on/off 판정은 `lib/dk-meta.ts fetchAdStatuses()` (Graph 계정 edge 우선, DK 는 실패 시 fallback) 만 경유한다. DK `raw_meta_ad_creative` 등 적재 테이블은 push 파이프라인이 죽으면 stale ACTIVE 로 남아 이미 졸업/OFF 한 광고가 후보에 재등장한다 (7/9 RHYTHMICAL_MAMA 사고).

- `scripts/check-status-source.mjs` (prebuild) 가 위반을 빌드 실패로 차단한다. 가드를 우회·완화하지 마라.
- 성과·spend 이력 표시는 이력 그대로 (OFF 광고 과거 spend 표시 O) — 후보/집행중 판정만 ACTIVE 한정.
- 배포는 `vercel --prod` (SE 레포 gitignore — git push 아님).
