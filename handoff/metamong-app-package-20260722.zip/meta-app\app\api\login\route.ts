import { NextRequest, NextResponse } from "next/server";
import { checkPassword, makeSessionCookie, SESSION_COOKIE_NAME } from "@/lib/auth";

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  const password = String(body?.password ?? "");
  const next = String(body?.next ?? "/");
  if (!checkPassword(password)) {
    return NextResponse.json({ ok: false, error: "invalid" }, { status: 401 });
  }
  const cookie = makeSessionCookie();
  const res = NextResponse.json({ ok: true, next });
  res.cookies.set(SESSION_COOKIE_NAME, cookie.value, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: cookie.maxAge,
    path: "/",
  });
  return res;
}
