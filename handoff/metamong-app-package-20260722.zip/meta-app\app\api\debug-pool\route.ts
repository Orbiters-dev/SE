import { NextResponse } from "next/server";
import { buildContentPool } from "@/lib/influencer-aggregation";

export async function GET() {
  const pool = await buildContentPool();
  const wlCount = pool.filter((p) => p.hasWl).length;
  const wlSpendSum = pool.reduce((s, p) => s + p.wlSpendJpy, 0);
  const wlImpSum = pool.reduce((s, p) => s + p.wlImpressions, 0);
  const samples = pool
    .filter((p) => p.hasWl)
    .slice(0, 10)
    .map((p) => ({
      handle: p.igHandle,
      shortcode: p.postShortcode,
      wlSpend: p.wlSpendJpy,
      wlImp: p.wlImpressions,
      grade: p.finalGrade,
    }));
  return NextResponse.json({
    totalContents: pool.length,
    hasWlCount: wlCount,
    wlSpendSum,
    wlImpSum,
    samples,
  });
}
