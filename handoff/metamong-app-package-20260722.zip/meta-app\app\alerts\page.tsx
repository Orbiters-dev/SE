import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { EnvWarning } from "@/components/meta/EnvWarning";
import { Monkey } from "@/components/meta/Monkey";
import {
  fetchAds, budgetIncreaseCandidates, offRecommendations, graduationCandidates,
} from "@/lib/meta-aggregations";
import { fmtWon, fmtPct, isoDate, daysAgo } from "@/lib/format";
import {
  FREQ_HIGH, KPI_CPC, CTR_LOW,
  OFF_MIN_DAYS, OFF_D3_CPC_MAX, OFF_D3_CTR_MIN, OFF_D3_CPLPV_OFF,
  GRAD_CPC_MAX, GRAD_CTR_MIN, GRAD_CPLPV_MAX, GRAD_MIN_DAYS,
} from "@/lib/meta-constants";

export const revalidate = 60;

export default async function AlertsPage() {
  let body: React.ReactNode;
  try {
    const today = new Date();
    const since = isoDate(daysAgo(7, today));
    const until = isoDate(daysAgo(1, today));
    const adsRaw = await fetchAds(since, until);
    const ads = adsRaw.filter((a) => a.spend > 0);

    const candidates = budgetIncreaseCandidates(ads);
    const grads = graduationCandidates(ads, daysAgo(1, today));
    // Off 평가 입력은 spend 0 포함 풀 (delivery 실패 광고가 spend 필터에 걸러지면 안 됨)
    const off = offRecommendations(adsRaw, daysAgo(1, today));
    const highFreq = ads.filter((a) => a.frequency >= FREQ_HIGH).sort((a, b) => b.frequency - a.frequency);
    const lowCtr = ads
      .filter((a) => a.impressions >= 1000 && a.ctr > 0 && a.ctr < CTR_LOW)
      .sort((a, b) => a.ctr - b.ctr);
    const cpcSpike = ads
      .filter((a) => a.clicks >= 5 && a.cpc > KPI_CPC * 2)
      .sort((a, b) => b.cpc - a.cpc);

    body = (
      <>
        <section>
          <div className="mb-3 flex items-baseline justify-between">
            <h1 className="text-lg font-semibold tracking-tight">알림</h1>
            <span className="text-xs text-muted-foreground">7일 풀</span>
          </div>
          <p className="text-xs text-muted-foreground">
            표시만. 실행은 Ads Manager 에서 직접.
          </p>
        </section>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Monkey mood="rich" size={32} />
              증액 후보
              <Badge variant="secondary">{candidates.length}</Badge>
            </CardTitle>
            <p className="text-xs text-muted-foreground">
              spend ≥ ₩30,000 · CPLPV ≤ 풀 평균 × 0.85 · CTR ≥ 풀 평균 × 1.1 · Freq ≤ {FREQ_HIGH}
            </p>
          </CardHeader>
          <CardContent className="overflow-x-auto p-0">
            <Table className="md:min-w-[640px]">
              <TableHeader>
                <TableRow>
                  <TableHead>광고</TableHead>
                  <TableHead className="text-right">Spend</TableHead>
                  <TableHead className="text-right">CPLPV</TableHead>
                  <TableHead className="hidden text-right md:table-cell">CTR</TableHead>
                  <TableHead className="text-right">Bump %</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {candidates.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="py-8">
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <Monkey mood="dizzy" size={56} />
                        <span className="text-sm">증액 후보 없음</span>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
                {candidates.map((c) => (
                  <TableRow key={c.ad_id}>
                    <TableCell className="max-w-[130px] md:max-w-[260px]">
                      <div className="truncate text-sm font-medium">{c.ad_name}</div>
                      <div className="truncate text-xs text-muted-foreground">{c.adset_name}</div>
                    </TableCell>
                    <TableCell className="text-right tabular-nums">{fmtWon(c.spend)}</TableCell>
                    <TableCell className="text-right tabular-nums">{fmtWon(c.cplpv)}</TableCell>
                    <TableCell className="hidden text-right tabular-nums md:table-cell">{fmtPct(c.ctr)}</TableCell>
                    <TableCell className="text-right tabular-nums">
                      <Badge>+{c.bump_pct}%</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Monkey mood="ecstatic" size={32} />
              졸업 후보
              <Badge variant="secondary">{grads.length}</Badge>
            </CardTitle>
            <p className="text-xs text-muted-foreground">
              Testing · D+{GRAD_MIN_DAYS}+ · CPC ≤ ₩{GRAD_CPC_MAX} · CTR ≥ {GRAD_CTR_MIN}% · CPLPV ≤ ₩{GRAD_CPLPV_MAX} 모두 통과
            </p>
          </CardHeader>
          <CardContent className="overflow-x-auto p-0">
            <Table className="md:min-w-[640px]">
              <TableHeader>
                <TableRow>
                  <TableHead>광고</TableHead>
                  <TableHead className="text-right">CPC</TableHead>
                  <TableHead className="text-right">CTR</TableHead>
                  <TableHead className="text-right">CPLPV</TableHead>
                  <TableHead className="hidden text-right md:table-cell">D+N</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {grads.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={5} className="py-8">
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <Monkey mood="teacher" size={56} />
                        <span className="text-sm">졸업 후보 없음 — 더 키우는 중</span>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
                {grads.map((g) => (
                  <TableRow key={g.ad_id}>
                    <TableCell className="max-w-[130px] md:max-w-[260px]">
                      <div className="truncate text-sm font-medium">{g.ad_name}</div>
                      <div className="truncate text-xs text-muted-foreground">{g.adset_name}</div>
                    </TableCell>
                    <TableCell className="text-right tabular-nums">{fmtWon(g.cpc)}</TableCell>
                    <TableCell className="text-right tabular-nums">{fmtPct(g.ctr)}</TableCell>
                    <TableCell className="text-right tabular-nums">{fmtWon(g.cplpv)}</TableCell>
                    <TableCell className="hidden text-right tabular-nums md:table-cell">
                      {g.days_live !== null ? `D+${g.days_live}` : "?"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <p className="px-4 py-3 text-xs text-muted-foreground">
              승급 = Testing PAUSE → Proven 새 ad_id (haru 방식, learning 재진입 CPLPV +25~32% 감안). 실행은 Ads Manager 에서 직접.
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              {off.candidates.length > 0 && <Monkey mood="cry" size={28} />}
              Off 권장 (강한 신호)
              <Badge variant={off.candidates.length > 0 ? "destructive" : "secondary"}>
                {off.candidates.length}
              </Badge>
            </CardTitle>
            <p className="text-xs text-muted-foreground">
              Testing D+{OFF_MIN_DAYS}+: CPC ≤ ₩{OFF_D3_CPC_MAX} AND CTR ≥ {OFF_D3_CTR_MIN}% → 생존 ·
              하나라도 나쁨 + CPLPV ≥ ₩{OFF_D3_CPLPV_OFF} → OFF (정상이면 D+5 유예) ·
              CPC·CTR 양호해도 CPLPV ≥ ₩{OFF_D3_CPLPV_OFF} → 이탈형 OFF · Proven 은 delivery 실패만
            </p>
          </CardHeader>
          <CardContent className="overflow-x-auto p-0">
            <Table className="md:min-w-[720px]">
              <TableHeader>
                <TableRow>
                  <TableHead>광고 · 트리거</TableHead>
                  <TableHead>풀</TableHead>
                  <TableHead className="text-right">CTR</TableHead>
                  <TableHead className="hidden text-right md:table-cell">CPC</TableHead>
                  <TableHead className="hidden text-right md:table-cell">CPLPV</TableHead>
                  <TableHead className="text-right">Spend</TableHead>
                  <TableHead className="hidden text-right md:table-cell">D+N</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {off.candidates.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={7} className="py-8">
                      <div className="flex flex-col items-center gap-2 text-muted-foreground">
                        <Monkey mood="tongue" size={56} />
                        <span className="text-sm">강한 Off 신호 없음 — D+3 게이트 통과</span>
                      </div>
                    </TableCell>
                  </TableRow>
                )}
                {off.candidates.map((a) => (
                  <TableRow key={a.ad_id}>
                    <TableCell className="max-w-[170px] md:max-w-[300px]">
                      <div className="truncate text-sm font-medium">{a.ad_name}</div>
                      <div className="text-xs text-destructive">{a.reason}</div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="whitespace-nowrap">{a.pool}</Badge>
                    </TableCell>
                    <TableCell className="text-right tabular-nums">{fmtPct(a.ctr)}</TableCell>
                    <TableCell className="hidden text-right tabular-nums md:table-cell">{fmtWon(a.cpc)}</TableCell>
                    <TableCell className="hidden text-right tabular-nums md:table-cell">{a.cplpv > 0 ? fmtWon(a.cplpv) : "—"}</TableCell>
                    <TableCell className="text-right tabular-nums">{fmtWon(a.spend)}</TableCell>
                    <TableCell className="hidden text-right tabular-nums md:table-cell">
                      {a.days_live !== null ? `D+${a.days_live}` : "?"}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            <p className="px-4 py-3 text-xs text-muted-foreground">
              PAID는 즉시 Off, GIFT는 새 콜라보 발주 우선. WL은 3~6개월 운용 — 시간 단독 Off X.
            </p>
          </CardContent>
        </Card>

        {off.monitoring.length > 0 && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base flex items-center gap-2">
                Off 후보 모니터링 (약한 신호)
                <Badge variant="outline">{off.monitoring.length}</Badge>
              </CardTitle>
              <p className="text-xs text-muted-foreground">
                CPC·CTR 경계지만 CPLPV 정상 — 즉시 Off X, D+5 재판정 (경계선 회복 케이스 보호).
              </p>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {off.monitoring.map((a) => (
                  <li key={a.ad_id} className="flex items-center justify-between gap-2">
                    <div className="min-w-0">
                      <div className="truncate text-sm font-medium">{a.ad_name}</div>
                      <div className="truncate text-xs text-muted-foreground">{a.reason}</div>
                    </div>
                    <div className="shrink-0 text-right">
                      <div className="text-sm font-medium tabular-nums">{fmtPct(a.ctr)}</div>
                      <div className="text-xs text-muted-foreground">
                        <Badge variant="outline" className="mr-1">{a.pool}</Badge>
                        {fmtWon(a.spend)}
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}

        <AlertList
          title="피로도 (Freq ≥ 2.5)"
          ads={highFreq}
          metric={(a) => a.frequency.toFixed(2)}
          metricLabel="Freq"
        />
        <AlertList
          title={`저성과 CTR (< ${CTR_LOW}%)`}
          ads={lowCtr}
          metric={(a) => fmtPct(a.ctr)}
          metricLabel="CTR"
        />
        <AlertList
          title={`CPC 스파이크 (> ₩${KPI_CPC * 2})`}
          ads={cpcSpike}
          metric={(a) => fmtWon(a.cpc)}
          metricLabel="CPC"
        />
      </>
    );
  } catch (e) {
    body = <EnvWarning error={e instanceof Error ? e.message : String(e)} />;
  }
  return <div className="space-y-6">{body}</div>;
}

interface AlertItem {
  ad_id: string;
  ad_name: string;
  adset_name: string;
  spend: number;
}

function AlertList<T extends AlertItem>({
  title, ads, metric, metricLabel,
}: {
  title: string;
  ads: T[];
  metric: (a: T) => string;
  metricLabel: string;
}) {
  const hasIssue = ads.length > 0;
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base flex items-center gap-2">
          {hasIssue && <Monkey mood="cry" size={28} />}
          {title}
          <Badge variant="outline">{ads.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!hasIssue && (
          <div className="flex flex-col items-center gap-2 py-4 text-muted-foreground">
            <Monkey mood="tongue" size={56} />
            <span className="text-xs">문제 없음</span>
          </div>
        )}
        <ul className="space-y-2">
          {ads.slice(0, 8).map((a) => (
            <li key={a.ad_id} className="flex items-center justify-between gap-2">
              <div className="min-w-0">
                <div className="truncate text-sm font-medium">{a.ad_name}</div>
                <div className="truncate text-xs text-muted-foreground">{a.adset_name}</div>
              </div>
              <div className="shrink-0 text-right">
                <div className="text-sm font-medium tabular-nums">{metric(a)}</div>
                <div className="text-xs text-muted-foreground">
                  {metricLabel} · {fmtWon(a.spend)}
                </div>
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
