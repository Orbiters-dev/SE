import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Link from "next/link";
import { ExternalLink } from "lucide-react";
import { EnvWarning } from "@/components/meta/EnvWarning";
import { ScrollableTable } from "@/components/meta/ScrollableTable";
import { buildContentPool, type ContentSummary } from "@/lib/influencer-aggregation";
import { fetchWatch3sMap, type Watch3s } from "@/lib/datakeeper";
import { fetchContentTags, fetchTaxonomy, type ContentTag } from "@/lib/sheets";
import type { Taxonomy } from "@/lib/sheets-types";
import { TagCell } from "@/components/meta/TagCell";
import { buildPerfTiers, tierValues, type PerfRow, type Tier, type MetricCell } from "@/lib/perf-tiers";
import { fmtCompact } from "@/lib/format";
import { cn } from "@/lib/utils";

export const revalidate = 60;

function fmtKrw(v: number): string {
  return `₩${Math.round(v).toLocaleString("en-US")}`;
}
function fmtViews(v: number | null): string {
  if (v == null) return "—";
  return fmtCompact(v);
}
function fmtRate(v: number | null): string {
  if (v == null) return "—";
  if (v >= 1_000) return `₩${Math.round(v).toLocaleString("en-US")}`;
  if (v >= 100) return `₩${v.toFixed(0)}`;
  if (v >= 10) return `₩${v.toFixed(1)}`;
  if (v >= 1) return `₩${v.toFixed(2)}`;
  return `₩${v.toFixed(3)}`;
}
function fmtVtr(v: number | null): string {
  if (v == null) return "—";
  return `${(v * 100).toFixed(1)}%`;
}
function fmtFollowers(v: number | null): string {
  if (v == null) return "—";
  return fmtCompact(v);
}
function fmtLpv(v: number | null): string {
  if (v == null || v <= 0) return "—";
  return fmtCompact(v);
}
function fmtCtr(v: number | null): string {
  if (v == null) return "—";
  return `${v.toFixed(2)}%`;
}

export default async function ContentPoolPage() {
  let body: React.ReactNode;
  try {
    // DK content_posts(JP·IG) 신규 콘텐츠 자동 편입 — 시트 미기재 게시물도 풀에 표시 (태그만 우선 선택 가능)
    const raw = await buildContentPool({ includeDkOnly: true });
    // 자동 태그(별도 시트) — 비공개/미배포면 빈 맵으로 폴백 (페이지는 떠야 함)
    const tags = await fetchContentTags().catch(() => new Map<string, ContentTag>());
    // 3초 시청 비율 (DK content_posts views/plays) — 실패 시 빈 맵 폴백
    const watch3s = await fetchWatch3sMap().catch(() => new Map<string, Watch3s>());
    // 태그 드롭다운 옵션 (Inhouse Content Tracker 택소노미) — 실패 시 빈 옵션 폴백
    const taxonomy = await fetchTaxonomy().catch((): Taxonomy => ({ kmGroups: [], hooks: [] }));
    // 요소 성과 티어 — 이미 받은 raw/tags/watch3s 재사용(추가 DK 호출 X). 훅 이름 = v2 택소노미.
    const perf = buildPerfTiers(raw, tags, watch3s, taxonomy.hooks);
    // 합산 등급 폐기(2026-07-07 세은) — 정렬은 게시일 최신순. 평가 = 요소별 티어 배지.
    const pool = [...raw].sort((a, b) => (b.postDate ?? "").localeCompare(a.postDate ?? ""));
    const wlCount = pool.filter((c) => c.hasWl).length;

    body = (
      <Tabs defaultValue="pool" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 sm:w-auto">
          <TabsTrigger value="pool">콘텐츠 풀 ({pool.length})</TabsTrigger>
          <TabsTrigger value="perf">성과 티어</TabsTrigger>
          <TabsTrigger value="tagging">태깅 항목</TabsTrigger>
        </TabsList>

        <TabsContent value="pool" className="space-y-6">
          <PoolSection pool={pool} wlCount={wlCount} tags={tags} watch3s={watch3s} taxonomy={taxonomy} />
        </TabsContent>

        <TabsContent value="perf" className="space-y-6">
          <PerfTierSection km={perf.km} hook={perf.hook} />
        </TabsContent>

        <TabsContent value="tagging" className="space-y-6">
          <TaggingPlanSection />
        </TabsContent>
      </Tabs>
    );
  } catch (e) {
    body = <EnvWarning error={e instanceof Error ? e.message : String(e)} />;
  }
  // 페이지는 고정 — 좌우 스크롤은 표 하단 sticky 바(ScrollableTable)에서.
  return <div className="space-y-6">{body}</div>;
}

// 현행 태깅·등급 체계.
// 분류 = 콘텐츠에 붙이는 라벨(키메세지·훅·앵글) · 등급 = 요소별 percentile 5티어(S~D) · 보류 = 아직 안 씀
const TAGGING_ITEMS: { kind: "분류" | "등급" | "보류"; item: string; desc: string }[] = [
  { kind: "분류", item: "키메세지 (S##_F##)", desc: "소구점 — Subject×Focus 종속 (시트 수기검수). 예: S06_F03 보온보냉" },
  { kind: "분류", item: "훅 (H01~H26)", desc: "첫 3초 훅 유형. 예: H03 실수지적+권위" },
  { kind: "분류", item: "앵글 (AG01~10)", desc: "카메라 구도 — vision 보강 후 (현재 보류)" },
  { kind: "등급", item: "단가 (₩/view)", desc: "비용효율 percentile 5티어(S~D). 낮을수록 S" },
  { kind: "등급", item: "VTR (조회/팔로워)", desc: "percentile 5티어" },
  { kind: "등급", item: "조회수", desc: "percentile 5티어" },
  { kind: "등급", item: "ER (engagement)", desc: "percentile 5티어" },
  { kind: "보류", item: "3s율 (조회/재생)", desc: "IG 57건만 실측·대부분 천장(중앙 98%)이라 변별 약함 → 보류" },
  { kind: "보류", item: "정성 (overall)", desc: "시트 overall 조인 후 티어 예정" },
];

function TierBadge({ t }: { t: Tier }) {
  if (t === "?") return <span className="text-[10px] text-muted-foreground">·</span>;
  const cls: Record<string, string> = {
    S: "bg-[var(--good-bg)] text-[var(--good-fg)]",
    A: "bg-accent text-accent-foreground",
    B: "bg-secondary text-secondary-foreground",
    C: "bg-[var(--bad-bg)]/50 text-[var(--bad-fg)]",
    D: "bg-[var(--bad-bg)] text-[var(--bad-fg)]",
  };
  return <span className={cn("inline-flex rounded px-1.5 py-0.5 text-[11px] font-bold", cls[t])}>{t}</span>;
}

function MetricCellView({ cell, fmt }: { cell: MetricCell; fmt: (v: number) => string }) {
  if (cell.n === 0) return <div className="text-center text-[10px] text-muted-foreground">—</div>;
  return (
    <div className="flex flex-col items-center gap-0.5">
      <TierBadge t={cell.tier} />
      <span className="text-[10px] text-muted-foreground">
        {cell.avg != null ? fmt(cell.avg) : "—"}{cell.n < 5 ? ` ·${cell.n}*` : ""}
      </span>
    </div>
  );
}

function PerfMatrix({ title, rows, note }: { title: string; rows: PerfRow[]; note?: string }) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">{title}</CardTitle>
        {note && <p className="text-xs text-muted-foreground">{note}</p>}
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="min-w-[240px]">요소</TableHead>
              <TableHead className="text-center">ER</TableHead>
              <TableHead className="text-center">CTR(WL)</TableHead>
              <TableHead className="text-center">CPLPV(WL)</TableHead>
              <TableHead className="text-center">3s율</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((r) => (
              <TableRow key={r.code}>
                <TableCell className="text-sm"><span className="font-semibold">{r.code}</span> {r.name}</TableCell>
                <TableCell><MetricCellView cell={r.er} fmt={(v) => `${v.toFixed(2)}%`} /></TableCell>
                <TableCell><MetricCellView cell={r.ctr} fmt={(v) => `${v.toFixed(1)}%`} /></TableCell>
                <TableCell><MetricCellView cell={r.cplpv} fmt={(v) => `₩${Math.round(v)}`} /></TableCell>
                <TableCell><MetricCellView cell={r.s3} fmt={(v) => `${Math.round(v * 100)}%`} /></TableCell>
              </TableRow>
            ))}
            {rows.length === 0 && (
              <TableRow><TableCell colSpan={5} className="py-4 text-center text-sm text-muted-foreground">데이터 없음</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

function PerfTierSection({ km, hook }: { km: PerfRow[]; hook: PerfRow[] }) {
  return (
    <section className="space-y-6">
      <div>
        <h2 className="text-lg font-bold tracking-tight">요소 성과 티어 (지표별)</h2>
        <p className="text-xs text-muted-foreground">
          지표마다 그룹을 percentile 5티어(S~D) · 합산 X · CTR/CPLPV=WL 콘텐츠만·3s율=조회&lt;재생만 → 소표본(*) 주의 · CPLPV는 낮을수록 S
        </p>
      </div>
      <PerfMatrix title="키메세지(소구점)별 성과" rows={km} />
      <PerfMatrix title="훅별 성과" rows={hook} note="훅 코드(H##) 기준" />
    </section>
  );
}

function TaggingPlanSection() {
  return (
    <section className="space-y-4">
      <div className="flex items-baseline justify-between">
        <h2 className="text-lg font-bold tracking-tight">콘텐츠 태깅·등급 체계</h2>
        <span className="text-xs text-muted-foreground">분류=라벨 · 등급=요소별 percentile 5티어</span>
      </div>
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">현행 항목</CardTitle>
          <p className="text-xs text-muted-foreground">
            분류 = 콘텐츠에 붙이는 라벨(키메세지·훅) · 등급 = 요소별 percentile 5티어(지금) → 나중에 성과로 &quot;어떤 태그가 잘 되나&quot; 교차
          </p>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-auto">
            <Table className="md:min-w-[760px]">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[88px]">종류</TableHead>
                  <TableHead className="w-[280px]">항목</TableHead>
                  <TableHead>설명</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {TAGGING_ITEMS.map((row) => (
                  <TableRow key={row.item}>
                    <TableCell>
                      <Badge variant={row.kind === "등급" ? "default" : row.kind === "분류" ? "secondary" : "outline"}>
                        {row.kind}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-medium">{row.item}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{row.desc}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </section>
  );
}

function PoolSection({
  pool, wlCount, tags, watch3s, taxonomy,
}: {
  pool: ContentSummary[];
  wlCount: number;
  tags: Map<string, ContentTag>;
  watch3s: Map<string, Watch3s>;
  taxonomy: Taxonomy;
}) {
  const taggedCount = pool.filter((c) => c.postShortcode && tags.has(c.postShortcode)).length;
  // 요소별 percentile 5티어 (합산 등급 폐기 — 요소 하나당 독립 티어. 2026-07-07 세은)
  const rateT = tierValues(pool.map((c, i): [number, number | null] =>
    [i, c.hasWl ? c.wlUnifiedRateKrwPerView : c.organicRateKrwPerView]), false);   // 단가 낮을수록 S
  const vtrT = tierValues(pool.map((c, i): [number, number | null] =>
    [i, c.hasWl ? c.wlVtr : c.organicVtr]), true);
  const erT = tierValues(pool.map((c, i): [number, number | null] => [i, c.engagementRate]), true);
  const viewT = tierValues(pool.map((c, i): [number, number | null] => [i, c.currentViews]), true);
  return (
    <>
      <section>
        <div className="mb-3 flex items-baseline justify-between">
          <h2 className="text-lg font-bold tracking-tight">콘텐츠 풀 (Organic + WL 통합)</h2>
          <span className="text-xs text-muted-foreground">{pool.length} 콘텐츠 · WL {wlCount} · 태그 {taggedCount}</span>
        </div>
      </section>

      <Card className="overflow-visible">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">전체 ({pool.length})</CardTitle>
          <p className="text-xs text-muted-foreground">
            합산 등급 없음 — 요소별(전체 view·ER·단가·VTR) percentile 5티어(S~D) 배지 · 단가는 낮을수록 S ·
            단가·VTR = WL 콘텐츠는 WL 기준(보수+COGS+WL spend / 현재 view), 아니면 Organic 기준(보수+COGS / D+3 view) ·
            전체 view·LPV·CPLPV·CTR 은 WL 콘텐츠만 · 정렬 = 게시일 최신순 ·
            DK 배지 = 시트 미기재, DK에서 자동 편입된 새 콘텐츠 (KM/훅 바로 선택 가능)
          </p>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollableTable className="max-h-[78vh]">
            <Table className="min-w-[1790px]">
              <TableHeader>
                <TableRow>
                  <TableHead className="min-w-[220px]">인플 / 제품</TableHead>
                  <TableHead className="w-[260px]">태그 (KM / 훅 · 클릭해 편집)</TableHead>
                  <TableHead className="w-[64px]">Deal</TableHead>
                  <TableHead className="w-[84px] text-right">팔로워</TableHead>
                  <TableHead className="w-[96px] text-right">D+3 view</TableHead>
                  <TableHead className="w-[104px] text-right">organic view</TableHead>
                  <TableHead className="w-[118px] text-right">전체 view</TableHead>
                  <TableHead className="w-[92px] text-right">ER</TableHead>
                  <TableHead className="w-[76px] text-right">3s율</TableHead>
                  <TableHead className="w-[112px]">Hook Type</TableHead>
                  <TableHead className="w-[92px] text-right">LPV</TableHead>
                  <TableHead className="w-[108px] text-right">CPLPV</TableHead>
                  <TableHead className="w-[80px] text-right">CTR</TableHead>
                  <TableHead className="w-[130px] text-right">단가 (₩/view)</TableHead>
                  <TableHead className="w-[100px] text-right">VTR</TableHead>
                  <TableHead className="w-[88px] text-right whitespace-nowrap">정성</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pool.map((c, i) => (
                  <ContentRow
                    key={`${c.internalId || c.postShortcode || c.creatorId}-${i}`}
                    c={c}
                    tag={c.postShortcode ? tags.get(c.postShortcode) : undefined}
                    w3s={c.postShortcode ? watch3s.get(c.postShortcode) : undefined}
                    tiers={{ rate: rateT.get(i), vtr: vtrT.get(i), er: erT.get(i), view: viewT.get(i) }}
                    taxonomy={taxonomy}
                  />
                ))}
              </TableBody>
            </Table>
          </ScrollableTable>
        </CardContent>
      </Card>
    </>
  );
}

// 요소별 티어 배지 + 값 (배지 = percentile 5티어, 표본<5 또는 값 없음이면 배지 생략)
function ValT({ txt, t }: { txt: string; t?: Tier }) {
  return (
    <div className="flex items-center justify-end gap-1.5">
      {t && t !== "?" && <TierBadge t={t} />}
      <span>{txt}</span>
    </div>
  );
}

interface ElemTiers { rate?: Tier; vtr?: Tier; er?: Tier; view?: Tier; }

function ContentRow({ c, tag, w3s, tiers, taxonomy }: {
  c: ContentSummary; tag?: ContentTag; w3s?: Watch3s; tiers: ElemTiers; taxonomy: Taxonomy;
}) {
  const rate = c.hasWl ? c.wlUnifiedRateKrwPerView : c.organicRateKrwPerView;
  const vtr = c.hasWl ? c.wlVtr : c.organicVtr;
  // organic view = 전체 누적 view − paid view(LPV). paid view = spend/CPLPV = LPV.
  const paidView = c.hasWl ? (c.wlLpv ?? 0) : 0;
  const organicView = c.currentViews != null ? Math.max(0, c.currentViews - paidView) : null;
  const dt = (c.dealType ?? "").trim().toLowerCase();
  const isPaid = dt === "paid";
  const dealLabel = isPaid ? "Paid" : dt ? "Gift" : "—";

  return (
    <TableRow className="transition-colors">
      <TableCell className="max-w-[280px]">
        <div className="flex items-center gap-1.5">
          {c.dkOnly ? (
            <span className="truncate text-sm font-semibold">@{c.igHandle}</span>
          ) : (
            <Link
              href={`/influencers/${encodeURIComponent(c.igHandle)}`}
              className="truncate text-sm font-semibold hover:opacity-80"
            >
              @{c.igHandle}
            </Link>
          )}
          {c.hasWl && <Badge variant="default" className="h-4 px-1 text-[9px]">WL</Badge>}
          {c.dkOnly && <Badge variant="outline" className="h-4 px-1 text-[9px]">DK</Badge>}
        </div>
        <div className="truncate text-[11px] text-muted-foreground">
          {c.product || "—"}{c.cogs.sku ? ` · ${c.cogs.sku}` : ""}
        </div>
        {c.url ? (
          <a
            href={c.url}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-1 inline-flex items-center gap-1 rounded-full bg-primary/90 px-2 py-0.5 text-[10px] font-semibold text-primary-foreground hover:bg-primary"
          >
            <ExternalLink className="h-2.5 w-2.5" /> 영상
          </a>
        ) : (
          <span className="text-[10px] text-muted-foreground">URL 없음</span>
        )}
      </TableCell>
      <TableCell className="align-top">
        <TagCell
          shortcode={c.postShortcode}
          handle={c.igHandle}
          url={c.url ?? null}
          kmAuto={tag?.kmPrimary ?? ""}
          hookAuto={tag?.hookPrimary ?? ""}
          kmManual={tag?.kmManual ?? []}
          hookManual={tag?.hookManual ?? []}
          kmAutoRejected={tag?.kmAutoRejected ?? false}
          kmPrimaryDesc={tag?.kmPrimaryDesc ?? ""}
          kmSub={tag?.kmSub ?? ""}
          hookPrimaryName={tag?.hookPrimaryName ?? ""}
          evidence={tag?.evidence ?? ""}
          confidence={tag?.confidence ?? ""}
          kmGroups={taxonomy.kmGroups}
          hooks={taxonomy.hooks}
        />
      </TableCell>
      <TableCell>
        <Badge variant={isPaid ? "default" : "secondary"} className="text-[10px]">
          {dealLabel}
        </Badge>
      </TableCell>
      <TableCell className="text-right tabular-nums text-sm">{fmtFollowers(c.followers)}</TableCell>
      <TableCell className="text-right tabular-nums text-sm">{fmtViews(c.organicViewD3)}</TableCell>
      <TableCell className="text-right tabular-nums text-sm">{fmtViews(organicView)}</TableCell>
      <TableCell className="text-right tabular-nums text-sm">
        <ValT txt={fmtViews(c.currentViews)} t={c.currentViews != null ? tiers.view : undefined} />
      </TableCell>
      <TableCell className="text-right tabular-nums text-sm">
        <ValT txt={fmtCtr(c.engagementRate)} t={c.engagementRate != null ? tiers.er : undefined} />
      </TableCell>
      <TableCell className="text-right tabular-nums text-sm">
        {w3s && w3s.rate != null ? (
          <span
            className={w3s.measured ? "" : "text-muted-foreground/60"}
            title={w3s.measured
              ? `조회(3s+) ${w3s.views.toLocaleString()} / 재생 ${w3s.plays.toLocaleString()}`
              : "plays==views (재생·조회 구분 미수집)"}
          >
            {(w3s.rate * 100).toFixed(0)}%{w3s.measured ? "" : "*"}
          </span>
        ) : (
          <span className="text-muted-foreground">—</span>
        )}
      </TableCell>
      <TableCell className="text-sm">
        {c.hookType ? (
          <div className="max-w-[104px] truncate" title={c.hookType}>{c.hookType}</div>
        ) : (
          <span className="text-muted-foreground">—</span>
        )}
      </TableCell>
      <TableCell className="text-right tabular-nums text-sm">{c.hasWl ? fmtLpv(c.wlLpv) : "—"}</TableCell>
      <TableCell className="text-right tabular-nums text-sm">{c.hasWl ? fmtRate(c.wlCplpv) : "—"}</TableCell>
      <TableCell className="text-right tabular-nums text-sm">{c.hasWl ? fmtCtr(c.wlCtr) : "—"}</TableCell>
      <TableCell className="text-right tabular-nums text-sm font-medium">
        <ValT txt={fmtRate(rate)} t={rate != null ? tiers.rate : undefined} />
      </TableCell>
      <TableCell className="text-right tabular-nums text-sm">
        <ValT txt={fmtVtr(vtr)} t={vtr != null ? tiers.vtr : undefined} />
      </TableCell>
      <TableCell className="text-right tabular-nums text-sm whitespace-nowrap">{c.overall || "—"}</TableCell>
    </TableRow>
  );
}
