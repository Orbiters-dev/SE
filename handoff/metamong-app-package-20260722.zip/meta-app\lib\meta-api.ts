// SERVER-ONLY. Do not import from client components.
// Port of api_get + fetch from tools/meta_jp_daily.py L59-93.

import "server-only";
import { META_GRAPH_BASE } from "./meta-constants";

const TOKEN = process.env.META_JP_ACCESS_TOKEN;
const ACCT = process.env.META_JP_AD_ACCOUNT_ID;

function requireEnv(): { token: string; acct: string } {
  if (!TOKEN || !ACCT) {
    throw new Error(
      "META_JP_ACCESS_TOKEN / META_JP_AD_ACCOUNT_ID missing in env",
    );
  }
  return { token: TOKEN, acct: ACCT };
}

type Json = Record<string, unknown>;

export async function apiGet(
  path: string,
  params: Record<string, string | number | undefined> = {},
): Promise<Json[]> {
  const { token } = requireEnv();
  const search = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined) search.set(k, String(v));
  }
  search.set("access_token", token);

  let url = `${META_GRAPH_BASE}/${path}?${search.toString()}`;
  const out: Json[] = [];

  // Next.js fetch caching: 60s revalidate (matches plan: TanStack 60s stale).
  while (url) {
    const res = await fetch(url, {
      next: { revalidate: 60 },
    });
    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(`Graph API ${res.status}: ${body.slice(0, 300)}`);
    }
    const data = (await res.json()) as { data?: Json[]; paging?: { next?: string } };
    out.push(...(data.data ?? []));
    url = data.paging?.next ?? "";
  }
  return out;
}

export type InsightLevel = "account" | "campaign" | "adset" | "ad";

export interface InsightRow {
  campaign_id?: string;
  campaign_name?: string;
  adset_id?: string;
  adset_name?: string;
  ad_id?: string;
  ad_name?: string;
  spend?: string;
  impressions?: string;
  clicks?: string;
  ctr?: string;
  cpc?: string;
  cpm?: string;
  frequency?: string;
  reach?: string;
  actions?: { action_type: string; value: string }[];
  date_start?: string;
  date_stop?: string;
}

const INSIGHT_FIELDS = [
  "campaign_id", "campaign_name", "adset_id", "adset_name",
  "ad_id", "ad_name", "spend", "impressions", "clicks",
  "ctr", "cpc", "cpm", "frequency", "reach", "actions",
] as const;

export interface FetchInsightsOptions {
  level: InsightLevel;
  timeRange?: { since: string; until: string };  // iso yyyy-mm-dd
  datePreset?: "yesterday" | "last_7d" | "last_14d" | "last_30d" | "last_90d";
  withDaily?: boolean;
  timeIncrement?: "monthly" | number;  // withDaily 보다 우선
  limit?: number;
}

export async function fetchInsights(
  opts: FetchInsightsOptions,
): Promise<InsightRow[]> {
  const { acct } = requireEnv();
  const params: Record<string, string | number> = {
    fields: INSIGHT_FIELDS.join(","),
    level: opts.level,
    limit: opts.limit ?? 500,
  };
  if (opts.timeIncrement !== undefined) params.time_increment = opts.timeIncrement;
  else if (opts.withDaily) params.time_increment = 1;
  if (opts.timeRange) params.time_range = JSON.stringify(opts.timeRange);
  else if (opts.datePreset) params.date_preset = opts.datePreset;

  return apiGet(`${acct}/insights`, params) as Promise<InsightRow[]>;
}

// ── Single-ad detail: node info + lifetime daily series ──

export interface AdInfo {
  id: string;
  name?: string;
  created_time?: string;
  effective_status?: string;
  adset?: { name?: string };
  campaign?: { name?: string };
}

export async function fetchAdInfo(adId: string): Promise<AdInfo | null> {
  const { token } = requireEnv();
  const params = new URLSearchParams({
    fields: "id,name,created_time,effective_status,adset{name},campaign{name}",
    access_token: token,
  });
  const res = await fetch(`${META_GRAPH_BASE}/${adId}?${params.toString()}`, {
    next: { revalidate: 300 },
  });
  if (!res.ok) return null;
  return (await res.json()) as AdInfo;
}

// ad_id → effective_status 맵 (ACTIVE / PAUSED / ADSET_PAUSED / CAMPAIGN_PAUSED / ARCHIVED…).
// on/off 필터용 — insights 에는 effective_status 가 없어 별도 조회.
// ⚠ per-id `?ids=<배치>` 는 배치 안에 접근불가/삭제된 id 하나만 있어도 전체 400 → 빈 맵 → 필터 fail-open.
//    그래서 계정 edge `/act_x/ads` 로 전체 광고 status 를 받아 필터한다(개별 id 오류에 견고).
export async function fetchAdStatuses(adIds: string[]): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  if (adIds.length === 0) return map;
  const { token, acct } = requireEnv();
  const wanted = new Set(adIds);
  let url = `${META_GRAPH_BASE}/${acct}/ads?fields=id,effective_status&limit=500&access_token=${token}`;
  let pages = 0;
  while (url && pages < 20) {
    const res = await fetch(url, { next: { revalidate: 300 } });
    if (!res.ok) break;
    const data = (await res.json()) as {
      data?: { id?: string; effective_status?: string }[];
      paging?: { next?: string };
    };
    for (const a of data.data ?? []) {
      if (a.id && a.effective_status && wanted.has(a.id)) map.set(a.id, a.effective_status);
    }
    url = data.paging?.next ?? "";
    pages++;
  }
  return map;
}

export async function fetchAdDaily(
  adId: string,
  since: string,
  until: string,
): Promise<InsightRow[]> {
  return apiGet(`${adId}/insights`, {
    fields: INSIGHT_FIELDS.join(","),
    time_increment: 1,
    time_range: JSON.stringify({ since, until }),
    limit: 500,
  }) as Promise<InsightRow[]>;
}

export function extractLpv(actions?: { action_type: string; value: string }[]): number {
  if (!actions) return 0;
  const hit = actions.find((a) => a.action_type === "landing_page_view");
  return hit ? Number(hit.value) : 0;
}

export function extractPurchases(actions?: { action_type: string; value: string }[]): number {
  if (!actions) return 0;
  const hit = actions.find((a) =>
    a.action_type === "purchase" || a.action_type === "omni_purchase",
  );
  return hit ? Number(hit.value) : 0;
}

// ── Ad creative — partnership ad permalink fetch ──
// Port of tools/meta_jp_daily.py:106-132 build_post_url_map.
// Returns map { ad_id → instagram permalink_url (partnership ads only) }.
export async function fetchAdCreatives(adIds: string[]): Promise<Map<string, string>> {
  const map = new Map<string, string>();
  if (adIds.length === 0) return map;
  const { token } = requireEnv();
  const unique = Array.from(new Set(adIds));
  for (let i = 0; i < unique.length; i += 50) {
    const batch = unique.slice(i, i + 50);
    const params = new URLSearchParams({
      ids: batch.join(","),
      fields: "id,creative{instagram_permalink_url,effective_instagram_media_id}",
      access_token: token,
    });
    const url = `${META_GRAPH_BASE}/?${params.toString()}`;
    try {
      const res = await fetch(url, { next: { revalidate: 600 } });
      if (!res.ok) continue;
      const data = await res.json() as Record<string, { creative?: { instagram_permalink_url?: string } }>;
      for (const [adId, info] of Object.entries(data)) {
        const perma = info?.creative?.instagram_permalink_url;
        if (perma) map.set(adId, perma);
      }
    } catch {
      // batch fail → silent skip
    }
  }
  return map;
}

// ── Ad → 실제 IG 게시자 username (파트너십 광고 매칭용) ──
// ad → creative.effective_instagram_media_id → media.username. 2단 배치 조회.
export async function fetchAdPosterUsernames(adIds: string[]): Promise<Map<string, string>> {
  const out = new Map<string, string>();
  if (adIds.length === 0) return out;
  const { token } = requireEnv();
  const unique = Array.from(new Set(adIds));

  const adToMedia = new Map<string, string>();
  for (let i = 0; i < unique.length; i += 50) {
    const batch = unique.slice(i, i + 50);
    const params = new URLSearchParams({
      ids: batch.join(","),
      fields: "id,creative{effective_instagram_media_id}",
      access_token: token,
    });
    try {
      const res = await fetch(`${META_GRAPH_BASE}/?${params.toString()}`, { next: { revalidate: 600 } });
      if (!res.ok) continue;
      const data = await res.json() as Record<string, { creative?: { effective_instagram_media_id?: string } }>;
      for (const [adId, info] of Object.entries(data)) {
        const mid = info?.creative?.effective_instagram_media_id;
        if (mid) adToMedia.set(adId, mid);
      }
    } catch {
      // batch fail → silent skip
    }
  }

  const mediaIds = Array.from(new Set(adToMedia.values()));
  const mediaUser = new Map<string, string>();
  for (let i = 0; i < mediaIds.length; i += 50) {
    const batch = mediaIds.slice(i, i + 50);
    const params = new URLSearchParams({
      ids: batch.join(","),
      fields: "username",
      access_token: token,
    });
    try {
      const res = await fetch(`${META_GRAPH_BASE}/?${params.toString()}`, { next: { revalidate: 600 } });
      if (!res.ok) continue;
      const data = await res.json() as Record<string, { username?: string }>;
      for (const [mid, info] of Object.entries(data)) {
        if (info?.username) mediaUser.set(mid, info.username);
      }
    } catch {
      // batch fail → silent skip
    }
  }

  for (const [adId, mid] of adToMedia) {
    const u = mediaUser.get(mid);
    if (u) out.set(adId, u.toLowerCase());
  }
  return out;
}

// shortcode 추출 — sheet URL 과 동일 규칙
const PERMALINK_SHORTCODE_RE = /\/(reel|p|tv)\/([A-Za-z0-9_-]+)/;
export function shortcodeFromPermalink(url: string): string | null {
  const m = url.match(PERMALINK_SHORTCODE_RE);
  return m ? m[2] : null;
}
