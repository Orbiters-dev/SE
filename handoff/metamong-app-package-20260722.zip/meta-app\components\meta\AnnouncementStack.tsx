"use client";

// 팝업 체인 오케스트레이터.
// 1순위: WL 광고 운영 체제 정리 (오늘 반영 완료 + 운영 흐름, ~6/26 00:00 KST) → X 닫으면
// 2순위: 슈퍼세일 결과 (24h 한정, ~6/12 16:00 KST) → X 닫으면
// 3순위: 오늘의 이슈 자동(당일 신규 등록 / Testing→Proven 졸업 — 항목 있을 때만).
// 상위 단계가 만료/이미 닫힘이면 다음 단계로.
// (6/18 WL 시스템 개편 "예정" 공지 = SystemRestructureAnnouncement 는 6/19 실집행 완료로 체인에서 제거됨
//  → 운영 체제 정리 팝업(OperationModelAnnouncement)이 실측 숫자로 대체)
// (슈퍼세일 사후 효율 공지 = PostSaleEfficiencyAnnouncement 는 6/19 체인에서 제거됨)

import { useEffect, useState } from "react";
import {
  JuneSettlementAnnouncement,
  JUNE_SETTLEMENT_SHOW_UNTIL_UTC,
  JUNE_SETTLEMENT_DISMISS_KEY,
} from "@/components/meta/JuneSettlementAnnouncement";
import {
  NewAdsAnnouncement,
  NEW_ADS_SHOW_UNTIL_UTC,
  NEW_ADS_DISMISS_KEY,
} from "@/components/meta/NewAdsAnnouncement";
import {
  TodayOpsAnnouncement,
  TODAY_OPS_SHOW_UNTIL_UTC,
  TODAY_OPS_DISMISS_KEY,
} from "@/components/meta/TodayOpsAnnouncement";
import {
  OperationModelAnnouncement,
  OPERATION_MODEL_SHOW_UNTIL_UTC,
  OPERATION_MODEL_DISMISS_KEY,
} from "@/components/meta/OperationModelAnnouncement";
import {
  SupersaleAnnouncement,
  SUPERSALE_SHOW_UNTIL_UTC,
  SUPERSALE_DISMISS_KEY,
} from "@/components/meta/SupersaleAnnouncement";
import { DailyIssuesPopup } from "@/components/meta/DailyIssuesPopup";

export function AnnouncementStack() {
  const [stage, setStage] = useState<
    "none" | "settlement" | "newads" | "ops" | "operation" | "supersale" | "daily"
  >("none");

  const supersaleStageOrNext = (): "supersale" | "daily" => {
    const supersaleEligible =
      Date.now() < SUPERSALE_SHOW_UNTIL_UTC &&
      !sessionStorage.getItem(SUPERSALE_DISMISS_KEY);
    return supersaleEligible ? "supersale" : "daily";
  };

  const operationStageOrNext = (): "operation" | "supersale" | "daily" => {
    const operationEligible =
      Date.now() < OPERATION_MODEL_SHOW_UNTIL_UTC &&
      !sessionStorage.getItem(OPERATION_MODEL_DISMISS_KEY);
    return operationEligible ? "operation" : supersaleStageOrNext();
  };

  const opsStageOrNext = (): "ops" | "operation" | "supersale" | "daily" => {
    const opsEligible =
      Date.now() < TODAY_OPS_SHOW_UNTIL_UTC &&
      !sessionStorage.getItem(TODAY_OPS_DISMISS_KEY);
    return opsEligible ? "ops" : operationStageOrNext();
  };

  const newAdsStageOrNext = ():
    | "newads"
    | "ops"
    | "operation"
    | "supersale"
    | "daily" => {
    const newAdsEligible =
      Date.now() < NEW_ADS_SHOW_UNTIL_UTC &&
      !sessionStorage.getItem(NEW_ADS_DISMISS_KEY);
    return newAdsEligible ? "newads" : opsStageOrNext();
  };

  const settlementStageOrNext = ():
    | "settlement"
    | "newads"
    | "ops"
    | "operation"
    | "supersale"
    | "daily" => {
    const settlementEligible =
      Date.now() < JUNE_SETTLEMENT_SHOW_UNTIL_UTC &&
      !sessionStorage.getItem(JUNE_SETTLEMENT_DISMISS_KEY);
    return settlementEligible ? "settlement" : newAdsStageOrNext();
  };

  useEffect(() => {
    setStage(settlementStageOrNext());
  }, []);

  if (stage === "settlement") {
    return <JuneSettlementAnnouncement onClose={() => setStage(newAdsStageOrNext())} />;
  }
  if (stage === "newads") {
    return <NewAdsAnnouncement onClose={() => setStage(opsStageOrNext())} />;
  }
  if (stage === "ops") {
    return <TodayOpsAnnouncement onClose={() => setStage(operationStageOrNext())} />;
  }
  if (stage === "operation") {
    return <OperationModelAnnouncement onClose={() => setStage(supersaleStageOrNext())} />;
  }
  if (stage === "supersale") {
    return <SupersaleAnnouncement onClose={() => setStage("daily")} />;
  }
  if (stage === "daily") {
    return <DailyIssuesPopup />;
  }
  return null;
}
