"use client";

// "오늘의 이슈" 팝업 — 당일 신규 등록 + Testing→Proven 졸업 광고.
// 항목 0건이면 안 뜸. X 닫기 = 같은 탭 세션 + 같은 날짜 동안 다시 안 뜸.
// 신규: 영상 바로가기 버튼. 졸업: 직전 7d 점유율 게이지 + 졸업 조건 충족 표시.
// issues_info 경고는 표시하지 않음 (2026-06-11 세은 지시 — 영구).

import { useEffect, useState } from "react";
import { X, GraduationCap, Sparkles, ExternalLink, Check } from "lucide-react";
import { Monkey } from "@/components/meta/Monkey";
import { Badge } from "@/components/ui/badge";
import type { DailyIssues, GraduatedAd, NewAd } from "@/lib/daily-issues";

function dismissKey(date: string) {
  return `daily_issues_dismissed_${date}`;
}

function fmtWon(v: number) {
  return `₩${Math.round(v).toLocaleString("en-US")}`;
}

// 점유율 게이지 — 50% 졸업 기준선 포함
function ShareBar({ label, pct }: { label: string; pct: number }) {
  const pass = pct >= 50;
  return (
    <div className="flex items-center gap-2">
      <span className="w-10 shrink-0 text-[11px] text-muted-foreground">{label}</span>
      <div className="relative h-3.5 flex-1 overflow-hidden rounded-full bg-secondary">
        <div
          className="h-full rounded-full bg-primary"
          style={{ width: `${Math.min(100, pct)}%` }}
        />
        <div className="absolute inset-y-0 left-1/2 w-px bg-foreground/30" />
      </div>
      <span className="w-14 shrink-0 text-right text-xs font-semibold tabular-nums">
        {pct.toFixed(1)}%{pass && <Check className="ml-0.5 inline h-3 w-3 text-emerald-600" />}
      </span>
    </div>
  );
}

function GraduatedItem({ a }: { a: GraduatedAd }) {
  const ctrPass = a.ctr_7d >= a.kpi_ctr;
  const sharePass = a.share_spend >= 50 && a.share_clicks >= 50 && a.share_lpv >= 50;
  return (
    <li className="rounded-lg bg-secondary/40 px-3 py-2.5">
      <div className="truncate text-sm font-medium">{a.name}</div>
      <div className="truncate text-xs text-muted-foreground">
        {a.from_adset} → {a.adset_name}
      </div>
      <div className="mt-2 flex gap-1.5">
        <Badge variant="outline">누적 {fmtWon(a.spend_lifetime)}</Badge>
        <Badge variant="outline">7d {fmtWon(a.spend_7d)}</Badge>
      </div>
      <div className="mt-2 space-y-1">
        <div className="text-[11px] font-medium text-muted-foreground">
          직전 7d Testing ad set 점유율 <span className="font-normal">(기준선 = 졸업 게이트 50%)</span>
        </div>
        <ShareBar label="Spend" pct={a.share_spend} />
        <ShareBar label="Clicks" pct={a.share_clicks} />
        <ShareBar label="LPV" pct={a.share_lpv} />
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[11px]">
        <span className={ctrPass ? "rounded-full bg-emerald-100 px-2 py-0.5 font-semibold text-emerald-700" : "rounded-full bg-secondary px-2 py-0.5 text-muted-foreground"}>
          CTR {a.ctr_7d.toFixed(2)}% {ctrPass ? "≥" : "<"} KPI {a.kpi_ctr}%
        </span>
        {sharePass && ctrPass && (
          <span className="rounded-full bg-emerald-100 px-2 py-0.5 font-semibold text-emerald-700">
            ✓ Triple share + 성과 게이트 충족 → 졸업
          </span>
        )}
      </div>
    </li>
  );
}

function NewAdItem({ a }: { a: NewAd }) {
  return (
    <li className="rounded-lg bg-secondary/40 px-3 py-2">
      <div className="flex items-center justify-between gap-2">
        <div className="min-w-0">
          <div className="truncate text-sm font-medium">{a.name}</div>
          <div className="truncate text-xs text-muted-foreground">{a.adset_name}</div>
        </div>
        {a.permalink && (
          <a
            href={a.permalink}
            target="_blank"
            rel="noopener noreferrer"
            className="flex shrink-0 items-center gap-1 rounded-full bg-primary px-2.5 py-1 text-[11px] font-semibold text-primary-foreground transition-opacity hover:opacity-85"
          >
            <ExternalLink className="h-3 w-3" />
            영상 바로가기
          </a>
        )}
      </div>
    </li>
  );
}

export function DailyIssuesPopup() {
  const [data, setData] = useState<DailyIssues | null>(null);

  useEffect(() => {
    fetch("/api/daily-issues")
      .then((r) => (r.ok ? r.json() : null))
      .then((d: DailyIssues | null) => {
        if (!d || !d.date) return;
        if (sessionStorage.getItem(dismissKey(d.date))) return;
        if (d.newAds.length + d.graduated.length === 0) return;
        setData(d);
      })
      .catch(() => {});
  }, []);

  if (!data) return null;

  const dismiss = () => {
    sessionStorage.setItem(dismissKey(data.date), "1");
    setData(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={dismiss} />
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-border bg-background shadow-2xl">
        <button
          onClick={dismiss}
          aria-label="이슈 닫기"
          className="absolute right-3 top-3 rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <X className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-3 border-b border-border/60 bg-secondary/40 px-5 py-4">
          <Monkey mood="teacher" size={48} />
          <div>
            <div className="text-base font-bold tracking-tight">오늘의 이슈</div>
            <div className="text-xs text-muted-foreground">{data.date}</div>
          </div>
        </div>
        <div className="max-h-[60vh] space-y-4 overflow-y-auto px-5 py-4">
          {data.graduated.length > 0 && (
            <section>
              <h3 className="mb-2 flex items-center gap-1.5 text-sm font-semibold">
                <GraduationCap className="h-4 w-4" />
                Testing → Proven 졸업
                <Badge variant="secondary">{data.graduated.length}</Badge>
              </h3>
              <ul className="space-y-1.5">
                {data.graduated.map((a) => <GraduatedItem key={a.ad_id} a={a} />)}
              </ul>
            </section>
          )}
          {data.newAds.length > 0 && (
            <section>
              <h3 className="mb-2 flex items-center gap-1.5 text-sm font-semibold">
                <Sparkles className="h-4 w-4" />
                신규 등록
                <Badge variant="secondary">{data.newAds.length}</Badge>
              </h3>
              <ul className="space-y-1.5">
                {data.newAds.map((a) => <NewAdItem key={a.ad_id} a={a} />)}
              </ul>
            </section>
          )}
        </div>
      </div>
    </div>
  );
}
