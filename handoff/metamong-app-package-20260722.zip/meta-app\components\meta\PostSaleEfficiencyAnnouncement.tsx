"use client";

// 슈퍼세일 사후 효율 공지 (2026-06-17 · 메타몽).
// 슈퍼세일 vs 사후 동기간(둘 다 150h·동일 예산) Total ROAS 비교 + 내일(6/18) 운영방식 전면 변경 공지.
// 노출 ~6/23 00:00 KST (6/19 재노출 요청) → 이후 자동 미표시. X 닫기 = 같은 탭 세션 동안 미표시 (sessionStorage).
// 표시 게이트(시간·dismiss)는 AnnouncementStack이 관리 — 여기는 표시 전용.
// 금액 KRW 통일 · 합산 = Total ROAS · 줄글 X 카드/칩 (메타몽 팝업 룰).

import type { ReactNode } from "react";
import { X } from "lucide-react";
import { Monkey } from "@/components/meta/Monkey";
import { cn } from "@/lib/utils";

export const POSTSALE_EFF_SHOW_UNTIL_UTC = Date.UTC(2026, 5, 22, 15, 0, 0); // 2026-06-23 00:00 KST
export const POSTSALE_EFF_DISMISS_KEY = "postsale_eff_20260619_dismissed";

interface Chip {
  label: string;
  value: string;
  tone: "bad" | "good" | "flat";
}

interface Card {
  tag: string;
  tone: "result" | "decision" | "info";
  title: string;
  chips?: Chip[];
  bullets?: ReactNode[];
}

// 윈도우: 세일 6/4 20:00~6/11 01:59 / 사후 6/11 02:00~6/17 07:59 (둘 다 150h)
const CARDS: Card[] = [
  {
    tag: "결과",
    tone: "result",
    title: "📉 트래픽은 그대로, 전환만 무너짐",
    chips: [
      { label: "CPC", value: "₩95 → ₩92", tone: "flat" },
      { label: "CTR", value: "7.42% → 7.52%", tone: "flat" },
      { label: "CPLPV", value: "₩125 → ₩130", tone: "flat" },
      { label: "LPV", value: "14,826 → 14,229", tone: "flat" },
      { label: "LP→주문", value: "0.80% → 0.09%", tone: "bad" },
    ],
    bullets: [
      <>
        같은 예산 · 같은 트래픽인데 <b>산 비율(전환)만 9배 빠짐</b>
      </>,
      <>
        Meta가 한 일은 두 기간 동일 → 차이는 <b>라쿠텐 세일 인센티브</b>뿐
      </>,
    ],
  },
  {
    tag: "결과",
    tone: "result",
    title: "🧾 매출 · 주문 (동일 150h)",
    chips: [
      { label: "매출", value: "₩6.13M → ₩712K", tone: "bad" },
      { label: "주문", value: "118 → 13", tone: "bad" },
      { label: "객단가", value: "거의 동일", tone: "flat" },
    ],
    bullets: [
      <>
        총 광고비는 두 기간 비슷 (<b>₩2.24M → ₩2.13M</b>)
      </>,
      <>
        매출만 <b>−88%</b> → 세일 종료로 회수가 무너진 구조
      </>,
    ],
  },
  {
    tag: "결정",
    tone: "decision",
    title: "⚙️ 내일(6/18)부터 각 ad set budget ₩8,000으로 수정·실행",
    chips: [{ label: "Budget", value: "₩8,000 / ad set", tone: "good" }],
    bullets: [
      <>
        효율 저조(<b>Total ROAS 0.33x</b>) → 각 ad set budget을 <b>₩8,000</b>으로 수정
      </>,
      <>
        내일 <b>6/18</b>부터 설정 변경 후 실행
      </>,
    ],
  },
];

// 히어로: Total ROAS (RPP 포함) 비교
const HERO = {
  saleRoas: "2.73x",
  postRoas: "0.33x",
  saleSub: "세일 6/4~6/11",
  postSub: "사후 6/11~6/17",
};

export function PostSaleEfficiencyAnnouncement({ onClose }: { onClose: () => void }) {
  const dismiss = () => {
    sessionStorage.setItem(POSTSALE_EFF_DISMISS_KEY, "1");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={dismiss} />
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-border bg-background shadow-2xl">
        <button
          onClick={dismiss}
          aria-label="닫기"
          className="absolute right-3 top-3 rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <X className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-3 border-b border-border/60 bg-secondary/40 px-5 py-4">
          <Monkey mood="teacher" size={48} />
          <div>
            <div className="text-base font-bold tracking-tight">슈퍼세일 사후 효율</div>
            <div className="text-xs text-muted-foreground">2026-06-17 · 메타몽</div>
          </div>
        </div>

        <div className="max-h-[64vh] space-y-3 overflow-y-auto px-5 py-4">
          {/* 히어로: Total ROAS 비교 */}
          <div className="rounded-xl border border-border/60 bg-secondary/30 px-4 py-3">
            <div className="mb-2 text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
              Total ROAS (RPP 포함)
            </div>
            <div className="flex items-stretch gap-2">
              <div className="flex-1 rounded-lg bg-emerald-50 px-3 py-2.5 text-center">
                <div className="text-2xl font-extrabold text-emerald-600">{HERO.saleRoas}</div>
                <div className="mt-0.5 text-[11px] text-muted-foreground">{HERO.saleSub}</div>
              </div>
              <div className="flex items-center text-lg font-bold text-muted-foreground">→</div>
              <div className="flex-1 rounded-lg bg-rose-50 px-3 py-2.5 text-center">
                <div className="text-2xl font-extrabold text-rose-600">{HERO.postRoas}</div>
                <div className="mt-0.5 text-[11px] text-muted-foreground">{HERO.postSub}</div>
              </div>
            </div>
            <div className="mt-2 text-center text-[12px] text-foreground/70">
              동일 150h · 동일 예산 기준 <b>8.2배</b> 하락
            </div>
          </div>

          {CARDS.map((c, ci) => (
            <div key={ci} className="rounded-xl border border-border/60 bg-secondary/30 px-4 py-3">
              <span
                className={cn(
                  "mb-2 inline-block rounded-md px-2 py-0.5 text-[11px] font-bold",
                  c.tone === "decision" && "bg-emerald-100 text-emerald-700",
                  c.tone === "result" && "bg-primary/15 text-primary",
                  c.tone === "info" && "bg-secondary text-muted-foreground",
                )}
              >
                {c.tag}
              </span>
              <div className="mb-1.5 text-sm font-bold">{c.title}</div>
              {c.chips && (
                <div className="mb-2 flex flex-wrap gap-1.5">
                  {c.chips.map((chip, i) => (
                    <span
                      key={i}
                      className={cn(
                        "inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[12px] font-semibold",
                        chip.tone === "bad" && "bg-rose-100 text-rose-700",
                        chip.tone === "good" && "bg-emerald-100 text-emerald-700",
                        chip.tone === "flat" && "bg-secondary text-foreground/70",
                      )}
                    >
                      <span className="text-[10px] font-medium opacity-70">{chip.label}</span>
                      {chip.value}
                    </span>
                  ))}
                </div>
              )}
              {c.bullets && (
                <ul className="list-disc space-y-1 pl-4">
                  {c.bullets.map((b, i) => (
                    <li key={i} className="text-[13px] leading-relaxed text-foreground/80">
                      {b}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
