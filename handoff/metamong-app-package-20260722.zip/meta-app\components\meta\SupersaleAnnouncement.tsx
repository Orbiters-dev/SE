"use client";

// 슈퍼세일 (2026-06-04 20:00 ~ 06-11 01:59 JST) 결과 공지 팝업.
// 2026-06-12 16:00 KST 까지 24시간 한정 표시 — 이후 자동 미표시 (코드 제거 불필요).
// X 닫기 = 같은 탭 세션 동안 다시 안 뜸 (sessionStorage).
// 탭 2개: ① 들인 돈 대비 (세일 단독) ② 평시 대비 (직전주 동일 요일·시각 150h).

import { useState } from "react";
import { X } from "lucide-react";
import { Monkey } from "@/components/meta/Monkey";
import { cn } from "@/lib/utils";

// 표시 게이트(시간·dismiss)는 AnnouncementStack이 관리 — 여기는 표시 전용.
export const SUPERSALE_SHOW_UNTIL_UTC = Date.UTC(2026, 5, 12, 7, 0, 0); // 2026-06-12 16:00 KST
export const SUPERSALE_DISMISS_KEY = "supersale_2026jun_popup_dismissed";

interface Stat {
  label: string;
  value: string;
  sub?: string;
  highlight?: boolean;
  delta?: string;       // "+452.7%" 등 — 배지로 표시
  deltaGood?: boolean;  // true=초록 / false=중립(회색)
}

// 탭① — 들인 돈 대비 (세일 150시간 단독). 금액 전부 KRW (¥→₩ 환산 9.561, 세일 윈도우 평균)
// 매출·주문은 취소 주문(orderProgress 900) 2건 제외 — ¥641,880/118건 → ¥630,720/116건.
// RPP ¥44,493 (6/1~6/11 집행, 6/11 포함 확정) → ₩425,397 합산 — 기간 불일치 경고는 foot에.
const ABS_HERO: Stat[] = [
  { label: "총 광고비", value: "₩2,285,906", sub: "Meta ₩1,860,509\n+ RPP ₩425,397" },
  { label: "매출 (정가)", value: "₩6,030,301", sub: "주문 116건" },
  { label: "Total ROAS", value: "2.64x", sub: "Meta 단독 3.24x", highlight: true },
];
const ABS_GRID: Stat[] = [
  { label: "LPV", value: "14,826" },
  { label: "CPLPV", value: "₩125" },
  { label: "CTR", value: "7.42%" },
  { label: "CPC", value: "₩95" },
  { label: "도달", value: "213K" },
  { label: "Freq", value: "1.42" },
];

// 탭② — 평시(직전주 동일 요일·시각 150h) 대비
const CMP_HERO: Stat[] = [
  { label: "매출", value: "+443%", sub: "₩6,030,301", highlight: true },
  { label: "ROAS", value: "3.24x", sub: "평시 1.11x", highlight: true },
  { label: "광고비", value: "+88%", sub: "₩1,860,509" },
];
const CMP_GRID: Stat[] = [
  { label: "주문", value: "116건", delta: "+452%", deltaGood: true },
  { label: "LPV", value: "14,826", delta: "+91%", deltaGood: true },
  { label: "CPLPV", value: "₩125", delta: "유지", deltaGood: true },
  { label: "CTR", value: "7.42%", delta: "+12.7%", deltaGood: true },
  { label: "CPC", value: "₩95", delta: "+0.4%" },
  { label: "도달", value: "213K", delta: "+38%", deltaGood: true },
];

const TABS = [
  { key: "abs", label: "💰 들인 돈 대비", hero: ABS_HERO, grid: ABS_GRID, foot: "⚠ RPP ₩425,397(¥44,493)는 6/1~6/11 집행분 — 세일 기간과 완전히 일치하지 않아 대략 반영", footWarn: true },
  { key: "cmp", label: "📊 평시 대비", hero: CMP_HERO, grid: CMP_GRID, foot: "직전주 동일 요일·시각 150시간 대비 (Meta 광고비 기준, RPP 제외)", footWarn: false },
] as const;

function HeroCard({ s }: { s: Stat }) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center gap-0.5 rounded-xl border px-2 py-3 text-center",
        s.highlight ? "border-primary/30 bg-primary/10" : "border-border/60 bg-secondary/40",
      )}
    >
      <div className="text-[11px] font-medium text-muted-foreground">{s.label}</div>
      <div className={cn("text-lg font-bold tabular-nums leading-tight", s.highlight && "text-primary")}>
        {s.value}
      </div>
      {s.sub && <div className="whitespace-pre-line text-[10px] text-muted-foreground">{s.sub}</div>}
    </div>
  );
}

function GridTile({ s }: { s: Stat }) {
  return (
    <div className="flex items-center justify-between rounded-lg bg-secondary/40 px-3 py-2">
      <span className="text-xs text-muted-foreground">{s.label}</span>
      <span className="flex items-center gap-1.5">
        <span className="text-sm font-semibold tabular-nums">{s.value}</span>
        {s.delta && (
          <span
            className={cn(
              "rounded-full px-1.5 py-px text-[10px] font-bold",
              s.deltaGood ? "bg-emerald-100 text-emerald-700" : "bg-secondary text-muted-foreground",
            )}
          >
            {s.delta}
          </span>
        )}
      </span>
    </div>
  );
}

export function SupersaleAnnouncement({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState<"abs" | "cmp">("abs");

  const dismiss = () => {
    sessionStorage.setItem(SUPERSALE_DISMISS_KEY, "1");
    onClose();
  };

  const active = TABS.find((t) => t.key === tab)!;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={dismiss} />
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-border bg-background shadow-2xl">
        <button
          onClick={dismiss}
          aria-label="닫기"
          className="absolute right-3 top-3 rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <X className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-3 border-b border-border/60 bg-secondary/40 px-5 py-4">
          <Monkey mood="rich" size={48} />
          <div>
            <div className="text-base font-bold tracking-tight">슈퍼세일 결과 나왔어요</div>
            <div className="text-xs text-muted-foreground">6/4(목) 20:00 ~ 6/11(수) 01:59 · 150시간</div>
          </div>
        </div>
        <div className="flex gap-1.5 px-5 pt-3">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                "rounded-full px-3.5 py-1.5 text-xs font-semibold transition-colors",
                tab === t.key
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "bg-secondary text-muted-foreground hover:text-foreground",
              )}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className="max-h-[55vh] overflow-y-auto px-5 py-4">
          <div className="grid grid-cols-3 gap-2">
            {active.hero.map((s) => <HeroCard key={s.label} s={s} />)}
          </div>
          <div className="mt-2 grid grid-cols-2 gap-1.5">
            {active.grid.map((s) => <GridTile key={s.label} s={s} />)}
          </div>
          {active.foot && (
            <p className={cn(
              "mt-2 text-right text-[10px]",
              active.footWarn ? "font-medium text-destructive" : "text-muted-foreground",
            )}>
              {active.foot}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
