"use client";

// 콘텐츠 풀 행 내 태그 편집기 — 키메세지(S##_F##)·훅(HV-##/HC-## v2) 다중 선택.
// 선택 = 칩(코드+내용)으로 표시, ×로 제거. select 로 추가. comma 목록으로 시트
// km_manual/hook_manual 저장(자동 태그보다 우선). 수동 0개 = 자동 태그 표시.

import { useState } from "react";
import type { KmGroup, TaxonomyOption } from "@/lib/sheets-types";

interface Props {
  shortcode: string | null;
  kmAuto: string;          // 자동 태그 코드 (없으면 "")
  hookAuto: string;
  kmManual: string[];      // 저장된 수동 코드 목록
  hookManual: string[];
  kmAutoRejected: boolean; // km_manual="-" 센티널 — 자동 KM 기각(미분류 취급)
  kmGroups: KmGroup[];
  hooks: TaxonomyOption[];
  // 저장 성공 시 상위(모달 밖 요약 칩)에 최신 상태 통지
  onChange?: (s: { km: string[]; hook: string[]; kmRejected: boolean }) => void;
}

const short = (s: string, n = 30) => (s.length > n ? `${s.slice(0, n)}…` : s);

export function TagEditor({ shortcode, kmAuto, hookAuto, kmManual, hookManual, kmAutoRejected, kmGroups, hooks, onChange }: Props) {
  const [km, setKm] = useState<string[]>(kmManual);
  const [hook, setHook] = useState<string[]>(hookManual);
  const [kmRejected, setKmRejected] = useState<boolean>(kmAutoRejected);
  const [saving, setSaving] = useState<"km" | "hook" | null>(null);
  const [err, setErr] = useState<string | null>(null);

  // 코드 → 설명 (칩·자동 표시에 내용 병기)
  const kmLabel = (code: string) => {
    for (const g of kmGroups) {
      const o = g.options.find((x) => x.code === code);
      if (o) return o.label;
    }
    return "";
  };
  const hookLabel = (code: string) => hooks.find((x) => x.code === code)?.label ?? "";

  // 훅 v2 optgroup — 시트 그룹(🎬 비주얼훅 · 폐기 등) 순서 유지
  const hookGroups = new Map<string, TaxonomyOption[]>();
  for (const o of hooks) {
    const k = o.group ?? "";
    const list = hookGroups.get(k);
    if (list) list.push(o);
    else hookGroups.set(k, [o]);
  }

  // rejected=true 는 km 전용 — 시트 km_manual 에 "-" 센티널 저장 (자동 태그 기각)
  async function save(field: "km" | "hook", list: string[], rejected = false) {
    if (!shortcode) return;
    const prev = field === "km" ? km : hook;
    const prevRejected = kmRejected;
    (field === "km" ? setKm : setHook)(list);
    if (field === "km") setKmRejected(rejected);
    setSaving(field);
    setErr(null);
    try {
      const res = await fetch("/api/tags", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ shortcode, field, value: rejected ? "-" : list.join(",") }),
      });
      if (!res.ok) {
        const data = (await res.json().catch(() => null)) as { error?: string } | null;
        throw new Error(data?.error || `HTTP ${res.status}`);
      }
      onChange?.({
        km: field === "km" ? list : km,
        hook: field === "hook" ? list : hook,
        kmRejected: field === "km" ? rejected : kmRejected,
      });
    } catch (e) {
      (field === "km" ? setKm : setHook)(prev); // 실패 시 롤백
      if (field === "km") setKmRejected(prevRejected);
      setErr(e instanceof Error ? e.message : String(e));
    } finally {
      setSaving(null);
    }
  }

  if (!shortcode) {
    return <span className="text-xs text-muted-foreground">URL 없음</span>;
  }

  const selectCls =
    "w-full max-w-[236px] truncate rounded border bg-background px-1 py-0.5 text-[11px] " +
    "text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:opacity-50";

  function Chips({ field, list, auto, labelOf, rejected = false }: {
    field: "km" | "hook"; list: string[]; auto: string; labelOf: (c: string) => string;
    rejected?: boolean; // km 전용 — 자동 태그 기각 상태
  }) {
    if (list.length === 0) {
      // 자동 기각 상태: 미분류 표시 + ↺ 로 자동 태그 복원
      if (field === "km" && rejected) {
        return (
          <span className="inline-flex items-center gap-1 text-[10px] text-muted-foreground">
            — 미분류 (자동 기각)
            {auto && (
              <button
                type="button"
                aria-label="자동 태그 복원"
                title={`자동 태그 복원: ${auto} ${labelOf(auto)}`}
                className="shrink-0 font-bold hover:opacity-60"
                disabled={saving === field}
                onClick={() => save("km", [], false)}
              >
                ↺
              </button>
            )}
          </span>
        );
      }
      return auto ? (
        <span
          className="inline-flex max-w-[236px] items-center gap-1 truncate rounded bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground"
          title={`자동 태그: ${auto} ${labelOf(auto)}`}
        >
          <span className="truncate">자동 {auto} {short(labelOf(auto), 22)}</span>
          {field === "km" && (
            <button
              type="button"
              aria-label="자동 태그 기각"
              title="자동 태그가 틀렸으면 × — 미분류로 바뀌고 아래에서 수동 추가"
              className="shrink-0 font-bold hover:opacity-60"
              disabled={saving === field}
              onClick={() => save("km", [], true)}
            >
              ×
            </button>
          )}
        </span>
      ) : (
        <span className="text-[10px] text-muted-foreground">— 미분류</span>
      );
    }
    return (
      <>
        {list.map((code) => (
          <span
            key={code}
            className="inline-flex max-w-[236px] items-center gap-1 rounded bg-[var(--good-bg)] px-1.5 py-0.5 text-[10px] font-medium text-[var(--good-fg)]"
            title={`${code} ${labelOf(code)}`}
          >
            <span className="truncate">{code} {short(labelOf(code), 20)}</span>
            <button
              type="button"
              aria-label={`${code} 제거`}
              className="shrink-0 font-bold hover:opacity-60"
              disabled={saving === field}
              onClick={() => save(field, list.filter((c) => c !== code))}
            >
              ×
            </button>
          </span>
        ))}
      </>
    );
  }

  return (
    <div className="space-y-1.5">
      <div className="space-y-0.5">
        <div className="flex flex-wrap items-center gap-1">
          <span className="w-[20px] shrink-0 text-[9px] font-semibold text-muted-foreground">KM</span>
          <Chips field="km" list={km} auto={kmAuto} labelOf={kmLabel} rejected={kmRejected} />
        </div>
        <select
          className={selectCls}
          value=""
          disabled={saving === "km"}
          onChange={(e) => {
            const v = e.target.value;
            if (v && !km.includes(v)) save("km", [...km, v]);
          }}
        >
          <option value="">+ 키메세지 추가…</option>
          {kmGroups.map((g) => (
            <optgroup key={g.subject} label={`${g.subject} ${g.subjectName}`}>
              {g.options.filter((o) => !km.includes(o.code)).map((o) => (
                <option key={o.code} value={o.code}>{o.code} {short(o.label, 40)}</option>
              ))}
            </optgroup>
          ))}
        </select>
      </div>
      <div className="space-y-0.5">
        <div className="flex flex-wrap items-center gap-1">
          <span className="w-[20px] shrink-0 text-[9px] font-semibold text-muted-foreground">훅</span>
          <Chips field="hook" list={hook} auto={hookAuto} labelOf={hookLabel} />
        </div>
        <select
          className={selectCls}
          value=""
          disabled={saving === "hook"}
          onChange={(e) => {
            const v = e.target.value;
            if (v && !hook.includes(v)) save("hook", [...hook, v]);
          }}
        >
          <option value="">+ 훅 추가…</option>
          {[...hookGroups.entries()].map(([grp, opts]) => {
            const items = opts.filter((o) => !hook.includes(o.code)).map((o) => (
              <option key={o.code} value={o.code}>{o.code} {short(o.label, 40)}</option>
            ));
            if (!items.length) return null;
            return grp
              ? <optgroup key={grp} label={grp}>{items}</optgroup>
              : items;
          })}
        </select>
      </div>
      {err && <div className="text-[10px] text-[var(--bad-fg)]">저장 실패: {short(err, 48)}</div>}
    </div>
  );
}
