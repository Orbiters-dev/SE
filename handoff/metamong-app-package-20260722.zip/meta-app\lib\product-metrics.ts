// SERVER-ONLY. Product-level (PPSU / Stainless) monthly metrics for the Products tab.
// Combines: Meta LPV/spend (Paid session, live) + Rakuten order units (current month live,
// past months static seed from PaPoMa actuals).
//
// 어트리뷰션 한계: Rakuten 주문은 전 채널 합산(Meta 기여 분리 불가). LPV = Meta가 LP로 보낸
// Paid 세션. 스토어 전체 접속자수(전환율 분모)는 RMS API가 없어 미수집 → 전환율 칸은 비움.

import "server-only";
import { fetchInsights } from "./dk-meta";   // DK 단일소스
import { extractLpv } from "./meta-api";
import { toFloat, isoDate } from "./format";
import { type Product } from "./rakuten";
import productAccessRaw from "./product-access-seed.json";

const PRODUCTS: Product[] = ["PPSU", "Stainless"];
const MONTHLY_START = "2026-01-01"; // PaPoMa 집계 시작월

// ASIN → product (ProductSSOT ALL PRODUCTS group 기준, 2026-06-22 추출).
// campaign_name 은 신뢰 불가 (6/18 이전 Stainless Proven 캠페인에 PPSU 광고 혼재) →
// ad_name 에 박힌 ASIN 이 실제 제품의 단일 진실 소스.
const ASIN_PRODUCT: Record<string, Product> = {
  "B07YKH98WT": "PPSU", "B07YKJ18D5": "PPSU", "B07YKKWFTN": "PPSU", "B07YL2FT96": "PPSU",
  "B082SSPN4X": "PPSU", "B083986L91": "PPSU", "B08398HJRD": "PPSU", "B08398KZ2B": "PPSU",
  "B083WJBR9B": "PPSU", "B083XT642K": "PPSU", "B0842D5Z17": "PPSU", "B0842DMZ3H": "PPSU",
  "B08TZY1TFY": "PPSU", "B09DCQF68Q": "PPSU", "B09DD28LSF": "PPSU", "B09DD2CXTL": "PPSU",
  "B09DD2WBV9": "PPSU", "B09DD3D6PM": "PPSU", "B09TQWYKPV": "PPSU", "B09TR2Q525": "PPSU",
  "B09ZTV6KL8": "PPSU", "B09ZTWF9SZ": "PPSU", "B0B6ZXGGDR": "PPSU", "B0B9GLVWYN": "PPSU",
  "B0BZYSL3BH": "PPSU", "B0C1N1PLYD": "PPSU", "B0C1N3QZ7K": "PPSU", "B0C1N3VDL3": "PPSU",
  "B0DB7SPP2P": "PPSU", "B0DB7V1BW3": "PPSU", "B0DCV766MB": "PPSU", "B0DCV7MTLS": "PPSU",
  "B0DJNXD66N": "PPSU", "B0DY6SKQ2N": "PPSU", "B0DY6SM9Y7": "PPSU", "B0F4CRT6LV": "PPSU",
  "B0F4D1V39Q": "PPSU", "B0F4D28MC3": "PPSU", "B0F4D3YZ8H": "PPSU", "B0F4D8L1HL": "PPSU",
  "B0F6XNGT85": "PPSU", "B0F8Q8RK18": "PPSU", "B0F8QGZ7TH": "PPSU", "B0F8QH8T8X": "PPSU",
  "B0F8QHJN6G": "PPSU", "B0F8QHRGKW": "PPSU", "B0F9NPRCTM": "PPSU", "B0F9PVZMR1": "PPSU",
  "B0F9PX51FX": "PPSU", "B0F9PY2LBV": "PPSU", "B0F9PZD6QM": "PPSU", "B0F9PZGGF2": "PPSU",
  "B0F9PZPMH8": "PPSU", "B0F9Q2F89Y": "PPSU", "B0FGY2YQJW": "PPSU", "B0FGY39763": "PPSU",
  "B083921731": "Stainless", "B0FHKBTY2S": "Stainless", "B0FHKC2DVV": "Stainless",
  "B0FHKFQPGR": "Stainless", "B0FHKG2SG5": "Stainless", "B0FKFN91X9": "Stainless",
  "B0FKFW6PND": "Stainless", "B0FKG59ZMN": "Stainless", "B0FKG6RCDC": "Stainless",
  "B0FKGCRG45": "Stainless", "B0FKGFN121": "Stainless", "B0G6CCJ24K": "Stainless",
};

const ASIN_RE = /B0[A-Z0-9]{8}/;

// 제품 분류 — ad_name ASIN(정확) → ad_name 라벨(옛 형식)만. campaign 으로는 분류 X.
// (campaign fallback 은 6/18 이전 Stainless Proven 캠페인에 PPSU 광고 혼재 때문에 오분류 → 130% 유발. 제거.)
// ad_name 에 제품 단서 없으면 null(제외) — 잘못 분류하느니 빼는 게 정확.
function classifyAd(adName: string): Product | null {
  const m = adName.match(ASIN_RE);            // 1) ASIN (실제 제품, 옛/새 구조 무관)
  if (m && ASIN_PRODUCT[m[0]]) return ASIN_PRODUCT[m[0]];
  const a = adName.toLowerCase();             // 2) ad_name 라벨 (| PPSU 300ml | 등)
  if (a.includes("ppsu")) return "PPSU";
  if (a.includes("stainless")) return "Stainless";
  return null;
}

// 제품별 접속자수 + 주문 — RMS 商品ページ get-item-list API(visitAll / unitsAll), 商品管理番号 분류(니플 제외).
// product-access-seed.json — tools/rms_access_downloader.py --update-app 으로 매일 갱신 (당월). 과거월은 API backfill.
const PRODUCT_ACCESS = productAccessRaw as Record<Product, Record<string, { access: number; orders: number }>>;

export interface ProductMonthRow {
  month: string;        // "2026-06"
  product: Product;
  lpv: number;          // Meta Paid session (landing_page_view)
  spend: number;        // Meta spend (KRW)
  cplpv: number;        // spend / lpv
  access: number;       // 제품별 전체 접속자수 (RMS 商品ページ)
  ratio: number;        // 메타 유입 비중 % = lpv / access
  cvr: number;          // 전환율 % = orders / access
  orders: number;       // RMS unitsAll (product-access-seed)
  inProgress: boolean;  // 이번 달 진행 중
}

// Meta ad-level monthly → month×product LPV/spend 누적.
async function fetchMetaProductMonthly(): Promise<
  Map<string, { lpv: number; spend: number }>
> {
  const today = new Date();
  const rows = await fetchInsights({
    level: "ad",
    timeRange: { since: MONTHLY_START, until: isoDate(today) },
    timeIncrement: "monthly",
  });
  const map = new Map<string, { lpv: number; spend: number }>();
  for (const r of rows) {
    const month = (r.date_start ?? "").slice(0, 7);
    if (!month) continue;
    const prod = classifyAd(r.ad_name ?? "");
    if (!prod) continue;
    const key = `${month}|${prod}`;
    const cur = map.get(key) ?? { lpv: 0, spend: 0 };
    cur.lpv += extractLpv(r.actions);
    cur.spend += toFloat(r.spend);
    map.set(key, cur);
  }
  return map;
}

// "전체" = PPSU + Stainless 합 (店舗 전체는 니플·교체스트로 등 잡상품 섞여 PPSU+Stainless 와 안 맞음 → 폐기).
// 7지표 통일: 접속·메타유입·비중·주문·CPLPV·Spend·전환율.
export interface TotalMonthRow {
  month: string;
  access: number;       // PPSU + Stainless 접속자수 합
  metaLpv: number;      // 합 LPV
  ratio: number;        // 메타 유입 비중 % = metaLpv / access
  orders: number;       // 합 주문
  cplpv: number;        // spend / lpv
  spend: number;        // 합 spend
  cvr: number;          // 전환율 % = orders / access
  inProgress: boolean;
}

export interface ProductMetrics {
  rows: ProductMonthRow[];        // 월 오름차순, 제품별 2행/월
  totalMonthly: TotalMonthRow[];  // 전체(=PPSU+Stainless 합) 7지표, 최신월 위로
  thisMonth: string;
}

export async function fetchProductMetrics(): Promise<ProductMetrics> {
  const today = new Date();
  const thisMonth = isoDate(today).slice(0, 7);

  const meta = await fetchMetaProductMonthly();

  // 대상 월 = product-access-seed 월 ∪ Meta 월 ∪ 현재 달
  const months = new Set<string>([...Object.keys(PRODUCT_ACCESS.PPSU ?? {}), thisMonth]);
  for (const key of meta.keys()) months.add(key.split("|")[0]);

  const rows: ProductMonthRow[] = [];
  for (const month of [...months].sort()) {
    for (const product of PRODUCTS) {
      const m = meta.get(`${month}|${product}`) ?? { lpv: 0, spend: 0 };
      const pa = PRODUCT_ACCESS[product]?.[month];
      const access = pa?.access ?? 0;
      const orders = pa?.orders ?? 0;       // 접속·주문 동일 API (visitAll / unitsAll)
      rows.push({
        month,
        product,
        lpv: m.lpv,
        spend: m.spend,
        cplpv: m.lpv > 0 ? m.spend / m.lpv : 0,
        access,
        ratio: access > 0 ? (m.lpv / access) * 100 : 0,
        cvr: access > 0 ? (orders / access) * 100 : 0,
        orders,
        inProgress: month === thisMonth,
      });
    }
  }

  // "전체" = 월별 PPSU + Stainless 합 (店舗 전체 아님 — 니플 등 제외)
  const totalMap = new Map<string, { access: number; lpv: number; spend: number; orders: number }>();
  for (const r of rows) {
    const t = totalMap.get(r.month) ?? { access: 0, lpv: 0, spend: 0, orders: 0 };
    t.access += r.access;
    t.lpv += r.lpv;
    t.spend += r.spend;
    t.orders += r.orders;
    totalMap.set(r.month, t);
  }
  const totalMonthly: TotalMonthRow[] = [...totalMap.entries()]
    .map(([month, t]) => ({
      month,
      access: t.access,
      metaLpv: t.lpv,
      ratio: t.access > 0 ? (t.lpv / t.access) * 100 : 0,
      orders: t.orders,
      cplpv: t.lpv > 0 ? t.spend / t.lpv : 0,
      spend: t.spend,
      cvr: t.access > 0 ? (t.orders / t.access) * 100 : 0,
      inProgress: month === thisMonth,
    }))
    .sort((a, b) => b.month.localeCompare(a.month));

  return { rows, totalMonthly, thisMonth };
}
