// SERVER-ONLY. 키메세지(소구점)/훅별 성과 매트릭스 티어.
// 각 지표(ER·CTR·CPLPV·3s율)마다 그룹(subject/hook)들을 percentile 5티어(S~D).
// ⚠️ 페이지에서 이미 받은 pool/tags/w3s 를 넘겨받아 계산만 함(추가 DK 호출 X → 503 방지).

import "server-only";
import type { ContentSummary } from "./influencer-aggregation";
import type { ContentTag } from "./sheets";
import type { TaxonomyOption } from "./sheets-types";
import type { Watch3s } from "./datakeeper";

export type Tier = "S" | "A" | "B" | "C" | "D" | "?";
export interface MetricCell { avg: number | null; n: number; tier: Tier; }
export interface PerfRow {
  code: string; name: string;
  er: MetricCell; ctr: MetricCell; cplpv: MetricCell; s3: MetricCell;
}

const SUBJ_NAME: Record<string, string> = {
  S01: "바디 소재", S02: "꼭지류", S03: "부속품/인체공학", S04: "엔지니어링/제조",
  S05: "세척용이성", S06: "기능/성능", S07: "발달", S08: "디자인/발견",
  S09: "브랜드/신뢰", S10: "라이프스타일", S11: "프로모션", S12: "신상품/런칭",
};

const TIERS: Tier[] = ["S", "A", "B", "C", "D"];
const EMPTY: MetricCell = { avg: null, n: 0, tier: "?" };

function tierMetric(groups: Map<string, number[]>, higherBetter: boolean): Map<string, MetricCell> {
  const rows = [...groups.entries()]
    .filter(([, v]) => v.length > 0)
    .map(([code, v]) => ({ code, avg: v.reduce((a, b) => a + b, 0) / v.length, n: v.length }));
  rows.sort((a, b) => (higherBetter ? b.avg - a.avg : a.avg - b.avg));
  const n = rows.length;
  const out = new Map<string, MetricCell>();
  rows.forEach((r, i) => {
    out.set(r.code, { avg: r.avg, n: r.n, tier: n >= 5 ? TIERS[Math.min(4, Math.floor((i / n) * 5))] : "?" });
  });
  return out;
}

// 개별 콘텐츠 요소별 percentile 5티어 (합산 X — 요소 하나당 독립 티어).
// entries = [key, value]. null/비수치 제외. 표본 5개 미만이면 티어 안 매김.
export function tierValues(
  entries: [number, number | null | undefined][],
  higherBetter: boolean,
): Map<number, Tier> {
  const valid = entries.filter((e): e is [number, number] => e[1] != null && Number.isFinite(e[1]));
  const out = new Map<number, Tier>();
  if (valid.length < 5) return out;
  valid.sort((a, b) => (higherBetter ? b[1] - a[1] : a[1] - b[1]));
  valid.forEach(([k], i) => {
    out.set(k, TIERS[Math.min(4, Math.floor((i / valid.length) * 5))]);
  });
  return out;
}

function buildAxis(
  pool: ContentSummary[],
  tags: Map<string, ContentTag>,
  w3s: Map<string, Watch3s>,
  keysOf: (t: ContentTag) => string[],
  nameOf: (code: string) => string,
): PerfRow[] {
  const perf = new Map<string, { er: number | null; ctr: number | null; cplpv: number | null }>();
  for (const c of pool) {
    if (!c.postShortcode) continue;
    perf.set(c.postShortcode, { er: c.engagementRate, ctr: c.wlCtr, cplpv: c.wlCplpv });
  }
  const er = new Map<string, number[]>(), ctr = new Map<string, number[]>(),
        cplpv = new Map<string, number[]>(), s3 = new Map<string, number[]>();
  const push = (m: Map<string, number[]>, k: string, v: number | null | undefined) => {
    if (v == null || !Number.isFinite(v)) return;
    (m.get(k) ?? m.set(k, []).get(k)!).push(v);
  };
  const codes = new Set<string>();
  for (const t of tags.values()) {
    // 다중 태그 = 콘텐츠 하나가 여러 그룹에 기여
    for (const k of new Set(keysOf(t))) {
      codes.add(k);
      const p = perf.get(t.shortcode);
      if (p) { push(er, k, p.er); push(ctr, k, p.ctr); push(cplpv, k, p.cplpv); }
      const w = w3s.get(t.shortcode);
      if (w && w.rate != null) push(s3, k, w.rate);
    }
  }
  const erT = tierMetric(er, true), ctrT = tierMetric(ctr, true),
        cpT = tierMetric(cplpv, false), s3T = tierMetric(s3, true);
  const rows: PerfRow[] = [...codes].map((code) => ({
    code, name: nameOf(code),
    er: erT.get(code) ?? EMPTY,
    ctr: ctrT.get(code) ?? EMPTY,
    cplpv: cpT.get(code) ?? EMPTY,
    s3: s3T.get(code) ?? EMPTY,
  }));
  const ord = (t: Tier) => (TIERS.indexOf(t) < 0 ? 9 : TIERS.indexOf(t));
  rows.sort((a, b) => ord(a.er.tier) - ord(b.er.tier) || (b.er.avg ?? -1) - (a.er.avg ?? -1));
  return rows;
}

// pool/tags/w3s = 페이지에서 이미 fetch 한 것 재사용 (추가 DK 호출 없음)
export function buildPerfTiers(
  pool: ContentSummary[],
  tags: Map<string, ContentTag>,
  w3s: Map<string, Watch3s>,
  hookTaxonomy: TaxonomyOption[] = [],
): { km: PerfRow[]; hook: PerfRow[] } {
  // 훅 코드 → 설명 맵. 1순위 = 택소노미 v2 (HV-##/HC-##), 2순위 = 태그의 hook_primary
  // 라벨에서 코드 접두어 제거 (구 H## 자동 태그용). 예: "H03 실수 지적+권위" → "실수 지적+권위"
  const hookNames = new Map<string, string>();
  for (const o of hookTaxonomy) hookNames.set(o.code, o.label);
  for (const t of tags.values()) {
    const code = (t.hookPrimary.match(/^H(?:[VC]-)?\d{2}/) ?? [])[0];
    if (!code || hookNames.has(code)) continue;
    hookNames.set(code, (t.hookPrimaryName || "").replace(/^H(?:[VC]-)?\d{2}\s*/, "").trim());
  }
  // 수동 태그(km_manual/hook_manual)가 하나라도 있으면 자동 대신 수동 목록 사용
  // 자동 KM 기각(km_manual="-") 행은 KM 집계에서 제외
  const kmCodes = (t: ContentTag) =>
    (t.kmManual.length ? t.kmManual : t.kmAutoRejected ? [] : [t.kmPrimary])
      .map((v) => (v.match(/^S\d{2}/) ?? [])[0])
      .filter((v): v is string => Boolean(v));
  const hookCodes = (t: ContentTag) =>
    (t.hookManual.length ? t.hookManual : [t.hookPrimary])
      .map((v) => (v.match(/^H(?:[VC]-)?\d{2}/) ?? [])[0])
      .filter((v): v is string => Boolean(v));
  const km = buildAxis(pool, tags, w3s, kmCodes, (c) => SUBJ_NAME[c] ?? "");
  const hook = buildAxis(pool, tags, w3s, hookCodes, (c) => hookNames.get(c) ?? "");
  return { km, hook };
}
