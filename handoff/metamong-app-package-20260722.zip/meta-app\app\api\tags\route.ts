import { NextRequest, NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { upsertManualTag, type ManualField } from "@/lib/tag-write";

// 수동 태그 저장 — 인증은 proxy.ts 전역 게이트가 처리 (로그인 세션 없으면 여기 못 옴)
export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as { shortcode?: string; field?: string; value?: string };
    const shortcode = (body.shortcode ?? "").trim();
    const field = body.field as ManualField;
    const value = (body.value ?? "").trim();

    if (!shortcode || !/^[A-Za-z0-9_-]+$/.test(shortcode)) {
      return NextResponse.json({ error: "invalid shortcode" }, { status: 400 });
    }
    if (field !== "km" && field !== "hook") {
      return NextResponse.json({ error: "invalid field" }, { status: 400 });
    }
    // 빈 값 = 수동 해제(자동 태그로 복귀) · 다중 선택 = comma 목록 ("S01_F04,S06_F06")
    // km "-" = 자동 KM 기각 센티널 (오분류 제거 → 미분류 취급)
    // 훅 = v2 HV-##/HC-## (구 H## 저장값 혼재 행 편집 위해 읽기 호환 유지)
    const re = field === "km"
      ? /^S\d{2}_F\d{2}(,S\d{2}_F\d{2})*$/
      : /^H(?:[VC]-)?\d{2}(,H(?:[VC]-)?\d{2})*$/;
    const isRejectSentinel = field === "km" && value === "-";
    if (value && !isRejectSentinel && !re.test(value)) {
      return NextResponse.json({ error: "invalid value" }, { status: 400 });
    }

    await upsertManualTag(shortcode, field, value);
    revalidatePath("/influencers");
    return NextResponse.json({ ok: true });
  } catch (e) {
    return NextResponse.json(
      { error: e instanceof Error ? e.message : String(e) },
      { status: 500 },
    );
  }
}
