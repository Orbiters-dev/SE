"use client";

import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

export function DragScroll({ children, className }: { children: React.ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let isDown = false;
    let startX = 0;
    let startY = 0;
    let scrollLeft = 0;
    let scrollTop = 0;
    let dragged = false;

    const onDown = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      // 링크 / 버튼 클릭은 무시 (drag X)
      if (target.closest("a, button")) return;
      e.preventDefault();  // native text/link drag 방지
      isDown = true;
      dragged = false;
      el.classList.add("cursor-grabbing");
      startX = e.pageX - el.offsetLeft;
      startY = e.pageY - el.offsetTop;
      scrollLeft = el.scrollLeft;
      scrollTop = el.scrollTop;
    };
    const onDragStart = (e: DragEvent) => e.preventDefault();
    const onUp = () => {
      isDown = false;
      el.classList.remove("cursor-grabbing");
    };
    const onMove = (e: MouseEvent) => {
      if (!isDown) return;
      const x = e.pageX - el.offsetLeft;
      const y = e.pageY - el.offsetTop;
      const dx = x - startX;
      const dy = y - startY;
      if (Math.abs(dx) > 5 || Math.abs(dy) > 5) dragged = true;
      el.scrollLeft = scrollLeft - dx;
      el.scrollTop = scrollTop - dy;
    };
    const onClick = (e: MouseEvent) => {
      if (dragged) {
        e.preventDefault();
        e.stopPropagation();
      }
    };
    el.addEventListener("mousedown", onDown);
    window.addEventListener("mouseup", onUp);
    el.addEventListener("mousemove", onMove);
    el.addEventListener("mouseleave", onUp);
    el.addEventListener("click", onClick, true);
    return () => {
      el.removeEventListener("mousedown", onDown);
      window.removeEventListener("mouseup", onUp);
      el.removeEventListener("mousemove", onMove);
      el.removeEventListener("mouseleave", onUp);
      el.removeEventListener("click", onClick, true);
    };
  }, []);

  return (
    <div ref={ref} className={cn("cursor-grab select-none", className)}>
      {children}
    </div>
  );
}
