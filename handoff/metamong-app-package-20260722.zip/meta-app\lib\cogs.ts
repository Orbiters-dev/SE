// Product COGS table — 세은 명시 2026-06-09.
// Plan: lib/cogs.ts 정적 매핑. KRW 단위 입력 → JPY 환산.

import "server-only";

// 1 JPY ≈ 10 KRW (plan 디폴트 가정. 정확 환율 fetch X)
const JPY_PER_KRW = 1 / 10;

interface CogsEntry {
  keyword: string;        // case-insensitive substring 매칭
  unitKrw: number;
  unitJpy: number;
}

const COGS_TABLE: CogsEntry[] = [
  { keyword: "stainless", unitKrw: 32_000, unitJpy: 32_000 * JPY_PER_KRW },
  { keyword: "stain",     unitKrw: 32_000, unitJpy: 32_000 * JPY_PER_KRW },  // "stain300-bear" 등
  { keyword: "fliptop",   unitKrw: 25_000, unitJpy: 25_000 * JPY_PER_KRW },
  { keyword: "flip-top",  unitKrw: 25_000, unitJpy: 25_000 * JPY_PER_KRW },
  { keyword: "ppsu",      unitKrw: 20_000, unitJpy: 20_000 * JPY_PER_KRW },
];

/**
 * Grosmimi 탭 Product (col 6) 자유 텍스트 → SKU 키워드 + Unit COGS.
 * 매칭 안 되면 unitJpy=0 (외부 제품 또는 미매핑).
 *
 * 예시:
 *  "stain300-bear/" → stainless (3200 JPY)
 *  "ppsu300_white"  → ppsu (2000 JPY)
 *  "PPSU Tumbler"   → ppsu (2000 JPY)
 *  "Flip-top 300ml" → fliptop (2500 JPY)
 *  "Baby Snacks"    → null (0)
 */
export interface CogsLookup {
  sku: string | null;
  unitJpy: number;
  unitKrw: number;
}

export function lookupCogs(productText: string): CogsLookup {
  const lower = (productText ?? "").toLowerCase();
  if (!lower.trim()) return { sku: null, unitJpy: 0, unitKrw: 0 };
  // 가장 긴 키워드 우선 매칭 (stainless > stain)
  const sorted = [...COGS_TABLE].sort((a, b) => b.keyword.length - a.keyword.length);
  for (const entry of sorted) {
    if (lower.includes(entry.keyword)) {
      return { sku: entry.keyword, unitJpy: entry.unitJpy, unitKrw: entry.unitKrw };
    }
  }
  return { sku: null, unitJpy: 0, unitKrw: 0 };
}

// Public for UI inspection
export const COGS_TABLE_PUBLIC = COGS_TABLE.map((e) => ({
  sku: e.keyword,
  unitKrw: e.unitKrw,
  unitJpy: e.unitJpy,
}));
