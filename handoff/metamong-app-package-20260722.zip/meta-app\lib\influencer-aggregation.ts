// SERVER-ONLY. Content-level grading (2026-06-10 refit — Organic 풀 + WL 풀 분리).
//  - Organic 풀 (모든 콘텐츠):
//      view = D+3 ±7일 + 발현률 normalize fallback
//      단가 = (보수 + COGS) / D+3 view (KRW/view)
//      VTR  = D+3 view / followers
//      등급: organicGrade
//  - WL 풀 (hasWl=true 콘텐츠만):
//      view = 현재 누적 view (cron 마지막 capture)
//      spend = WL spend (90d 누적)
//      통합 단가 = (보수 + COGS + WL spend) / 현재 view (KRW/view)
//      WL CPM = WL spend / WL impressions × 1000
//      등급: wlGrade
//  - 가중치: 단가 0.45 + VTR 0.45 + 정성 0.10 (ER 제거)
//  - S 임계 ≥80 + 게이트 (rate ≥70, VTR ≥70). A ≥60, B ≥25, C <25.
//  - 정성 ±1 bump (시트 Overall ≥4.5 / ≤2.0)

import "server-only";
import { unstable_cache } from "next/cache";
import { fetchMaster, fetchCollabs, type MasterRow, type CollabRow } from "./sheets";
import { fetchContentMetrics, fetchContentPosts, type ContentMetric, type ContentPost } from "./datakeeper";
import { fetchWlAttributionByShortcode, type CollabKey } from "./wl-attribution";
import { lookupCogs, type CogsLookup } from "./cogs";
import { normalizeProduct } from "./product";

const TARGET_DAY_ORGANIC = 3;
const FALLBACK_WINDOW = 7;

const W_RATE = 0.45;
const W_VTR = 0.45;
const W_QUAL = 0.10;

const QUAL_BUMP_UP = 4.5;
const QUAL_BUMP_DOWN = 2.0;

const KRW_PER_JPY = 10;
function jpyToKrw(jpy: number): number { return jpy * KRW_PER_JPY; }

export type Grade = "S" | "A" | "B" | "C" | "NA";
export type ViewMethod = "exact" | "normalized" | "na";

function gradeFromPercentile(p: number): Grade {
  if (p >= 80) return "S";
  if (p >= 60) return "A";
  if (p >= 25) return "B";
  return "C";
}

const S_GATE_RATE = 70;
const S_GATE_VTR = 70;
function sGatePass(rateScore: number | null, vtrScore: number | null): boolean {
  const r = rateScore ?? 0;
  const v = vtrScore ?? 0;
  return r >= S_GATE_RATE && v >= S_GATE_VTR;
}
function bumpGrade(g: Grade, d: 1 | -1 | 0): Grade {
  if (g === "NA") return "NA";
  const order: Grade[] = ["C", "B", "A", "S"];
  const i = order.indexOf(g);
  return order[Math.max(0, Math.min(3, i + d))];
}
function percentileRank(sorted: number[], v: number): number {
  if (sorted.length === 0) return 50;
  let lt = 0, eq = 0;
  for (const x of sorted) { if (x < v) lt++; else if (x === v) eq++; }
  return ((lt + eq / 2) / sorted.length) * 100;
}

function parseScore(s: string): number | null {
  if (!s) return null;
  const cleaned = s.replace(/[^\d.]/g, "");
  if (!cleaned) return null;
  const n = parseFloat(cleaned);
  return Number.isFinite(n) ? n : null;
}

function parseFollowers(s: string | null | undefined): number | null {
  if (!s) return null;
  const cleaned = String(s).trim();
  const num = parseFloat(cleaned.replace(/[,\s]/g, ""));
  if (!Number.isFinite(num)) return null;
  if (/m/i.test(cleaned)) return num * 1_000_000;
  if (/k/i.test(cleaned)) return num * 1_000;
  if (/万/.test(cleaned)) return num * 10_000;
  return num;
}

interface OrganicViewResult {
  view: number | null;
  method: ViewMethod;
  sourceAge: number | null;
}

function resolveD3OrganicView(
  postId: string,
  postDate: string | null,
  metricsByPost: Map<string, ContentMetric[]>,
): OrganicViewResult {
  if (!postDate) return { view: null, method: "na", sourceAge: null };
  const postDay = new Date(`${postDate}T00:00:00Z`);
  const target = new Date(postDay);
  target.setUTCDate(target.getUTCDate() + TARGET_DAY_ORGANIC);
  const rows = metricsByPost.get(postId) ?? [];

  // D+3 ±7일 실측 매칭 — view>0 만 (0값·전항목0 수집실패 glitch 제외).
  // 추정환산 폐기: 실측 없으면 빈칸(na). (2026-07-02 세은 지시)
  let best: { row: ContentMetric; gap: number } | null = null;
  for (const r of rows) {
    if ((r.views ?? 0) <= 0) continue;  // 0-glitch / 수집실패 행 제외
    const md = new Date(`${r.date}T00:00:00Z`);
    const gap = Math.abs((md.getTime() - target.getTime()) / 86_400_000);
    if (gap > FALLBACK_WINDOW) continue;
    if (!best || gap < best.gap) best = { row: r, gap };
  }
  if (best) {
    return { view: best.row.views, method: "exact", sourceAge: TARGET_DAY_ORGANIC };
  }
  return { view: null, method: "na", sourceAge: null };
}

// 현재 누적(전체) view — 최신행이 0-glitch면 0으로 읽히는 버그 방지: 가장 최근 "view>0" 행.
function latestNonzeroView(rows: ContentMetric[]): number | null {
  let best: { date: string; views: number } | null = null;
  for (const r of rows) {
    const v = r.views ?? 0;
    if (v <= 0) continue;
    if (!best || r.date > best.date) best = { date: r.date, views: v };
  }
  return best?.views ?? null;
}

export interface ContentSummary extends CollabRow {
  igHandle: string;
  postDate: string | null;
  postAge: number | null;
  followers: number | null;
  followersSource: "dk" | "master" | "na";
  dkOnly: boolean;                          // 콜라보 시트에 없고 DK content_posts 에서 자동 편입된 행

  // Views
  organicViewD3: number | null;             // Organic 풀용 (D+3)
  organicViewMethod: ViewMethod;
  organicViewSourceAge: number | null;
  currentViews: number | null;              // 현재 누적 (WL 풀 용)
  engagementRate: number | null;

  // Cost (KRW)
  feeJpyNumeric: number;
  feeKrw: number;
  cogs: CogsLookup;
  organicCostKrw: number;                   // 보수+COGS
  wlSpendKrw: number;
  wlImpressions: number;
  wlClicks: number;                         // WL 광고 클릭 합
  wlCtr: number | null;                     // WL clicks / impressions × 100
  wlLpv: number | null;                     // WL landing_page_view (DK LPV — 배포 전 null)
  wlCplpv: number | null;                   // WL spend / LPV (배포 전 null)
  wlAdIds: string[];                        // 이 콘텐츠에 귀속된 Meta ad_id 목록
  totalCostKrw: number;                     // 보수+COGS+WL (WL 풀 분자)

  // Organic metrics
  organicRateKrwPerView: number | null;     // (보수+COGS) / D+3 view
  organicVtr: number | null;                // D+3 view / followers
  // WL metrics
  wlUnifiedRateKrwPerView: number | null;   // (보수+COGS+WL) / 현재 view
  wlVtr: number | null;                     // 현재 view / followers
  wlCpmKrw: number | null;                  // WL spend / imp × 1000

  overallScore: number | null;
  hasWl: boolean;

  // Organic scoring
  organicRateScore: number | null;
  organicVtrScore: number | null;
  organicQualScore: number | null;
  organicQuantScore: number | null;
  organicPercentile: number | null;
  organicBaseGrade: Grade;
  organicQualBump: 1 | -1 | 0;
  organicGrade: Grade;

  // WL scoring (hasWl=true 만)
  wlRateScore: number | null;
  wlVtrScore: number | null;
  wlQualScore: number | null;
  wlQuantScore: number | null;
  wlPercentile: number | null;
  wlBaseGrade: Grade;
  wlQualBump: 1 | -1 | 0;
  wlGrade: Grade;

  // Legacy aliases (detail page 호환)
  organicView: number | null;
  viewMethod: ViewMethod;
  viewSourceAge: number | null;
  organicCostJpy: number;
  wlSpendJpy: number;
  organicRateJpyPerView: number | null;
  wlCpmJpy: number | null;
  totalCostJpy: number;
  totalReach: number | null;
  organicViewForUnit: number | null;
  d7Views: number | null;
  d30Views: number | null;
  d7Offset: number | null;
  d30Offset: number | null;
  unifiedRateJpyPerView: number | null;
  rateScore: number | null;
  vtrScore: number | null;
  erScore: number | null;
  quantScore: number | null;
  quantPercentile: number | null;
  baseGrade: Grade;
  qualBump: 1 | -1 | 0;
  finalGrade: Grade;
}

export interface BuildOptions {
  qualUpThreshold?: number;
  qualDownThreshold?: number;
  // DK content_posts(JP·IG)에 있지만 콜라보 시트에 아직 없는 새 콘텐츠를 풀에 자동 편입
  // (콘텐츠 탭 전용 — 코드/광고/인플루언서 집계는 기존 시트 기반 유지)
  includeDkOnly?: boolean;
}

// 풀 빌드는 페이지 여러 곳(콘텐츠/광고/상세)에서 쓰므로 결과 자체를 5분 캐시.
// (DK content_metrics_daily 50K행 쿼리 — per-principal rate limit 보호)
export async function buildContentPool(opts: BuildOptions = {}): Promise<ContentSummary[]> {
  return unstable_cache(
    () => buildContentPoolUncached(opts),
    ["content-pool", JSON.stringify(opts)],
    { revalidate: 300 },
  )();
}

// 같은 영상(postShortcode)이 여러 행이면 1행으로 병합. shortcode 없는 행(URL 미기재)은 각각 유지.
// 병합 시 앞 행의 빈 필드를 뒤 행 값으로 보충(코드·제품·평가 누락 방지).
function dedupeCollabsByShortcode(rows: CollabRow[]): CollabRow[] {
  const bySc = new Map<string, CollabRow>();
  const out: CollabRow[] = [];
  for (const c of rows) {
    const sc = c.postShortcode;
    if (!sc) { out.push(c); continue; }
    const prev = bySc.get(sc);
    if (!prev) { bySc.set(sc, c); out.push(c); continue; }
    for (const k of Object.keys(c) as (keyof CollabRow)[]) {
      const pv = prev[k], cv = c[k];
      if ((pv === "" || pv == null || pv === 0) && cv !== "" && cv != null && cv !== 0) {
        (prev as unknown as Record<string, unknown>)[k] = cv;
      }
    }
  }
  return out;
}

async function buildContentPoolUncached(opts: BuildOptions = {}): Promise<ContentSummary[]> {
  const qualUp = opts.qualUpThreshold ?? QUAL_BUMP_UP;
  const qualDown = opts.qualDownThreshold ?? QUAL_BUMP_DOWN;

  const [master, collabsRaw, metrics, posts] = await Promise.all([
    fetchMaster(),
    fetchCollabs(),
    fetchContentMetrics(180),
    fetchContentPosts(365, "grosmimi"),
  ]);
  // 같은 영상(shortcode)이 콜라보 시트에 여러 행이면 1개로 병합 → 콘텐츠·코드 탭에서
  // 같은 영상이 콜라보 2번으로 잡히던 문제 해결 (WL 싱크가 기존 행 갱신 대신 행 추가한 케이스). 2026-07-07
  const collabs = dedupeCollabsByShortcode(collabsRaw);

  const sheetAdCodes = new Map<string, string>();
  for (const c of collabs) {
    if (c.adCode && c.postShortcode) sheetAdCodes.set(c.adCode, c.postShortcode);
  }
  const metricsByPost = new Map<string, ContentMetric[]>();
  for (const m of metrics) {
    if (!m.post_id) continue;
    const arr = metricsByPost.get(m.post_id) ?? [];
    arr.push(m);
    metricsByPost.set(m.post_id, arr);
  }
  const postByShortcode = new Map<string, ContentPost>();
  for (const p of posts) {
    if (p.post_id) postByShortcode.set(p.post_id, p);
  }
  const masterByHandle = new Map<string, MasterRow>();
  for (const m of master) {
    const key = m.igHandle.toLowerCase().trim();
    if (key) masterByHandle.set(key, m);
  }

  const collabKeys: CollabKey[] = collabs
    .filter((c) => c.postShortcode && c.creatorId)
    .map((c) => ({
      shortcode: c.postShortcode!,
      handle: c.creatorId,
      postDate: c.postShortcode ? postByShortcode.get(c.postShortcode)?.post_date ?? null : null,
      product: c.product,
    }));
  const wlResult = await fetchWlAttributionByShortcode(sheetAdCodes, collabKeys);

  // ── DK 자동 편입 (opt-in) — 시트에 아직 없는 JP·IG 새 콘텐츠를 빈 콜라보 행으로 추가 ──
  const dkShortcodes = new Set<string>();
  let rows: CollabRow[] = collabs;
  if (opts.includeDkOnly) {
    const sheetScs = new Set(collabs.map((c) => c.postShortcode).filter(Boolean));
    const dkRows: CollabRow[] = [];
    for (const p of posts) {
      if (!p.post_id || sheetScs.has(p.post_id) || dkShortcodes.has(p.post_id)) continue;
      if (p.region !== "jp" || p.platform !== "instagram") continue;
      dkShortcodes.add(p.post_id);
      dkRows.push({
        period: "", internalId: "", creatorName: p.username, creatorId: p.username,
        platform: "Instagram", deliverableType: "", product: "", pic: "", status: "",
        expectedUpload: "", wlCode: "",
        url: p.url || `https://www.instagram.com/reel/${p.post_id}/`,
        postShortcode: p.post_id,
        conceptType: "", dealType: "", feeJpy: 0, feeRaw: "", commissionRate: "",
        adCode: "", whitelistingDuration: "", paymentStatus: "", paymentDate: "",
        scriptFollow: "", compliance: "", easeOfWork: "", hook: "", wowScene: "",
        overall: "", hookType: "",
      });
    }
    rows = [...collabs, ...dkRows];
  }

  const todayUTC = new Date();
  todayUTC.setUTCHours(0, 0, 0, 0);

  // ── per-content base 데이터 ──
  type Base = Omit<ContentSummary,
    | "organicRateScore" | "organicVtrScore" | "organicQualScore" | "organicQuantScore"
    | "organicPercentile" | "organicBaseGrade" | "organicQualBump" | "organicGrade"
    | "wlRateScore" | "wlVtrScore" | "wlQualScore" | "wlQuantScore"
    | "wlPercentile" | "wlBaseGrade" | "wlQualBump" | "wlGrade"
    | "rateScore" | "vtrScore" | "erScore" | "quantScore" | "quantPercentile"
    | "baseGrade" | "qualBump" | "finalGrade"
  >;

  const bases: Base[] = rows.map((c): Base => {
    const post = c.postShortcode ? postByShortcode.get(c.postShortcode) ?? null : null;
    const postDate = post?.post_date ?? null;
    const cogs = lookupCogs(c.product);
    const handleLower = c.creatorId.toLowerCase().trim();

    let followers: number | null = null;
    let followersSource: "dk" | "master" | "na" = "na";
    if (post?.followers != null && post.followers > 0) {
      followers = post.followers;
      followersSource = "dk";
    } else {
      const m = masterByHandle.get(handleLower);
      if (m) {
        const fparsed = parseFollowers(m.igFollowers);
        if (fparsed != null && fparsed > 0) {
          followers = fparsed;
          followersSource = "master";
        }
      }
    }

    let postAge: number | null = null;
    if (postDate) {
      const pd = new Date(`${postDate}T00:00:00Z`);
      postAge = Math.round((todayUTC.getTime() - pd.getTime()) / 86_400_000);
    }

    // D+3 organic view
    const viewRes = c.postShortcode
      ? resolveD3OrganicView(c.postShortcode, postDate, metricsByPost)
      : { view: null, method: "na" as ViewMethod, sourceAge: null };
    const organicViewD3 = viewRes.view;

    // 현재 누적(전체) view — metrics 최신 view>0 우선(진짜 누적), 없으면 views_30d fallback.
    let currentViews: number | null = c.postShortcode
      ? latestNonzeroView(metricsByPost.get(c.postShortcode) ?? [])
      : null;
    if (currentViews == null) currentViews = post?.views_30d ?? null;

    const er = post?.engagement_rate ?? null;

    const wl = c.postShortcode ? wlResult.byShortcode.get(c.postShortcode) : undefined;
    const wlSpendKrw = wl?.spend ?? 0;
    const wlImpressions = wl?.impressions ?? 0;
    const wlClicks = wl?.clicks ?? 0;
    const wlCtr = wlImpressions > 0 ? (wlClicks / wlImpressions) * 100 : null;
    const wlLpv: number | null = wl?.lpv ?? null;               // DK LPV 배포 후 채워짐 (Part B)
    const wlCplpv: number | null = wlLpv != null && wlLpv > 0 ? wlSpendKrw / wlLpv : null;
    const hasWl = wlSpendKrw > 0 || wlImpressions > 0;

    const feeKrw = jpyToKrw(c.feeJpy);
    const organicCostKrw = feeKrw + cogs.unitKrw;
    const totalCostKrw = organicCostKrw + wlSpendKrw;

    // Organic metrics
    const organicRate = organicViewD3 != null && organicViewD3 > 0
      ? organicCostKrw / organicViewD3
      : null;
    const organicVtr = followers != null && followers > 0 && organicViewD3 != null
      ? organicViewD3 / followers
      : null;

    // WL metrics (hasWl 일 때만 유의미)
    const wlUnifiedRate = currentViews != null && currentViews > 0
      ? totalCostKrw / currentViews
      : null;
    const wlVtr = followers != null && followers > 0 && currentViews != null
      ? currentViews / followers
      : null;
    const wlCpm = wlImpressions > 0 ? (wlSpendKrw / wlImpressions) * 1000 : null;

    return {
      ...c,
      product: normalizeProduct(c.product),  // 표시 통일 (COGS lookup 은 위에서 원문으로 완료)
      igHandle: handleLower,
      dkOnly: c.postShortcode != null && dkShortcodes.has(c.postShortcode),
      postDate,
      postAge,
      followers,
      followersSource,
      organicViewD3,
      organicViewMethod: viewRes.method,
      organicViewSourceAge: viewRes.sourceAge,
      currentViews,
      engagementRate: er,
      feeJpyNumeric: c.feeJpy,
      feeKrw,
      cogs,
      organicCostKrw,
      wlSpendKrw,
      wlImpressions,
      wlClicks,
      wlCtr,
      wlLpv,
      wlCplpv,
      wlAdIds: wl?.adIds ?? [],
      totalCostKrw,
      organicRateKrwPerView: organicRate,
      organicVtr,
      wlUnifiedRateKrwPerView: wlUnifiedRate,
      wlVtr,
      wlCpmKrw: wlCpm,
      overallScore: parseScore(c.overall),
      hasWl,
      // aliases
      organicView: organicViewD3,
      viewMethod: viewRes.method,
      viewSourceAge: viewRes.sourceAge,
      organicCostJpy: organicCostKrw,
      wlSpendJpy: wlSpendKrw,
      organicRateJpyPerView: organicRate,
      wlCpmJpy: wlCpm,
      totalCostJpy: totalCostKrw,
      totalReach: (organicViewD3 ?? 0) + wlImpressions > 0 ? (organicViewD3 ?? 0) + wlImpressions : null,
      organicViewForUnit: organicViewD3,
      d7Views: null,
      d30Views: organicViewD3,
      d7Offset: null,
      d30Offset: viewRes.sourceAge,
      unifiedRateJpyPerView: wlUnifiedRate,
    };
  });

  // ── Organic 풀 score (모든 콘텐츠) ──
  const organicRatePool = bases.map((d) => d.organicRateKrwPerView).filter((v): v is number => v != null && v > 0).sort((a, b) => a - b);
  const organicVtrPool = bases.map((d) => d.organicVtr).filter((v): v is number => v != null && v > 0).sort((a, b) => a - b);
  const organicCostPool = bases.map((d) => d.organicCostKrw).filter((v) => v > 0).sort((a, b) => a - b);
  const qualPool = bases.map((d) => d.overallScore).filter((v): v is number => v != null).sort((a, b) => a - b);

  // ── WL 풀 score (hasWl 만) ──
  const wlBases = bases.filter((d) => d.hasWl);
  const wlRatePool = wlBases.map((d) => d.wlUnifiedRateKrwPerView).filter((v): v is number => v != null && v > 0).sort((a, b) => a - b);
  const wlVtrPool = wlBases.map((d) => d.wlVtr).filter((v): v is number => v != null && v > 0).sort((a, b) => a - b);
  const wlCostPool = wlBases.map((d) => d.totalCostKrw).filter((v) => v > 0).sort((a, b) => a - b);
  const wlQualPool = wlBases.map((d) => d.overallScore).filter((v): v is number => v != null).sort((a, b) => a - b);

  // per-content scoring
  const final: ContentSummary[] = bases.map((d) => {
    // Organic scores
    let oRS: number | null = d.organicRateKrwPerView != null && d.organicRateKrwPerView > 0 && organicRatePool.length > 0
      ? 100 - percentileRank(organicRatePool, d.organicRateKrwPerView)
      : null;
    if (oRS == null) {
      if (d.organicCostKrw === 0) oRS = 100;
      else if (organicCostPool.length > 0) oRS = 100 - percentileRank(organicCostPool, d.organicCostKrw);
    }
    const oVS = d.organicVtr != null && d.organicVtr > 0 && organicVtrPool.length > 0
      ? percentileRank(organicVtrPool, d.organicVtr)
      : null;
    const oQS = d.overallScore != null && qualPool.length > 0
      ? percentileRank(qualPool, d.overallScore)
      : null;
    let oW = 0, oSum = 0;
    if (oRS != null) { oW += W_RATE * oRS; oSum += W_RATE; }
    if (oVS != null) { oW += W_VTR * oVS; oSum += W_VTR; }
    if (oQS != null) { oW += W_QUAL * oQS; oSum += W_QUAL; }
    const oQuant = oSum > 0 ? oW / oSum : null;

    // WL scores (hasWl 만 유의미)
    let wRS: number | null = null;
    let wVS: number | null = null;
    let wQS: number | null = null;
    let wQuant: number | null = null;
    if (d.hasWl) {
      wRS = d.wlUnifiedRateKrwPerView != null && d.wlUnifiedRateKrwPerView > 0 && wlRatePool.length > 0
        ? 100 - percentileRank(wlRatePool, d.wlUnifiedRateKrwPerView)
        : null;
      if (wRS == null) {
        if (d.totalCostKrw === 0) wRS = 100;
        else if (wlCostPool.length > 0) wRS = 100 - percentileRank(wlCostPool, d.totalCostKrw);
      }
      wVS = d.wlVtr != null && d.wlVtr > 0 && wlVtrPool.length > 0
        ? percentileRank(wlVtrPool, d.wlVtr)
        : null;
      wQS = d.overallScore != null && wlQualPool.length > 0
        ? percentileRank(wlQualPool, d.overallScore)
        : null;
      let wW = 0, wSum = 0;
      if (wRS != null) { wW += W_RATE * wRS; wSum += W_RATE; }
      if (wVS != null) { wW += W_VTR * wVS; wSum += W_VTR; }
      if (wQS != null) { wW += W_QUAL * wQS; wSum += W_QUAL; }
      wQuant = wSum > 0 ? wW / wSum : null;
    }

    return { ...d,
      organicRateScore: oRS, organicVtrScore: oVS, organicQualScore: oQS, organicQuantScore: oQuant,
      organicPercentile: null, organicBaseGrade: "NA" as Grade, organicQualBump: 0 as const, organicGrade: "NA" as Grade,
      wlRateScore: wRS, wlVtrScore: wVS, wlQualScore: wQS, wlQuantScore: wQuant,
      wlPercentile: null, wlBaseGrade: "NA" as Grade, wlQualBump: 0 as const, wlGrade: "NA" as Grade,
      rateScore: oRS, vtrScore: oVS, erScore: null, quantScore: oQuant,
      quantPercentile: null, baseGrade: "NA" as Grade, qualBump: 0 as const, finalGrade: "NA" as Grade,
    };
  });

  // ── grade 산정 ──
  const organicScoreVals = final.map((d) => d.organicQuantScore).filter((v): v is number => v != null).sort((a, b) => a - b);
  const wlScoreVals = final.filter((d) => d.hasWl).map((d) => d.wlQuantScore).filter((v): v is number => v != null).sort((a, b) => a - b);

  for (const d of final) {
    // Organic grade
    if (d.organicQuantScore != null) {
      const pct = percentileRank(organicScoreVals, d.organicQuantScore);
      const base = gradeFromPercentile(pct);
      let bump: 1 | -1 | 0 = 0;
      if (d.overallScore != null) {
        if (d.overallScore >= qualUp) bump = 1;
        else if (d.overallScore <= qualDown) bump = -1;
      }
      let graded = bumpGrade(base, bump);
      if (graded === "S" && !sGatePass(d.organicRateScore, d.organicVtrScore)) graded = "A";
      const viewTracked = d.organicViewD3 != null;
      if (!viewTracked && (graded === "S" || graded === "A")) graded = "B";
      d.organicPercentile = pct;
      d.organicBaseGrade = base;
      d.organicQualBump = bump;
      d.organicGrade = graded;
    }
    // WL grade (hasWl 만)
    if (d.hasWl && d.wlQuantScore != null) {
      const pct = percentileRank(wlScoreVals, d.wlQuantScore);
      const base = gradeFromPercentile(pct);
      let bump: 1 | -1 | 0 = 0;
      if (d.overallScore != null) {
        if (d.overallScore >= qualUp) bump = 1;
        else if (d.overallScore <= qualDown) bump = -1;
      }
      let graded = bumpGrade(base, bump);
      if (graded === "S" && !sGatePass(d.wlRateScore, d.wlVtrScore)) graded = "A";
      const viewTracked = d.currentViews != null && d.currentViews > 0;
      if (!viewTracked && (graded === "S" || graded === "A")) graded = "B";
      d.wlPercentile = pct;
      d.wlBaseGrade = base;
      d.wlQualBump = bump;
      d.wlGrade = graded;
    }
    // Legacy alias = Organic grade
    d.quantScore = d.organicQuantScore;
    d.quantPercentile = d.organicPercentile;
    d.baseGrade = d.organicBaseGrade;
    d.qualBump = d.organicQualBump;
    d.finalGrade = d.organicGrade;
  }

  return final;
}

// ── Influencer-level wrapper (detail page 호환) ──
export interface InfluencerSummary {
  igHandle: string;
  master: MasterRow | null;
  collabs: ContentSummary[];
  collabCount: number;
  paidCount: number;
  giftedCount: number;
  followers: number | null;
  // Cost (KRW)
  totalFeeJpy: number;
  totalCogsJpy: number;
  totalWlSpendJpy: number;
  // 평균 metric — Organic
  avgOrganicRate: number | null;
  avgOrganicVtr: number | null;
  // 평균 metric — WL
  avgWlUnifiedRate: number | null;
  avgWlVtr: number | null;
  avgWlCpm: number | null;
  avgEngagementRate: number | null;
  qualitativeMean: number | null;
  // 등급 — 최고 콘텐츠 등급
  organicGrade: Grade;
  wlGrade: Grade;
  primaryCollabUrl: string | null;
  hasWl: boolean;
  // legacy
  totalReach: number;
  totalOrganicView: number;
  totalWlImpressions: number;
  totalCostJpy: number;
  unifiedRateJpyPerView: number | null;
  avgCurrentViews: number | null;
  avgD7Views: number | null;
  avgD30Views: number | null;
  finalGrade: Grade;
  baseGrade: Grade;
  qualBump: 1 | -1 | 0;
  quantScore: number | null;
  quantPercentile: number | null;
}

export type EnrichedCollab = ContentSummary;

export async function buildInfluencerPool(opts: BuildOptions = {}): Promise<InfluencerSummary[]> {
  const contents = await buildContentPool(opts);
  const master = await fetchMaster();
  const masterByHandle = new Map<string, MasterRow>();
  for (const m of master) {
    const key = m.igHandle.toLowerCase().trim();
    if (key) masterByHandle.set(key, m);
  }

  const byHandle = new Map<string, ContentSummary[]>();
  for (const c of contents) {
    const arr = byHandle.get(c.igHandle) ?? [];
    arr.push(c);
    byHandle.set(c.igHandle, arr);
  }

  function avg(xs: (number | null | undefined)[]): number | null {
    const v = xs.filter((x): x is number => typeof x === "number" && Number.isFinite(x));
    if (v.length === 0) return null;
    return v.reduce((a, b) => a + b, 0) / v.length;
  }
  const order: Grade[] = ["S", "A", "B", "C", "NA"];

  const out: InfluencerSummary[] = [];
  for (const [handle, cs] of byHandle) {
    const totalFee = cs.reduce((s, c) => s + c.feeKrw, 0);
    const totalCogs = cs.reduce((s, c) => s + c.cogs.unitKrw, 0);
    const totalWl = cs.reduce((s, c) => s + c.wlSpendKrw, 0);
    const totalOrgView = cs.reduce((s, c) => s + (c.organicViewD3 ?? 0), 0);
    const totalWlImp = cs.reduce((s, c) => s + c.wlImpressions, 0);
    const paidCount = cs.filter((c) => c.dealType.trim().toLowerCase() === "paid").length;
    const primary = cs.filter((c) => c.url).pop();

    let bestOrganic: Grade = "NA";
    let bestWl: Grade = "NA";
    for (const c of cs) {
      if (order.indexOf(c.organicGrade) < order.indexOf(bestOrganic)) bestOrganic = c.organicGrade;
      if (order.indexOf(c.wlGrade) < order.indexOf(bestWl)) bestWl = c.wlGrade;
    }
    const followers = cs.find((c) => c.followers != null)?.followers ?? null;

    out.push({
      igHandle: handle,
      master: masterByHandle.get(handle) ?? null,
      collabs: cs,
      collabCount: cs.length,
      paidCount,
      giftedCount: cs.length - paidCount,
      followers,
      totalFeeJpy: totalFee,
      totalCogsJpy: totalCogs,
      totalWlSpendJpy: totalWl,
      avgOrganicRate: avg(cs.map((c) => c.organicRateKrwPerView)),
      avgOrganicVtr: avg(cs.map((c) => c.organicVtr)),
      avgWlUnifiedRate: avg(cs.filter((c) => c.hasWl).map((c) => c.wlUnifiedRateKrwPerView)),
      avgWlVtr: avg(cs.filter((c) => c.hasWl).map((c) => c.wlVtr)),
      avgWlCpm: avg(cs.filter((c) => c.hasWl).map((c) => c.wlCpmKrw)),
      avgEngagementRate: avg(cs.map((c) => c.engagementRate)),
      qualitativeMean: avg(cs.map((c) => c.overallScore)),
      organicGrade: bestOrganic,
      wlGrade: bestWl,
      primaryCollabUrl: primary?.url ?? null,
      hasWl: cs.some((c) => c.hasWl),
      // legacy
      totalReach: totalOrgView + totalWlImp,
      totalOrganicView: totalOrgView,
      totalWlImpressions: totalWlImp,
      totalCostJpy: totalFee + totalCogs + totalWl,
      unifiedRateJpyPerView: totalOrgView + totalWlImp > 0 ? (totalFee + totalCogs + totalWl) / (totalOrgView + totalWlImp) : null,
      avgCurrentViews: avg(cs.map((c) => c.currentViews)),
      avgD7Views: null,
      avgD30Views: avg(cs.map((c) => c.organicViewD3)),
      finalGrade: bestOrganic,
      baseGrade: bestOrganic,
      qualBump: 0,
      quantScore: avg(cs.map((c) => c.organicQuantScore)),
      quantPercentile: avg(cs.map((c) => c.organicPercentile)),
    });
  }
  out.sort((a, b) => {
    const g = order.indexOf(a.organicGrade) - order.indexOf(b.organicGrade);
    if (g !== 0) return g;
    return (b.quantScore ?? -1) - (a.quantScore ?? -1);
  });
  return out;
}

export async function fetchInfluencer(handle: string): Promise<InfluencerSummary | null> {
  const pool = await buildInfluencerPool();
  const key = handle.toLowerCase().trim();
  return pool.find((p) => p.igHandle === key) ?? null;
}
