// SERVER-ONLY. Content Tags (JP) 탭에 수동 태그(km_manual/hook_manual) upsert.
// Google Sheets API 쓰기 — service account JWT (RS256, node:crypto, 외부 deps X).

import "server-only";
import { createSign } from "node:crypto";

const TAG_SHEET_ID = process.env.TAG_SHEET_ID || "13S1cST2ukuNNHNUmyXAr1HuaYPsuuK_EfUQ10IWIQsE";
const TAG_TAB = "Content Tags (JP)";

// 컬럼 위치는 헤더 행에서 동적 해석 — 고정 인덱스는 컬럼 삽입 시 엉뚱한 셀을 덮는 사고
// (7/13 hook_visual/hook_caption 삽입으로 km_manual O→Q 밀림) 재발 방지.

function b64url(buf: Buffer): string {
  return buf.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

let cachedToken: { token: string; exp: number } | null = null;

async function getAccessToken(): Promise<string> {
  if (cachedToken && cachedToken.exp > Date.now() + 60_000) return cachedToken.token;

  const email = process.env.GOOGLE_SA_EMAIL;
  let key = process.env.GOOGLE_SA_PRIVATE_KEY;
  if (!email || !key) throw new Error("GOOGLE_SA_EMAIL / GOOGLE_SA_PRIVATE_KEY missing");
  key = key.replace(/\\n/g, "\n");

  const iat = Math.floor(Date.now() / 1000);
  const header = b64url(Buffer.from(JSON.stringify({ alg: "RS256", typ: "JWT" })));
  const claims = b64url(Buffer.from(JSON.stringify({
    iss: email,
    scope: "https://www.googleapis.com/auth/spreadsheets",
    aud: "https://oauth2.googleapis.com/token",
    iat,
    exp: iat + 3600,
  })));
  const signer = createSign("RSA-SHA256");
  signer.update(`${header}.${claims}`);
  const jwt = `${header}.${claims}.${b64url(signer.sign(key))}`;

  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: jwt,
    }),
  });
  if (!res.ok) throw new Error(`SA token exchange ${res.status}: ${await res.text()}`);
  const data = (await res.json()) as { access_token: string; expires_in: number };
  cachedToken = { token: data.access_token, exp: Date.now() + data.expires_in * 1000 };
  return data.access_token;
}

const API = "https://sheets.googleapis.com/v4/spreadsheets";
const TAB_ENC = encodeURIComponent(`'${TAG_TAB}'`);

async function sheetsFetch(path: string, init?: RequestInit): Promise<unknown> {
  const token = await getAccessToken();
  const res = await fetch(`${API}/${TAG_SHEET_ID}${path}`, {
    ...init,
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", ...init?.headers },
  });
  if (!res.ok) throw new Error(`Sheets API ${res.status}: ${await res.text()}`);
  return res.json();
}

function colLetter(n: number): string {
  let s = "", x = n;
  while (x > 0) {
    const r = (x - 1) % 26;
    s = String.fromCharCode(65 + r) + s;
    x = Math.floor((x - 1) / 26);
  }
  return s; // 1→A … 27→AA
}

// 헤더 행에서 컬럼 위치(1-based) 해석 — 컬럼 이동/삽입에 안전
async function resolveCols(): Promise<{ shortcode: number; km: number; hook: number; last: number }> {
  const got = (await sheetsFetch(`/values/${TAB_ENC}!1:1`)) as { values?: string[][] };
  const hdr = (got.values?.[0] ?? []).map((h) => h.trim());
  const find = (name: string) => {
    const i = hdr.indexOf(name);
    if (i < 0) throw new Error(`JP 탭 헤더에 ${name} 없음 — 시트 구조 확인`);
    return i + 1;
  };
  return { shortcode: find("shortcode"), km: find("km_manual"), hook: find("hook_manual"), last: hdr.length };
}

export type ManualField = "km" | "hook";

// shortcode 행 찾아 해당 manual 셀만 갱신. 행 없으면 새 행 append (수동 태깅만 있는 콘텐츠).
export async function upsertManualTag(shortcode: string, field: ManualField, value: string): Promise<void> {
  const cols = await resolveCols();
  const col = field === "km" ? cols.km : cols.hook;

  const got = (await sheetsFetch(
    `/values/${TAB_ENC}!${colLetter(cols.shortcode)}:${colLetter(cols.shortcode)}`,
  )) as { values?: string[][] };
  const rows = got.values ?? [];
  let rowIx = -1; // 1-based sheet row
  for (let i = 1; i < rows.length; i++) { // 0행 = 헤더
    if ((rows[i]?.[0] ?? "").trim() === shortcode) { rowIx = i + 1; break; }
  }

  if (rowIx > 0) {
    const cell = `${colLetter(col)}${rowIx}`;
    await sheetsFetch(`/values/${TAB_ENC}!${cell}?valueInputOption=RAW`, {
      method: "PUT",
      body: JSON.stringify({ values: [[value]] }),
    });
    return;
  }

  // 미태깅 콘텐츠 — shortcode + manual 값만 채운 새 행
  const width = Math.max(cols.last, col, cols.shortcode);
  const row = new Array<string>(width).fill("");
  row[cols.shortcode - 1] = shortcode;
  row[col - 1] = value;
  await sheetsFetch(
    `/values/${TAB_ENC}!A:${colLetter(width)}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`,
    { method: "POST", body: JSON.stringify({ values: [row] }) },
  );
}
