import Link from "next/link";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { EnvWarning } from "@/components/meta/EnvWarning";
import { ChevronDown } from "lucide-react";
import { fetchAds, fetchMonthlySpend, fetchMonthlyAdSpend, periodRange, type AdRow } from "@/lib/meta-aggregations";
import { rppMonthly, rppRange, rppUpdatedAt, fetchJpyKrw, type RppMonthlyRow } from "@/lib/rpp";
import { salesMonthly, salesRange, type SalesMonthlyRow } from "@/lib/rakuten-sales";
import { fmtWon, fmtPct, fmtNum } from "@/lib/format";
import { cn } from "@/lib/utils";

export const revalidate = 60;

const PERIODS = [
  { key: "1d", label: "어제" },
  { key: "7d", label: "7일" },
  { key: "30d", label: "30일" },
  { key: "mtd", label: "MTD" },
  { key: "lifetime", label: "Lifetime" },
  { key: "monthly", label: "월별" },
] as const;

type Period = (typeof PERIODS)[number]["key"];

interface SearchParams {
  period?: string;
  view?: string;
}

export default async function BudgetPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const sp = await searchParams;
  const period = (PERIODS.find((p) => p.key === sp.period)?.key ?? "7d") as Period;
  const view = sp.view === "ad" || sp.view === "adset" ? sp.view : "campaign";

  let body: React.ReactNode;
  try {
    if (period === "monthly") {
      const [monthly, monthlyAds, fx] = await Promise.all([
        fetchMonthlySpend(),
        fetchMonthlyAdSpend(),
        fetchJpyKrw(),
      ]);
      body = (
        <>
          <PageHeader period={period} view={view} rangeLabel="광고 시작 (2025-12) ~ 현재" />
          <TotalAdSpendCard monthly={monthly} rpp={rppMonthly()} sales={salesMonthly()} rate={fx.rate} fxLive={fx.live} />
          <MonthlyCard monthly={monthly} monthlyAds={monthlyAds} />
        </>
      );
      return <div className="space-y-6">{body}</div>;
    }

    const { since, until } = periodRange(period);
    const [ads, fx] = await Promise.all([
      fetchAds(since, until).then((rows) => rows.filter((a) => a.spend > 0)),
      fetchJpyKrw(),
    ]);
    const totalSpend = ads.reduce((s, a) => s + a.spend, 0);
    const rpp = rppRange(since, until);
    const rppKrw = rpp.spendJpy * fx.rate;
    const sales = salesRange(since, until);
    const salesKrw = sales.salesJpy * fx.rate;
    const troas = totalSpend + rppKrw > 0 ? salesKrw / (totalSpend + rppKrw) : 0;
    const grouped = groupBy(ads, view);

    body = (
      <>
        <PageHeader period={period} view={view} rangeLabel={`${since} ~ ${until}`} />

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">총 광고비 (Meta + RPP)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-semibold tabular-nums">{fmtWon(totalSpend + rppKrw)}</div>
            <div className="mt-2 grid grid-cols-2 gap-3 md:grid-cols-4">
              <div className="rounded-lg bg-secondary/40 px-3 py-2">
                <div className="text-[11px] text-muted-foreground">Meta</div>
                <div className="text-base font-semibold tabular-nums">{fmtWon(totalSpend)}</div>
                <div className="text-[11px] text-muted-foreground">
                  {ads.length}개 광고 · LPV {fmtNum(ads.reduce((s, a) => s + a.lpv, 0))}
                </div>
              </div>
              <div className="rounded-lg bg-secondary/40 px-3 py-2">
                <div className="text-[11px] text-muted-foreground">RPP (라쿠텐)</div>
                <div className="text-base font-semibold tabular-nums">{fmtWon(rppKrw)}</div>
                <div className="text-[11px] text-muted-foreground">
                  ¥{fmtNum(rpp.spendJpy)} · 클릭 {fmtNum(rpp.clicks)}
                </div>
              </div>
              <div className="rounded-lg bg-secondary/40 px-3 py-2">
                <div className="text-[11px] text-muted-foreground">라쿠텐 매출</div>
                <div className="text-base font-semibold tabular-nums">{fmtWon(salesKrw)}</div>
                <div className="text-[11px] text-muted-foreground">
                  ¥{fmtNum(sales.salesJpy)} · 주문 {fmtNum(sales.orders)}
                </div>
              </div>
              <div className="rounded-lg bg-secondary/40 px-3 py-2">
                <div className="text-[11px] text-muted-foreground">Total ROAS</div>
                <div className="text-base font-semibold tabular-nums">{troas.toFixed(2)}x</div>
                <div className="text-[11px] text-muted-foreground">매출 ÷ (Meta + RPP)</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between gap-2">
              <CardTitle className="text-base">단위별 분해</CardTitle>
              <div className="flex gap-1.5">
                {(["campaign", "adset", "ad"] as const).map((v) => (
                  <Link
                    key={v}
                    href={{ pathname: "/budget", query: { period, view: v } }}
                    className={cn(
                      "rounded-md px-2 py-1 text-xs font-medium",
                      view === v
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-muted-foreground hover:bg-secondary/70",
                    )}
                  >
                    {v === "campaign" ? "캠페인" : v === "adset" ? "애드셋" : "광고"}
                  </Link>
                ))}
              </div>
            </div>
          </CardHeader>
          <CardContent className="overflow-x-auto p-0">
            <Table className="md:min-w-[640px]">
              <TableHeader>
                <TableRow>
                  <TableHead>{view === "campaign" ? "캠페인" : view === "adset" ? "애드셋" : "광고"}</TableHead>
                  <TableHead className="text-right">Spend</TableHead>
                  <TableHead className="text-right">Share</TableHead>
                  <TableHead className="hidden text-right md:table-cell">LPV</TableHead>
                  <TableHead className="hidden text-right md:table-cell">CTR</TableHead>
                  <TableHead className="text-right">CPLPV</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {grouped.map((g) => (
                  <TableRow key={g.key}>
                    <TableCell className="max-w-[130px] md:max-w-[280px]">
                      <div className="truncate text-sm font-medium">{g.name}</div>
                    </TableCell>
                    <TableCell className="text-right tabular-nums">{fmtWon(g.spend)}</TableCell>
                    <TableCell className="text-right tabular-nums text-muted-foreground">
                      {fmtPct(totalSpend > 0 ? (g.spend / totalSpend) * 100 : 0, 1)}
                    </TableCell>
                    <TableCell className="hidden text-right tabular-nums md:table-cell">{fmtNum(g.lpv)}</TableCell>
                    <TableCell className="hidden text-right tabular-nums md:table-cell">{fmtPct(g.ctr)}</TableCell>
                    <TableCell className="text-right tabular-nums">{fmtWon(g.cplpv)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </>
    );
  } catch (e) {
    body = <EnvWarning error={e instanceof Error ? e.message : String(e)} />;
  }
  return <div className="space-y-6">{body}</div>;
}

function PageHeader({ period, view, rangeLabel }: { period: Period; view: string; rangeLabel: string }) {
  return (
    <section>
      <div className="mb-3 flex items-baseline justify-between">
        <h1 className="text-lg font-semibold tracking-tight">예산</h1>
        <span className="text-xs text-muted-foreground">{rangeLabel}</span>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {PERIODS.map((p) => (
          <Link
            key={p.key}
            href={{ pathname: "/budget", query: { period: p.key, view } }}
            className={cn(
              "rounded-md px-3 py-1.5 text-sm font-medium",
              period === p.key
                ? "bg-primary text-primary-foreground shadow-sm"
                : "bg-secondary text-muted-foreground hover:bg-secondary/70",
            )}
          >
            {p.label}
          </Link>
        ))}
      </div>
    </section>
  );
}

// 월별 총 광고비 = Meta(₩) + RPP(¥→₩ 환산). RPP = 라쿠텐 콘솔 일별 수집 (매일 09:20).
function TotalAdSpendCard({
  monthly, rpp, sales, rate, fxLive,
}: {
  monthly: Awaited<ReturnType<typeof fetchMonthlySpend>>;
  rpp: RppMonthlyRow[];
  sales: SalesMonthlyRow[];
  rate: number;
  fxLive: boolean;
}) {
  const metaByMonth = new Map(monthly.rows.map((m) => [m.month, m.spend]));
  const rppByMonth = new Map(rpp.map((r) => [r.month, r.spendJpy]));
  const salesByMonth = new Map(sales.map((s) => [s.month, s.salesJpy]));
  const months = [...new Set([...metaByMonth.keys(), ...rppByMonth.keys()])].sort((a, b) =>
    b.localeCompare(a),
  );
  const rows = months.map((month) => {
    const meta = metaByMonth.get(month) ?? 0;
    const rppJpy = rppByMonth.get(month) ?? 0;
    const rppKrw = rppJpy * rate;
    const salesKrw = (salesByMonth.get(month) ?? 0) * rate;
    const total = meta + rppKrw;
    return { month, meta, rppJpy, rppKrw, total, salesKrw, troas: total > 0 ? salesKrw / total : 0 };
  });
  const sum = rows.reduce(
    (s, r) => ({
      meta: s.meta + r.meta, rppKrw: s.rppKrw + r.rppKrw,
      total: s.total + r.total, salesKrw: s.salesKrw + r.salesKrw,
    }),
    { meta: 0, rppKrw: 0, total: 0, salesKrw: 0 },
  );
  const updated = rppUpdatedAt();
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-baseline justify-between gap-2">
          <CardTitle className="text-base">월별 총 광고비 · Total ROAS</CardTitle>
          <span className="text-sm font-bold tabular-nums">
            TOTAL {fmtWon(sum.total)} · {sum.total > 0 ? (sum.salesKrw / sum.total).toFixed(2) : "0.00"}x
          </span>
        </div>
        <p className="text-xs text-muted-foreground">
          Total ROAS = 라쿠텐 매출 ÷ (Meta + RPP). RPP·매출은 일별 자동 수집
          (¥→₩ {fxLive ? "실시간" : "고정"} 환율 {rate.toFixed(2)}
          {updated ? ` · 수집 ${updated.slice(0, 10)}` : ""})
        </p>
      </CardHeader>
      <CardContent className="overflow-x-auto p-0">
        <Table className="md:min-w-[680px]">
          <TableHeader>
            <TableRow>
              <TableHead>월</TableHead>
              <TableHead className="text-right">Meta</TableHead>
              <TableHead className="text-right">RPP</TableHead>
              <TableHead className="text-right">광고비 합계</TableHead>
              <TableHead className="text-right">라쿠텐 매출</TableHead>
              <TableHead className="text-right">Total ROAS</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((r) => (
              <TableRow key={r.month}>
                <TableCell className="text-sm font-medium">{r.month}</TableCell>
                <TableCell className="text-right tabular-nums">{fmtWon(r.meta)}</TableCell>
                <TableCell className="text-right tabular-nums">
                  {fmtWon(r.rppKrw)}
                  <span className="ml-1 text-[11px] text-muted-foreground">
                    ¥{fmtNum(r.rppJpy)}
                  </span>
                </TableCell>
                <TableCell className="text-right tabular-nums">{fmtWon(r.total)}</TableCell>
                <TableCell className="text-right tabular-nums">{fmtWon(r.salesKrw)}</TableCell>
                <TableCell className="text-right tabular-nums font-semibold">{r.troas.toFixed(2)}x</TableCell>
              </TableRow>
            ))}
            <TableRow className="border-t-2 bg-secondary/40 font-bold hover:bg-secondary/40">
              <TableCell className="text-sm">TOTAL</TableCell>
              <TableCell className="text-right tabular-nums">{fmtWon(sum.meta)}</TableCell>
              <TableCell className="text-right tabular-nums">{fmtWon(sum.rppKrw)}</TableCell>
              <TableCell className="text-right tabular-nums">{fmtWon(sum.total)}</TableCell>
              <TableCell className="text-right tabular-nums">{fmtWon(sum.salesKrw)}</TableCell>
              <TableCell className="text-right tabular-nums">
                {sum.total > 0 ? (sum.salesKrw / sum.total).toFixed(2) : "0.00"}x
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

function MonthlyCard({
  monthly, monthlyAds,
}: {
  monthly: Awaited<ReturnType<typeof fetchMonthlySpend>>;
  monthlyAds: Awaited<ReturnType<typeof fetchMonthlyAdSpend>>;
}) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-baseline justify-between gap-2">
          <CardTitle className="text-base">월별 사용액</CardTitle>
          <span className="text-sm font-bold tabular-nums">TOTAL {fmtWon(monthly.total)}</span>
        </div>
        <p className="text-xs text-muted-foreground">월 누르면 광고별 내역</p>
      </CardHeader>
      <CardContent className="space-y-1.5">
        {monthly.rows.map((m) => {
          const ads = monthlyAds.get(m.month) ?? [];
          return (
            <details
              key={m.month}
              className="group rounded-xl border border-border/60 bg-secondary/30 open:bg-secondary/50"
              open={m.inProgress}
            >
              <summary className="flex cursor-pointer list-none items-center gap-2 px-3 py-2.5 [&::-webkit-details-marker]:hidden">
                <ChevronDown className="h-4 w-4 shrink-0 text-muted-foreground transition-transform group-open:rotate-180" />
                <span className="text-sm font-semibold">
                  {m.month}
                  {m.inProgress && (
                    <span className="ml-1.5 text-[10px] font-semibold text-muted-foreground">진행 중</span>
                  )}
                </span>
                <span className="text-[11px] text-muted-foreground">광고 {ads.length}개</span>
                <span className="ml-auto text-sm font-bold tabular-nums">{fmtWon(m.spend)}</span>
              </summary>
              <div className="overflow-x-auto border-t border-border/60">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>광고</TableHead>
                      <TableHead className="hidden md:table-cell">캠페인</TableHead>
                      <TableHead className="text-right">사용액</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {ads.map((a, i) => (
                      <TableRow key={`${a.ad_name}-${i}`}>
                        <TableCell className="max-w-[180px] md:max-w-[340px]">
                          <div className="truncate text-sm">{a.ad_name}</div>
                          <div className="truncate text-[11px] text-muted-foreground md:hidden">{a.campaign_name}</div>
                        </TableCell>
                        <TableCell className="hidden max-w-[200px] md:table-cell">
                          <div className="truncate text-xs text-muted-foreground">{a.campaign_name}</div>
                        </TableCell>
                        <TableCell className="text-right tabular-nums text-sm">{fmtWon(a.spend)}</TableCell>
                      </TableRow>
                    ))}
                    <TableRow className="border-t-2 bg-secondary/40 font-bold hover:bg-secondary/40">
                      <TableCell className="text-sm">월 합계</TableCell>
                      <TableCell className="hidden md:table-cell" />
                      <TableCell className="text-right tabular-nums">{fmtWon(m.spend)}</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </details>
          );
        })}
      </CardContent>
    </Card>
  );
}

interface Grouped {
  key: string;
  name: string;
  spend: number;
  impr: number;
  clicks: number;
  lpv: number;
  ctr: number;
  cplpv: number;
}

function groupBy(ads: AdRow[], view: "campaign" | "adset" | "ad"): Grouped[] {
  const map = new Map<string, Grouped>();
  for (const a of ads) {
    const key =
      view === "campaign" ? a.campaign_name :
      view === "adset" ? a.adset_name : a.ad_name;
    const id = key || "(unnamed)";
    const cur = map.get(id) ?? {
      key: id, name: id, spend: 0, impr: 0, clicks: 0, lpv: 0, ctr: 0, cplpv: 0,
    };
    cur.spend += a.spend;
    cur.impr += a.impressions;
    cur.clicks += a.clicks;
    cur.lpv += a.lpv;
    map.set(id, cur);
  }
  const out = Array.from(map.values()).map((g) => ({
    ...g,
    ctr: g.impr > 0 ? (g.clicks / g.impr) * 100 : 0,
    cplpv: g.lpv > 0 ? g.spend / g.lpv : 0,
  }));
  return out.sort((a, b) => b.spend - a.spend);
}
