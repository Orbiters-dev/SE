"use client";

// 세로 = 페이지 기본 스크롤(우측 네이티브 바).
// 가로 = 화면 하단에 고정(sticky bottom-0)된 두꺼운 가로바(.hbar) — 본문과 scrollLeft 동기화.
// 본문 자체의 네이티브 가로바는 숨김(.no-native-sb) → 하단 고정 바 하나만 보임.
// → 어느 행(순위)을 보고 있든 하단 가로바로 항상 좌우 이동 가능. 드래그도 됨.

import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

export function ScrollableTable({ children }: { children: React.ReactNode; className?: string }) {
  const barRef = useRef<HTMLDivElement>(null);
  const bodyRef = useRef<HTMLDivElement>(null);
  const [width, setWidth] = useState(0);
  const [overflow, setOverflow] = useState(false);
  const syncing = useRef(false);

  // 본문 scrollWidth 측정 → 하단 바 더미 폭 동기화 + 가로 오버플로 여부
  useEffect(() => {
    const body = bodyRef.current;
    if (!body) return;
    const measure = () => {
      setWidth(body.scrollWidth);
      setOverflow(body.scrollWidth - body.clientWidth > 2);
    };
    measure();
    const raf = requestAnimationFrame(measure);
    const t = setTimeout(measure, 400);
    const ro = new ResizeObserver(measure);
    ro.observe(body);
    if (body.firstElementChild) ro.observe(body.firstElementChild);
    window.addEventListener("resize", measure);
    return () => {
      cancelAnimationFrame(raf); clearTimeout(t);
      ro.disconnect(); window.removeEventListener("resize", measure);
    };
  }, []);

  // 본문 드래그 → 가로 스크롤 (링크/버튼/펼침 클릭은 무시)
  useEffect(() => {
    const el = bodyRef.current;
    if (!el) return;
    let down = false, sx = 0, sl = 0, dragged = false;
    const onDown = (e: MouseEvent) => {
      if ((e.target as HTMLElement).closest("a, button, summary")) return;
      down = true; dragged = false; sx = e.pageX; sl = el.scrollLeft;
      el.classList.add("cursor-grabbing");
    };
    const onUp = () => { down = false; el.classList.remove("cursor-grabbing"); };
    const onMove = (e: MouseEvent) => {
      if (!down) return;
      const dx = e.pageX - sx;
      if (Math.abs(dx) > 5) dragged = true;
      el.scrollLeft = sl - dx;
    };
    const onClick = (e: MouseEvent) => { if (dragged) { e.preventDefault(); e.stopPropagation(); } };
    el.addEventListener("mousedown", onDown);
    window.addEventListener("mouseup", onUp);
    el.addEventListener("mousemove", onMove);
    el.addEventListener("mouseleave", onUp);
    el.addEventListener("click", onClick, true);
    return () => {
      el.removeEventListener("mousedown", onDown);
      window.removeEventListener("mouseup", onUp);
      el.removeEventListener("mousemove", onMove);
      el.removeEventListener("mouseleave", onUp);
      el.removeEventListener("click", onClick, true);
    };
  }, []);

  const sync = (from: HTMLDivElement | null, to: HTMLDivElement | null) => {
    if (!from || !to || syncing.current) return;
    syncing.current = true;
    to.scrollLeft = from.scrollLeft;
    requestAnimationFrame(() => { syncing.current = false; });
  };

  return (
    <div className="relative">
      {/* 본문: 가로만 스크롤(네이티브 바 숨김). 세로는 페이지가 처리 → 표 전체 높이 노출 */}
      <div
        ref={bodyRef}
        onScroll={() => sync(bodyRef.current, barRef.current)}
        className="no-native-sb cursor-grab select-none overflow-x-auto overflow-y-hidden"
      >
        {children}
      </div>
      {/* 화면 하단 고정 가로 스크롤바 — 두껍게 항상 보임(.hbar). 어느 행에 있든 노출·조작 가능 */}
      <div
        ref={barRef}
        onScroll={() => sync(barRef.current, bodyRef.current)}
        className={cn(
          "hbar sticky bottom-0 z-30 h-[18px] overflow-x-scroll overflow-y-hidden rounded-md border border-border bg-card/95 shadow-[0_-2px_10px_rgba(0,0,0,0.10)] backdrop-blur",
          overflow ? "block" : "hidden",
        )}
      >
        <div style={{ width, height: 1 }} />
      </div>
    </div>
  );
}
