import Link from "next/link";
import { ArrowLeft, ExternalLink } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { EnvWarning } from "@/components/meta/EnvWarning";
import { Monkey } from "@/components/meta/Monkey";
import { AdDailyCharts, type DailyPoint } from "@/components/meta/AdDailyCharts";
import { GradeChip, GradeBadge } from "@/components/meta/GradeChip";
import { buildAdGradeMap } from "@/lib/ad-grade";
import { fetchAdInfo, fetchAdDaily, fetchAdCreatives } from "@/lib/dk-meta";   // DK 단일소스
import { extractLpv } from "@/lib/meta-api";
import { toFloat, fmtWon, fmtPct, fmtNum, isoDate } from "@/lib/format";
import { FREQ_HIGH } from "@/lib/meta-constants";

export const revalidate = 60;

export default async function AdDetailPage({
  params,
}: {
  params: Promise<{ adId: string }>;
}) {
  const { adId } = await params;
  let body: React.ReactNode;
  try {
    const info = await fetchAdInfo(adId);
    const createdDate = info?.created_time?.slice(0, 10) ?? "2024-01-01";
    const today = isoDate(new Date());
    const [rows, permaMap, gradeMap] = await Promise.all([
      fetchAdDaily(adId, createdDate, today),
      fetchAdCreatives([adId]),
      buildAdGradeMap(),
    ]);
    const gradeTag = gradeMap.get(adId);

    const perDay = rows
      .map((r) => {
        const spend = toFloat(r.spend);
        const impr = toFloat(r.impressions);
        const clicks = toFloat(r.clicks);
        const lpv = extractLpv(r.actions);
        return {
          date: r.date_start ?? "",
          spend,
          lpv,
          clicks,
          ctr: impr > 0 ? (clicks / impr) * 100 : 0,
          cplpv: lpv > 0 ? spend / lpv : 0,
          frequency: toFloat(r.frequency),
          impressions: impr,
        };
      })
      .filter((d) => d.date)
      .sort((a, b) => a.date.localeCompare(b.date));

    // 누적(적분) — 등록일부터 그날까지 running total. LPV=합, CTR/CPLPV=누적 재계산.
    let cumSpend = 0, cumLpvAcc = 0, cumImpr = 0, cumClicks = 0;
    const daily: DailyPoint[] = perDay.map((d) => {
      cumSpend += d.spend;
      cumLpvAcc += d.lpv;
      cumImpr += d.impressions;
      cumClicks += d.clicks;
      return {
        ...d,
        cumLpv: cumLpvAcc,
        cumCtr: cumImpr > 0 ? (cumClicks / cumImpr) * 100 : 0,
        cumCplpv: cumLpvAcc > 0 ? cumSpend / cumLpvAcc : 0,
      };
    });

    const totSpend = daily.reduce((s, d) => s + d.spend, 0);
    const totLpv = daily.reduce((s, d) => s + d.lpv, 0);
    const totImpr = daily.reduce((s, d) => s + d.impressions, 0);
    const totClicks = rows.reduce((s, r) => s + toFloat(r.clicks), 0);
    const avgCtr = totImpr > 0 ? (totClicks / totImpr) * 100 : 0;
    const avgCplpv = totLpv > 0 ? totSpend / totLpv : 0;
    const lastFreq = daily.length > 0 ? daily[daily.length - 1].frequency : 0;
    const activeDays = daily.filter((d) => d.spend > 0).length;
    const permalink = permaMap.get(adId);
    const status = info?.effective_status ?? "";
    const statusActive = status === "ACTIVE";

    body = (
      <>
        <section className="space-y-2">
          <Link
            href="/ads"
            className="inline-flex items-center gap-1 text-xs font-semibold text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="h-3.5 w-3.5" /> 광고 목록
          </Link>
          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-base font-bold tracking-tight sm:text-lg">
              {info?.name ?? adId}
            </h1>
            {status && (
              <Badge variant={statusActive ? "default" : "secondary"} className="text-[10px]">
                {statusActive ? "ACTIVE" : status}
              </Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground">
            {info?.campaign?.name ?? "—"} · {info?.adset?.name ?? "—"}
          </p>
          {gradeTag && (
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <GradeChip grade={gradeTag.wlGrade} size={28} />
              <span className="text-[11px] text-muted-foreground">WL 등급</span>
              {gradeTag.organicGrade !== "NA" && (
                <span className="inline-flex items-center gap-1 text-[11px] text-muted-foreground">
                  · Organic <GradeBadge grade={gradeTag.organicGrade} />
                </span>
              )}
              <Link
                href={`/influencers/${encodeURIComponent(gradeTag.igHandle)}`}
                className="text-[11px] font-semibold text-primary hover:opacity-80"
              >
                @{gradeTag.igHandle} 콘텐츠 상세 →
              </Link>
            </div>
          )}
          <p className="text-xs text-muted-foreground">
            등록 {createdDate} · 집행 {activeDays}일
            {permalink && (
              <>
                {" · "}
                <a
                  href={permalink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-0.5 font-semibold text-primary hover:opacity-80"
                >
                  게시물 보기 <ExternalLink className="h-3 w-3" />
                </a>
              </>
            )}
          </p>
        </section>

        {daily.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center gap-2 py-10 text-muted-foreground">
              <Monkey mood="dizzy" size={64} />
              <span className="text-sm">등록 이후 delivery 데이터 없음</span>
            </CardContent>
          </Card>
        ) : (
          <>
            <p className="text-[11px] font-semibold text-muted-foreground">
              누적 성과 — 등록일({createdDate})부터 전체 기간 · 광고 목록의 수치는 최근 7일 기준
            </p>
            <section className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-6 sm:gap-3">
              <Stat label="총 Spend" value={fmtWon(totSpend)} />
              <Stat label="총 LPV" value={fmtNum(totLpv)} />
              <Stat label="총 노출" value={fmtNum(totImpr)} />
              <Stat label="평균 CTR" value={fmtPct(avgCtr)} />
              <Stat label="평균 CPLPV" value={fmtWon(avgCplpv)} />
              <Stat
                label="최근 Freq"
                value={lastFreq.toFixed(2)}
                warn={lastFreq >= FREQ_HIGH}
              />
            </section>

            <AdDailyCharts data={daily} />
          </>
        )}
      </>
    );
  } catch (e) {
    body = <EnvWarning error={e instanceof Error ? e.message : String(e)} />;
  }
  return <div className="space-y-5">{body}</div>;
}

function Stat({ label, value, warn }: { label: string; value: string; warn?: boolean }) {
  return (
    <Card className="border-border/60 bg-card/80">
      <CardContent className="p-3">
        <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className={`mt-1 text-sm font-bold tabular-nums sm:text-base ${warn ? "text-[var(--bad-fg)]" : ""}`}>
          {value}
        </div>
      </CardContent>
    </Card>
  );
}
