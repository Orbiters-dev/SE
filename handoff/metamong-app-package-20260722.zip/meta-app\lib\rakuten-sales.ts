// SERVER-ONLY. Rakuten 일별 총매출 (SE tools/collect_rakuten_sales_daily.py 가 매일 수집).
// 소스: RMS Order API searchOrder→getOrder, priceTaxIncl×units 합산 (취소확정 제외, 주문일 기준).
// Total ROAS = 이 매출 ÷ (Meta spend + RPP spend). 시드: lib/rakuten-sales-seed.json.

import "server-only";
import seed from "./rakuten-sales-seed.json";

interface SalesDay {
  sales_jpy: number;
  orders: number;
  units: number;
}

interface SalesSeed {
  updated_at: string | null;
  days: Record<string, SalesDay>;
}

const store = seed as unknown as SalesSeed;

export interface SalesMonthlyRow {
  month: string;
  salesJpy: number;
  orders: number;
}

export function salesUpdatedAt(): string | null {
  return store.updated_at;
}

// 월별 매출 (최신 월 위로)
export function salesMonthly(): SalesMonthlyRow[] {
  const byMonth = new Map<string, SalesMonthlyRow>();
  for (const [day, rec] of Object.entries(store.days)) {
    const month = day.slice(0, 7);
    const cur = byMonth.get(month) ?? { month, salesJpy: 0, orders: 0 };
    cur.salesJpy += rec.sales_jpy;
    cur.orders += rec.orders;
    byMonth.set(month, cur);
  }
  return [...byMonth.values()].sort((a, b) => b.month.localeCompare(a.month));
}

export interface SalesRangeSummary {
  salesJpy: number;
  orders: number;
  units: number;
}

// 기간 합산 (since/until ISO date, inclusive)
export function salesRange(since: string, until: string): SalesRangeSummary {
  const out: SalesRangeSummary = { salesJpy: 0, orders: 0, units: 0 };
  for (const [day, rec] of Object.entries(store.days)) {
    if (day < since || day > until) continue;
    out.salesJpy += rec.sales_jpy;
    out.orders += rec.orders;
    out.units += rec.units;
  }
  return out;
}
