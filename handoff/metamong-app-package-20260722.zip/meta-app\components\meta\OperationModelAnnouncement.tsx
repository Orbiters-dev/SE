"use client";

// WL 광고 운영 체제 정리 (2026-06-19 · 메타몽).
// 오늘 반영 완료: 3캠페인 체제 확정 / 명명규칙 전면 적용 / Testing 졸업 2건 / 운영 역할분담.
// + 앞으로의 운영 흐름(신규→Testing 1:1→D+3 게이트→Proven 졸업/OFF).
// 숫자는 6/19 라이브 재조회 실측 (일예산 ₩203,000).
// 노출 ~6/26 00:00 KST → 이후 자동 미표시. X 닫기 = 같은 탭 세션 동안 미표시 (sessionStorage).
// 표시 게이트(시간·dismiss)는 AnnouncementStack이 관리 — 여기는 표시 전용.
// 금액 KRW 통일 · 줄글 X 카드/칩 (메타몽 팝업 룰).

import type { ReactNode } from "react";
import { X } from "lucide-react";
import { Monkey } from "@/components/meta/Monkey";
import { cn } from "@/lib/utils";

export const OPERATION_MODEL_SHOW_UNTIL_UTC = Date.UTC(2026, 5, 25, 15, 0, 0); // 2026-06-26 00:00 KST
export const OPERATION_MODEL_DISMISS_KEY = "operation_model_20260619_dismissed";

interface Chip {
  label: string;
  value: string;
  tone: "bad" | "good" | "flat";
}

interface Card {
  tag: string;
  tone: "done" | "decision" | "info";
  title: string;
  chips?: Chip[];
  bullets?: ReactNode[];
}

const CARDS: Card[] = [
  {
    tag: "확정",
    tone: "decision",
    title: "🗂️ 3캠페인 체제로 정리",
    chips: [
      { label: "Stainless Proven", value: "소재 8", tone: "flat" },
      { label: "PPSU Proven", value: "소재 3", tone: "flat" },
      { label: "Testing 1:1", value: "5 ad set", tone: "flat" },
    ],
    bullets: [
      <>
        <b>Proven</b> = SKU별 1 ad set 통합 (여러 소재 한 묶음, Meta가 예산 자동분배)
      </>,
      <>
        <b>Testing</b> = 소재 1개 = ad set 1개 (1:1 분리, 각 ₩8,000 균등 비교)
      </>,
    ],
  },
  {
    tag: "완료",
    tone: "done",
    title: "🏷️ 광고 이름 규칙 전면 통일",
    bullets: [
      <>
        형식 <b>YYMMDD_Grosmimi_RKT_WL-G/P_핸들_ASIN_CT콘텐츠코드</b>
      </>,
      <>
        WL-G=무상/기프트 · WL-P=유상 · RKT=라쿠텐 채널
      </>,
      <>
        ON 광고 전부 새 규칙으로 rename (OFF 광고는 미터치)
      </>,
    ],
  },
  {
    tag: "완료",
    tone: "done",
    title: "🎓 Testing 졸업 2건 → Stainless Proven",
    chips: [
      { label: "arara", value: "졸업", tone: "good" },
      { label: "kyan", value: "졸업", tone: "good" },
    ],
    bullets: [
      <>
        Stainless Proven 통합 ad set이 <b>6 → 8 소재</b>로 (검토 통과분 편입)
      </>,
    ],
  },
  {
    tag: "역할",
    tone: "info",
    title: "🛠️ 운영 역할분담",
    bullets: [
      <>
        <b>세은</b> — on/off · 예산 · Proven 승급 (실제 딸깍 = 판단·실행)
      </>,
      <>
        <b>메타몽</b> — 캠페인/ad set 생성·수정·rename·세팅 전부 (현행 그대로 맞춤)
      </>,
    ],
  },
  {
    tag: "흐름",
    tone: "decision",
    title: "🔄 앞으로의 운영 흐름",
    bullets: [
      <>
        ① 신규 인플루언서 소재(WL 승인+게시물) → <b>Testing 진입</b> (1:1 · ₩8,000)
      </>,
      <>
        ② <b>D+3 판정</b> — CPLPV · VTR 게이트
      </>,
      <>
        ③ 통과 → <b>Proven 졸업</b>(제품별 통합 편입) / 미달 → <b>OFF</b>
      </>,
    ],
  },
  {
    tag: "계획",
    tone: "decision",
    title: "📈 예산 증액 계획",
    chips: [
      { label: "Stainless Proven", value: "₩123K → ₩160K", tone: "good" },
      { label: "전체 목표", value: "→ ₩300,000", tone: "good" },
    ],
    bullets: [
      <>
        Stainless Proven은 <b>20%씩 점진 증액</b> → 최종 <b>₩160,000</b> (learning reset 회피)
      </>,
      <>
        괜찮은 소재 나오면 <b>Testing 계속 추가</b> → 일예산 <b>총 ₩300,000</b> 규모로
      </>,
    ],
  },
];

// 히어로: 일예산 현재 ₩203,000 → 목표 ₩300,000 (6/19 라이브 실측)
const HERO = {
  total: "₩203,000",
  sub: "현재 일예산 · 목표 → ₩300,000",
  lanes: [
    { label: "Stainless Proven", value: "₩123K" },
    { label: "PPSU Proven", value: "₩40K" },
    { label: "Testing ×5", value: "₩8K씩" },
  ],
};

export function OperationModelAnnouncement({ onClose }: { onClose: () => void }) {
  const dismiss = () => {
    sessionStorage.setItem(OPERATION_MODEL_DISMISS_KEY, "1");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={dismiss} />
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-border bg-background shadow-2xl">
        <button
          onClick={dismiss}
          aria-label="닫기"
          className="absolute right-3 top-3 rounded-full p-1.5 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
        >
          <X className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-3 border-b border-border/60 bg-secondary/40 px-5 py-4">
          <Monkey mood="teacher" size={48} />
          <div>
            <div className="text-base font-bold tracking-tight">WL 광고 운영 체제 정리</div>
            <div className="text-xs text-muted-foreground">2026-06-19 · 메타몽 · 오늘 반영 완료</div>
          </div>
        </div>

        <div className="max-h-[64vh] space-y-3 overflow-y-auto px-5 py-4">
          {/* 히어로: 일예산 구조 */}
          <div className="rounded-xl border border-border/60 bg-secondary/30 px-4 py-3">
            <div className="mb-2 text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
              일예산 구조
            </div>
            <div className="mb-2 text-center text-3xl font-extrabold tracking-tight text-foreground">
              {HERO.total}
            </div>
            <div className="flex items-stretch gap-2">
              {HERO.lanes.map((lane, i) => (
                <div key={i} className="flex-1 rounded-lg bg-secondary/60 px-2 py-2 text-center">
                  <div className="text-sm font-bold text-foreground">{lane.value}</div>
                  <div className="mt-0.5 text-[10px] leading-tight text-muted-foreground">
                    {lane.label}
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-2 text-center text-[12px] text-foreground/70">{HERO.sub}</div>
          </div>

          {CARDS.map((c, ci) => (
            <div key={ci} className="rounded-xl border border-border/60 bg-secondary/30 px-4 py-3">
              <span
                className={cn(
                  "mb-2 inline-block rounded-md px-2 py-0.5 text-[11px] font-bold",
                  c.tone === "decision" && "bg-emerald-100 text-emerald-700",
                  c.tone === "done" && "bg-primary/15 text-primary",
                  c.tone === "info" && "bg-secondary text-muted-foreground",
                )}
              >
                {c.tag}
              </span>
              <div className="mb-1.5 text-sm font-bold">{c.title}</div>
              {c.chips && (
                <div className="mb-2 flex flex-wrap gap-1.5">
                  {c.chips.map((chip, i) => (
                    <span
                      key={i}
                      className={cn(
                        "inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[12px] font-semibold",
                        chip.tone === "bad" && "bg-rose-100 text-rose-700",
                        chip.tone === "good" && "bg-emerald-100 text-emerald-700",
                        chip.tone === "flat" && "bg-secondary text-foreground/70",
                      )}
                    >
                      <span className="text-[10px] font-medium opacity-70">{chip.label}</span>
                      {chip.value}
                    </span>
                  ))}
                </div>
              )}
              {c.bullets && (
                <ul className="list-disc space-y-1 pl-4">
                  {c.bullets.map((b, i) => (
                    <li key={i} className="text-[13px] leading-relaxed text-foreground/80">
                      {b}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
