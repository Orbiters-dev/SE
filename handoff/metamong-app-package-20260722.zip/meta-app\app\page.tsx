import { KpiCard } from "@/components/meta/KpiCard";
import { EnvWarning } from "@/components/meta/EnvWarning";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  fetchAccountSummary,
  fetchSupersaleCompare,
} from "@/lib/meta-aggregations";
import { rppRange, fetchJpyKrw } from "@/lib/rpp";
import { salesRange } from "@/lib/rakuten-sales";
import { fmtWon, fmtPct, fmtNum, isoDate, daysAgo, deltaPct } from "@/lib/format";

export const revalidate = 60;

export default async function HomePage() {
  let body: React.ReactNode;
  try {
    const today = new Date();
    const yesterday = daysAgo(1, today);
    const dBefore = daysAgo(2, today);
    const w1Until = yesterday;
    const w1Since = daysAgo(7, today);
    const w2Until = daysAgo(8, today);
    const w2Since = daysAgo(14, today);

    const [yest, prev, w1, w2, sale, fx] = await Promise.all([
      fetchAccountSummary(isoDate(yesterday), isoDate(yesterday)),
      fetchAccountSummary(isoDate(dBefore), isoDate(dBefore)),
      fetchAccountSummary(isoDate(w1Since), isoDate(w1Until)),
      fetchAccountSummary(isoDate(w2Since), isoDate(w2Until)),
      fetchSupersaleCompare(today).catch(() => null),
      fetchJpyKrw(),
    ]);
    // RPP (라쿠텐) — 일별 시드 기간 합산, ¥→₩ 환산
    const rppYest = rppRange(isoDate(yesterday), isoDate(yesterday)).spendJpy * fx.rate;
    const rppPrev = rppRange(isoDate(dBefore), isoDate(dBefore)).spendJpy * fx.rate;
    const rppW1 = rppRange(isoDate(w1Since), isoDate(w1Until)).spendJpy * fx.rate;
    const rppW2 = rppRange(isoDate(w2Since), isoDate(w2Until)).spendJpy * fx.rate;
    // Total ROAS = 라쿠텐 매출 ÷ (Meta + RPP)
    const troasOf = (salesJpy: number, meta: number, rpp: number) =>
      meta + rpp > 0 ? (salesJpy * fx.rate) / (meta + rpp) : 0;
    const troasYest = troasOf(salesRange(isoDate(yesterday), isoDate(yesterday)).salesJpy, yest.spend, rppYest);
    const troasPrev = troasOf(salesRange(isoDate(dBefore), isoDate(dBefore)).salesJpy, prev.spend, rppPrev);
    const troasW1 = troasOf(salesRange(isoDate(w1Since), isoDate(w1Until)).salesJpy, w1.spend, rppW1);
    const troasW2 = troasOf(salesRange(isoDate(w2Since), isoDate(w2Until)).salesJpy, w2.spend, rppW2);

    body = (
      <>
        <section>
          <div className="mb-3 flex items-baseline justify-between">
            <h1 className="text-lg font-semibold tracking-tight">어제 ({isoDate(yesterday)})</h1>
            <span className="text-xs text-muted-foreground">vs 그저께</span>
          </div>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
            <KpiCard label="Spend" value={fmtWon(yest.spend)} deltaPct={deltaPct(yest.spend, prev.spend)} />
            <KpiCard label="RPP" value={fmtWon(rppYest)} deltaPct={deltaPct(rppYest, rppPrev)} />
            <KpiCard label="총 광고비" value={fmtWon(yest.spend + rppYest)} deltaPct={deltaPct(yest.spend + rppYest, prev.spend + rppPrev)} />
            <KpiCard label="Total ROAS" value={`${troasYest.toFixed(2)}x`} deltaPct={deltaPct(troasYest, troasPrev)} />
            <KpiCard label="CTR" value={fmtPct(yest.ctr)} deltaPct={deltaPct(yest.ctr, prev.ctr)} />
            <KpiCard label="CPC" value={fmtWon(yest.cpc)} deltaPct={deltaPct(yest.cpc, prev.cpc)} invertColor />
            <KpiCard label="CPLPV" value={fmtWon(yest.cplpv)} deltaPct={deltaPct(yest.cplpv, prev.cplpv)} invertColor />
            <KpiCard label="Freq" value={yest.frequency.toFixed(2)} deltaPct={deltaPct(yest.frequency, prev.frequency)} invertColor />
            <KpiCard label="LPV" value={fmtNum(yest.lpv)} deltaPct={deltaPct(yest.lpv, prev.lpv)} />
          </div>
        </section>

        <section>
          <div className="mb-3 flex items-baseline justify-between">
            <h2 className="text-lg font-semibold tracking-tight">최근 7일 (W-1)</h2>
            <span className="text-xs text-muted-foreground">
              {isoDate(w1Since)} ~ {isoDate(w1Until)} vs W-2
            </span>
          </div>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
            <KpiCard label="Spend" value={fmtWon(w1.spend)} deltaPct={deltaPct(w1.spend, w2.spend)} />
            <KpiCard label="RPP" value={fmtWon(rppW1)} deltaPct={deltaPct(rppW1, rppW2)} />
            <KpiCard label="총 광고비" value={fmtWon(w1.spend + rppW1)} deltaPct={deltaPct(w1.spend + rppW1, w2.spend + rppW2)} />
            <KpiCard label="Total ROAS" value={`${troasW1.toFixed(2)}x`} deltaPct={deltaPct(troasW1, troasW2)} />
            <KpiCard label="CTR" value={fmtPct(w1.ctr)} deltaPct={deltaPct(w1.ctr, w2.ctr)} />
            <KpiCard label="CPC" value={fmtWon(w1.cpc)} deltaPct={deltaPct(w1.cpc, w2.cpc)} invertColor />
            <KpiCard label="CPLPV" value={fmtWon(w1.cplpv)} deltaPct={deltaPct(w1.cplpv, w2.cplpv)} invertColor />
            <KpiCard label="Freq" value={w1.frequency.toFixed(2)} deltaPct={deltaPct(w1.frequency, w2.frequency)} invertColor />
            <KpiCard label="LPV" value={fmtNum(w1.lpv)} deltaPct={deltaPct(w1.lpv, w2.lpv)} />
          </div>
        </section>

        {sale && sale.active && (
          <section>
            <Card>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-base">슈퍼세일 증액 모니터링</CardTitle>
                  <Badge variant="secondary">진행 중</Badge>
                </div>
                <p className="text-xs text-muted-foreground">
                  {sale.after_window} vs {sale.before_window}
                </p>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <Row label="Spend" delta={sale.delta.spend} after={fmtWon(sale.after.spend)} />
                <Row label="LPV" delta={sale.delta.lpv} after={fmtNum(sale.after.lpv)} />
                <Row label="CPLPV" delta={sale.delta.cplpv} after={fmtWon(sale.after.cplpv)} invert />
                <Row label="CTR" delta={sale.delta.ctr} after={fmtPct(sale.after.ctr)} />
                <Row label="Freq" delta={sale.delta.frequency} after={sale.after.frequency.toFixed(2)} invert />
                <Row label="Reach" delta={sale.delta.reach} after={fmtNum(sale.after.reach)} />
              </CardContent>
            </Card>
          </section>
        )}
      </>
    );
  } catch (e) {
    body = <EnvWarning error={e instanceof Error ? e.message : String(e)} />;
  }

  return <div className="space-y-6">{body}</div>;
}

function Row({ label, delta, after, invert }: { label: string; delta: number; after: string; invert?: boolean }) {
  const positive = delta > 0;
  const good = invert ? !positive : positive;
  const tone = Math.abs(delta) < 0.1 ? "neutral" : good ? "good" : "bad";
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="flex items-center gap-2 tabular-nums">
        <span className="font-semibold text-foreground">{after}</span>
        <span
          className={
            tone === "good"
              ? "rounded-full bg-[var(--good-bg)] px-2 py-0.5 text-[11px] font-semibold text-[var(--good-fg)]"
              : tone === "bad"
                ? "rounded-full bg-[var(--bad-bg)] px-2 py-0.5 text-[11px] font-semibold text-[var(--bad-fg)]"
                : "rounded-full bg-muted px-2 py-0.5 text-[11px] text-muted-foreground"
          }
        >
          {delta > 0 ? "▲" : delta < 0 ? "▼" : "▬"} {Math.abs(delta).toFixed(1)}%
        </span>
      </span>
    </div>
  );
}
