"""
Codex Evaluator — Cross-AI Harness Evaluator (Claude=Generator, Codex=Evaluator).

Supports 3 domain-specific audit modes:
  - general: Code quality, security, logic errors
  - cfo: Financial model verification, AICPA/KICPA 6-point checklist (CFO harness)
  - pipeline: E2E pipeline dual-test verification, Maker-Checker cross-system

Usage:
    # General code audit
    python tools/codex_evaluator.py audit --files tools/data_keeper.py

    # CFO financial audit (Generator output verification)
    python tools/codex_evaluator.py --domain cfo audit --files .tmp/cfo_sessions/generator_output.json

    # E2E pipeline audit (dual test results verification)
    python tools/codex_evaluator.py --domain pipeline audit --files .tmp/dual_test/run_latest/merged_report.html

    # Sprint contract verification
    python tools/codex_evaluator.py verify --contract .tmp/sprint_contract.md

    # Domain-specific question
    python tools/codex_evaluator.py --domain cfo ask "Q1 Gross Margin came in at 85% — is this normal?"

    # JSON output (for pipelines)
    python tools/codex_evaluator.py --domain pipeline audit --files report.json --json

Env:
    OPENAI_API_KEY  — OpenAI API key (from .env)
"""

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

# Load .env
ENV_PATH = Path(__file__).resolve().parent.parent / ".env"
if ENV_PATH.exists():
    for line in ENV_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, v = line.split("=", 1)
            v = v.strip().strip('"').strip("'")
            if k.strip() not in os.environ:
                os.environ[k.strip()] = v

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
REPO_ROOT = Path(__file__).resolve().parent.parent
TMP_DIR = REPO_ROOT / ".tmp" / "codex_evaluator"
TMP_DIR.mkdir(parents=True, exist_ok=True)

# ─── LightRAG Integration ────────────────────────────────────────
# Namespace tag biases retrieval toward past Codex (structural) audits,
# so numeric-only Gemini audits do not contaminate Codex context
# (prevents cross-evaluator false-positive reinforcement).

LIGHTRAG_URL = os.environ.get("LIGHTRAG_URL", "http://localhost:9621")
RAG_NAMESPACE_TAG = "codex-structural-policy"


def _rag_healthy() -> bool:
    """Check if LightRAG server is reachable."""
    try:
        import urllib.request
        req = urllib.request.Request(f"{LIGHTRAG_URL}/health", method="GET")
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return data.get("status") == "healthy"
    except Exception:
        return False


def _rag_query(text: str, mode: str = "hybrid", top_k: int = 5) -> str:
    """Query LightRAG for related structural/policy context. Empty on failure."""
    try:
        import urllib.request
        # Bias retrieval toward Codex's own past audits + structural notes
        biased = f"[{RAG_NAMESPACE_TAG} / structural policy security functionality error-handling] {text}"
        payload = json.dumps({"query": biased, "mode": mode, "top_k": top_k,
                              "only_need_context": True}).encode("utf-8")
        req = urllib.request.Request(f"{LIGHTRAG_URL}/query", data=payload, method="POST",
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            if isinstance(data, str):
                return data
            if isinstance(data, dict):
                return data.get("response", data.get("result", ""))
            return str(data)
    except Exception:
        return ""


def _rag_index_result(result: dict, domain: str, ts: str):
    """Index Codex audit result into LightRAG (fire-and-forget).

    Namespaced header ensures Gemini retrieval won't preferentially surface
    Codex's verdicts (prevents evaluator self-reinforcement loop).
    """
    if not _rag_healthy():
        return
    try:
        import urllib.request
        content = result.get("content", "")
        if not content or len(content) < 50:
            return
        # Namespace tag in header biases future Codex-side retrieval
        doc = (f"# Codex Structural Audit [{domain.upper()}] [{RAG_NAMESPACE_TAG}] — {ts}\n\n"
               f"{content[:3000]}")
        payload = json.dumps({"text": doc}).encode("utf-8")
        req = urllib.request.Request(f"{LIGHTRAG_URL}/documents/text", data=payload, method="POST",
                                     headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=10)
        print(f"[RAG] Indexed Codex audit result ({len(doc)} chars)", file=sys.stderr)
    except Exception as e:
        print(f"[RAG] Index failed (non-blocking): {e}", file=sys.stderr)

# ─── Evaluator system prompts ───────────────────────────────────────

AUDIT_SYSTEM = """You are a skeptical STRUCTURE / POLICY / SECURITY auditor for the codebase.
Your peer auditor (Gemini) handles NUMERIC and FACTUAL verification — do NOT repeat their work.

## YOUR SCOPE (what to evaluate)
1. FUNCTIONALITY (weight: CRITICAL) — Does control flow work? Any broken feature, unreachable code, missing branch = FAIL.
2. ERROR HANDLING & ROBUSTNESS (weight: HIGH) — Error propagation, exception swallowing, resource leaks, retries, timeouts.
3. CODE QUALITY (weight: MEDIUM) — Security (injection, auth, secrets), performance (N+1, unbounded loops), testability.
4. DESIGN & MAINTAINABILITY (weight: LOW) — Naming, modularity, separation of concerns.

## OUT OF YOUR SCOPE (Gemini handles these — do NOT flag)
- Arithmetic correctness, formula validation, sum/total checks
- Cross-reference between docstring claims and actual numbers
- Factual grounding of hardcoded values / dates / thresholds
- Percentage / ratio / unit consistency
- Numeric sanity (KPI ranges, gross-margin bounds, etc.)

If you find a numeric issue, note it as [GEMINI-TERRITORY] and move on — do NOT include it in your FAIL verdict.

## CALIBRATION RULES (avoid false positives)
- Intentional fallback behavior (returning `[]` on missing file) is a DESIGN CHOICE, not a bug, UNLESS the caller cannot distinguish success from failure. Flag only if the ambiguity is real.
- Sampling limits (e.g., "check top 20") are PERFORMANCE TRADE-OFFS, not bugs. Flag only if sampling provably hides known issue classes.
- SKIP-on-missing-file is often the CORRECT behavior when the caller explicitly expects optional inputs. Only flag if the docstring promises "fails on missing."
- If you are unsure whether something is a bug or design choice, mark as WARN, not FAIL.

## OUTPUT
For each file:
- Score per in-scope criterion (0-10)
- PASS/FAIL (FUNCTIONALITY < 8 = FAIL; others WARN unless critical)
- Specific issues with line numbers. Quote the code.
- Overall verdict: PASS | WARN | FAIL

Be specific. Quote code. Give line numbers. No vague praise. No numeric nitpicks."""

VERIFY_SYSTEM = """You are a sprint contract verifier for the codebase.
Given a sprint contract (scope + acceptance criteria), verify whether the
implementation meets every criterion.

For each criterion:
- PASS: fully implemented, tested, working
- FAIL: missing, broken, or incomplete (with specific evidence)
- PARTIAL: implemented but with caveats (list them)

Output a scorecard table and overall verdict."""

# ─── Gate-specific prompt suffixes ────────────────────────────────
# "build" gate = auditing SOURCE CODE (is the code correctly written?)
# "test"  gate = auditing EXECUTION RESULTS (did the tests run properly? are results trustworthy?)

BUILD_GATE_SUFFIX = """

## GATE: BUILD (source code audit)
You are reading SOURCE CODE. Evaluate structural quality of the code itself.
Focus: control flow, error propagation, testability, security. Do NOT imagine what runtime output will look like — that's the TEST gate's job.
"""

TEST_GATE_SUFFIX = """

## GATE: TEST (execution-result audit)
You are reading EXECUTION RESULTS (JSON / HTML report / log output), not source code.
Evaluate whether the test run was valid on the STRUCTURAL axis:
- Did every declared check actually execute? Any silent SKIP = FAIL.
- Is coverage complete across declared dimensions (brands, channels, stages, etc.)?
- Are there signs of false negatives (tests passed but shouldn't have)?
- Are error handlers actually exercised, or did all paths hit happy-path?
Ignore "how pretty is the test code" — you're auditing the RUN, not the source.
"""

# ─── Domain-specific Evaluator prompts ────────────────────────────

CFO_AUDIT_SYSTEM = """You are an independent financial auditor (AICPA/KICPA dual-certified).
You audit the Generator's financial output with ZERO trust.
Do NOT rely on the Generator's explanations — verify every number independently.

## 6-Point Audit Checklist (ALL mandatory):

A. ARITHMETIC — Every subtotal must sum to its parent total.
   Revenue components = Total Revenue. Gross Profit = Revenue - COGS.
   Percentages must match numerator/denominator (±0.1% rounding tolerance).

B. CROSS-TABLE CONSISTENCY — Same metric across multiple tables must match.
   P&L Revenue = Channel Breakdown Total = data-warehouse raw sum.
   Any $1K+ discrepancy = MAJOR. Any $10K+ = CRITICAL.

C. PERIOD CONSISTENCY — All tables must use the same date_from ~ date_to.
   YoY/MoM base period must be correct.

D. SIGN CONVENTIONS — Costs always positive or always negative (consistent).
   Discounts are revenue deductions. Margins must be positive (flag if negative).

E. ACCOUNTING STANDARDS
   - Revenue Recognition: apply your organization's chosen standard (gross vs net of platform fees)
   - COGS: use landed cost (not retail price)
   - Apply any segment-specific price-cutoff dates (e.g. pre- vs post- a price-change event)
   - Operating vs Non-operating: ad spend = operating, FX = non-operating

F. MATERIALITY & SANITY
   Apply your business-specific tolerance bands for gross margin, advertising-efficiency
   metrics (ACOS, MER), and any other domain KPIs. Flag values >2x or <0.5x typical level.

## Severity Classification:
- CRITICAL: Numbers are wrong (arithmetic error, wrong period). MUST fix.
- MAJOR: Significant inconsistency ($10K+ cross-table diff). Should fix.
- MINOR: Small inconsistency (<$1K, rounding). CFO discretion.
- INFO: Benchmark notes, methodology comments. Ignorable.

## Output Format:
```json
{
  "status": "PASS | WARN | FAIL",
  "summary": "One-line verdict",
  "findings": [{"id": "F001", "severity": "CRITICAL", "category": "A-F", "section": "...", "description": "...", "expected": "...", "actual": "...", "correction_needed": "..."}],
  "corrections_required": ["F001"],
  "approved_sections": ["..."]
}
```

Be ruthless with numbers. $1 off in a total is a bug."""

PIPELINER_AUDIT_SYSTEM = """You are an E2E pipeline verification specialist for your organization's automated workflows.
You audit Maker-Checker dual test results for the E2E pipeline.

## Pipeline Architecture (generic):
Multi-stage pipeline (Discovery → Intake → Review → Action → Fulfillment → Completion)
Systems: your CRM, your e-commerce backend, your database, your workflow engine, email

## Verification Criteria (per stage):

### STAGE INTEGRITY (CRITICAL — any failure = FAIL)
- Executor (Maker) action completed: record created/updated in target system
- Verifier (Checker) independently confirmed: downstream state matches expected
- Cross-system consistency: CRM ↔ e-commerce backend ↔ database all agree
- Signal file written with correct stage metadata

### DATA FLOW (HIGH)
- Record IDs propagate correctly across systems
- Email addresses match across all systems (no typo propagation)
- Status transitions are valid (no skipped stages)
- Timestamps are monotonically increasing per pipeline run

### WEBHOOK/WORKFLOW HEALTH (MEDIUM)
- Workflows are active and responding
- Webhook response times < 15s (WARN if > 30s)
- No task-runner/worker-offline errors
- Poll-based workflows are on schedule

### NEGATIVE TESTS (HIGH)
- Records that should NOT exist don't exist (neg checks)
- Duplicate submissions are rejected or idempotent
- Invalid data is caught at entry (form validation)

### CLEANUP (LOW)
- Test data is cleaned up after run (unless --no-cleanup)
- No orphaned records left across systems

## Output Format:
```
## Pipeline Audit — [run_id]

### Stage Results
| Stage | Executor | Verifier | Cross-System | Verdict |
|-------|----------|----------|--------------|---------|
| stage1 | PASS/FAIL | PASS/FAIL | PASS/FAIL | PASS/FAIL |

### Issues Found
1. **[CRITICAL]** Stage X: Executor PASS but Verifier FAIL — [details]

### Overall: PASS / FAIL
```

Any executor-verifier disagreement (one PASS, other FAIL) is automatically CRITICAL.
Silent failures (no error but wrong data) are worse than loud failures."""

# ─── OpenAI API call (chat completions) ─────────────────────────────

def call_openai(system_prompt: str, user_prompt: str, model: str = "gpt-4.1") -> dict:
    """Call OpenAI Chat Completions API directly via httpx/requests."""
    import urllib.request
    import urllib.error

    url = "https://api.openai.com/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json",
    }
    payload = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "temperature": 0.2,
        "max_tokens": 4096,
    }).encode("utf-8")

    req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return {
                "ok": True,
                "content": data["choices"][0]["message"]["content"],
                "model": data.get("model", model),
                "usage": data.get("usage", {}),
            }
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        return {"ok": False, "error": f"HTTP {e.code}: {body}"}
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ─── Codex CLI (non-interactive) ────────────────────────────────────

def call_codex_exec(prompt: str, full_auto: bool = False, json_output: bool = False) -> dict:
    """Run `codex exec` non-interactively. Falls back to API if CLI not available."""
    codex_bin = "codex"  # assumes installed globally
    cmd = [codex_bin, "exec"]
    if full_auto:
        cmd.append("--full-auto")
    if json_output:
        cmd.append("--json")
    cmd.append(prompt)

    env = os.environ.copy()
    env["CODEX_API_KEY"] = OPENAI_API_KEY

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=300,
            cwd=str(REPO_ROOT), env=env,
        )
        if result.returncode == 0:
            return {"ok": True, "content": result.stdout, "stderr": result.stderr}
        else:
            return {"ok": False, "error": result.stderr or result.stdout}
    except FileNotFoundError:
        print("[INFO] codex CLI not found, falling back to OpenAI API", file=sys.stderr)
        return call_openai(AUDIT_SYSTEM, prompt)
    except subprocess.TimeoutExpired:
        return {"ok": False, "error": "codex exec timed out (300s)"}


# ─── Commands ───────────────────────────────────────────────────────

DOMAIN_PROMPTS = {
    "general": AUDIT_SYSTEM,
    "cfo": CFO_AUDIT_SYSTEM,
    "pipeline": PIPELINER_AUDIT_SYSTEM,
}


def _get_domain_prompt(args) -> str:
    """Return the system prompt for the selected domain + gate."""
    domain = getattr(args, "domain", "general") or "general"
    base = DOMAIN_PROMPTS.get(domain, AUDIT_SYSTEM)
    gate = (getattr(args, "gate", None) or "build").lower()
    if gate == "test":
        body = base + TEST_GATE_SUFFIX
    else:
        # build is default — explicit suffix keeps LLM context consistent
        body = base + BUILD_GATE_SUFFIX
    # ─── Anti-stale-knowledge guard ──────────────────────────────────
    # Inject today's date so models don't treat valid recent dates as "future".
    from datetime import datetime, timezone
    today = datetime.now(timezone.utc).date().isoformat()
    today_clause = (
        f"\n\n## CURRENT DATE\n"
        f"Today's date (system clock, UTC): **{today}**.\n"
        f"Treat this as 'now'. Dates ON or BEFORE today are NOT 'in the future'.\n"
        f"Do NOT use your training cutoff as the reference for 'now'.\n"
    )
    return body + today_clause


def cmd_audit(args):
    """Audit specified files as Evaluator."""
    file_contents = []
    for fp in args.files:
        p = Path(fp)
        if not p.exists():
            p = REPO_ROOT / fp
        if p.exists():
            content = p.read_text(encoding="utf-8", errors="replace")
            # Truncate very large files
            lines = content.splitlines()
            if len(lines) > 500:
                content = "\n".join(lines[:500]) + f"\n\n... ({len(lines) - 500} more lines truncated)"
            file_contents.append(f"### {fp}\n```python\n{content}\n```")
        else:
            file_contents.append(f"### {fp}\n(FILE NOT FOUND)")

    system_prompt = _get_domain_prompt(args)
    domain = getattr(args, "domain", "general") or "general"

    # RAG: enrich with past audit context if available
    rag_context = ""
    if not getattr(args, "no_rag", False) and _rag_healthy():
        rag_query_text = f"{domain} audit issues: " + " ".join(args.files[:3])
        rag_context = _rag_query(rag_query_text, mode="hybrid", top_k=3)
        if rag_context and len(rag_context) > 50:
            rag_context = f"\n\n## Prior Context (from RAG)\n{rag_context[:2000]}\n"
            print(f"[RAG] Enriched with {len(rag_context)} chars of prior context", file=sys.stderr)

    user_prompt = (
        f"[{domain.upper()} AUDIT] Audit the following files. Apply hard thresholds. Be skeptical.\n\n"
        + "\n\n".join(file_contents)
        + rag_context
    )

    if args.use_codex:
        result = call_codex_exec(f"[{domain.upper()} AUDIT MODE] {user_prompt}")
    else:
        result = call_openai(system_prompt, user_prompt, model=args.model)

    _output(result, args)


def cmd_verify(args):
    """Verify sprint contract against codebase."""
    contract_path = Path(args.contract)
    if not contract_path.exists():
        contract_path = REPO_ROOT / args.contract
    if not contract_path.exists():
        print(f"ERROR: Contract file not found: {args.contract}", file=sys.stderr)
        sys.exit(1)

    contract = contract_path.read_text(encoding="utf-8")
    domain = getattr(args, "domain", "general") or "general"
    user_prompt = (
        f"[{domain.upper()} VERIFY] Verify this sprint contract against the current codebase.\n\n"
        f"## Sprint Contract\n{contract}\n\n"
        "Check each acceptance criterion. Report PASS/FAIL/PARTIAL for each."
    )

    if args.use_codex:
        result = call_codex_exec(f"[VERIFY MODE] {user_prompt}")
    else:
        result = call_openai(VERIFY_SYSTEM, user_prompt, model=args.model)

    _output(result, args)


def cmd_ask(args):
    """Free-form question to Evaluator."""
    system_prompt = _get_domain_prompt(args)
    prompt = args.prompt

    # RAG: enrich question with related context
    if not getattr(args, "no_rag", False) and _rag_healthy():
        rag_context = _rag_query(prompt, mode="hybrid", top_k=5)
        if rag_context and len(rag_context) > 50:
            prompt = f"{prompt}\n\n## Related Context (from RAG)\n{rag_context[:2000]}"
            print(f"[RAG] Enriched question with {len(rag_context)} chars", file=sys.stderr)

    if args.use_codex:
        result = call_codex_exec(prompt)
    else:
        result = call_openai(system_prompt, prompt, model=args.model)

    _output(result, args)


def cmd_resume(args):
    """Resume a previous Codex session."""
    if args.use_codex:
        # Use codex exec resume
        cmd = ["codex", "exec", "resume"]
        if args.thread_id:
            cmd.append(args.thread_id)
        else:
            cmd.append("--last")
        cmd.append(args.prompt)

        env = os.environ.copy()
        env["CODEX_API_KEY"] = OPENAI_API_KEY

        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=300,
                cwd=str(REPO_ROOT), env=env,
            )
            output = {"ok": result.returncode == 0, "content": result.stdout, "stderr": result.stderr}
        except Exception as e:
            output = {"ok": False, "error": str(e)}
    else:
        output = call_openai(AUDIT_SYSTEM, args.prompt, model=args.model)

    _output(output, args)


# ─── Output helper ──────────────────────────────────────────────────

def _output(result: dict, args):
    """Print result and optionally save."""
    import io, sys as _sys
    # Fix Windows cp949 encoding crash — force UTF-8 stdout
    if _sys.stdout.encoding and _sys.stdout.encoding.lower() not in ("utf-8", "utf8"):
        _sys.stdout = io.TextIOWrapper(_sys.stdout.buffer, encoding="utf-8", errors="replace")
        _sys.stderr = io.TextIOWrapper(_sys.stderr.buffer, encoding="utf-8", errors="replace")

    ts = time.strftime("%Y%m%d_%H%M%S")

    if hasattr(args, "json_output") and args.json_output:
        out = json.dumps(result, ensure_ascii=False, indent=2)
        print(out)
    else:
        if result.get("ok"):
            print(result.get("content", ""))
        else:
            print(f"ERROR: {result.get('error', 'unknown')}", file=sys.stderr)
            sys.exit(1)

    # Always save to .tmp
    save_path = TMP_DIR / f"eval_{ts}.json"
    save_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n[Saved to {save_path}]", file=sys.stderr)

    # Print usage if available
    usage = result.get("usage", {})
    if usage:
        total = usage.get("total_tokens", usage.get("input_tokens", 0) + usage.get("output_tokens", 0))
        print(f"[Tokens: {total}]", file=sys.stderr)

    # RAG: auto-index successful audit results for future retrieval
    if result.get("ok") and not getattr(args, "no_rag", False):
        domain = getattr(args, "domain", "general") or "general"
        _rag_index_result(result, domain, ts)


# ─── CLI ────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Codex Evaluator — Cross-AI harness Evaluator agent"
    )
    parser.add_argument("--model", default="gpt-4.1", help="OpenAI model (default: gpt-4.1)")
    parser.add_argument("--use-codex", action="store_true", help="Use codex CLI instead of API")
    parser.add_argument("--json", dest="json_output", action="store_true", help="JSON output")
    parser.add_argument("--domain", choices=["general", "cfo", "pipeline"], default="general",
                        help="Domain-specific audit mode (default: general)")
    parser.add_argument("--gate", choices=["build", "test"], default="build",
                        help="Gate context: build=source code audit, test=execution-result audit (default: build)")
    parser.add_argument("--no-rag", action="store_true",
                        help="Disable LightRAG context enrichment and auto-indexing")

    sub = parser.add_subparsers(dest="command", required=True)

    # audit
    p_audit = sub.add_parser("audit", help="Audit code files")
    p_audit.add_argument("--files", nargs="+", required=True, help="Files to audit")
    p_audit.set_defaults(func=cmd_audit)

    # verify
    p_verify = sub.add_parser("verify", help="Verify sprint contract")
    p_verify.add_argument("--contract", required=True, help="Path to sprint contract MD")
    p_verify.set_defaults(func=cmd_verify)

    # ask
    p_ask = sub.add_parser("ask", help="Free-form question")
    p_ask.add_argument("prompt", help="Question for evaluator")
    p_ask.set_defaults(func=cmd_ask)

    # resume
    p_resume = sub.add_parser("resume", help="Resume previous session")
    p_resume.add_argument("--thread-id", help="Thread ID to resume")
    p_resume.add_argument("prompt", help="Follow-up prompt")
    p_resume.set_defaults(func=cmd_resume)

    args = parser.parse_args()

    if not OPENAI_API_KEY:
        print("ERROR: OPENAI_API_KEY not set in .env or environment", file=sys.stderr)
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
